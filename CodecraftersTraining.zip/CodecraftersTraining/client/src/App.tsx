import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import Home from "@/pages/home";
import About from "@/pages/about";
import Services from "@/pages/services";
import Training from "@/pages/training";
import Internships from "@/pages/internships";
import Contact from "@/pages/contact";
import Admin from "@/pages/admin";
import AdminLogin from "@/pages/admin-login";
import ApplyPage from "@/pages/apply";
import AdminContentPage from "@/pages/admin/content";
import SiteSettingsPage from "@/pages/admin/site-settings";
import { useEffect } from "react";
import { AnimatePresence } from "framer-motion";
import { PageTransition } from "@/components/ui/animated-section";
import { SiteSettingsProvider, useSiteSettings } from "@/contexts/site-settings-context";
import OurTeamPage from "@/pages/about/our-team";
import OurMissionPage from "@/pages/about/our-mission";
import OurHistoryPage from "@/pages/about/our-history";
import OverviewPage from "@/pages/about/overview";
import DigitalMarketingPage from "@/pages/services/digital-marketing";
import SoftwareSolutionsPage from "@/pages/services/software-solutions";
import InternshipProgramsPage from "@/pages/services/internship-programs";
import AcceptedInternshipsPage from "@/pages/admin/accepted-internships";
import AcceptedTrainingsPage from "@/pages/admin/accepted-trainings";

function ScrollToTop() {
  const [location] = useLocation();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [location]);
  
  return null;
}

function Router() {
  const [location] = useLocation();
  
  return (
    <>
      <ScrollToTop />
      <AnimatePresence mode="wait">
        <PageTransition key={location}>
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/about" component={About} />
            <Route path="/about/overview" component={OverviewPage} />
            <Route path="/about/our-team" component={OurTeamPage} />
            <Route path="/about/our-mission" component={OurMissionPage} />
            <Route path="/about/our-history" component={OurHistoryPage} />
            <Route path="/services" component={Services} />
            <Route path="/services/digital-marketing" component={DigitalMarketingPage} />
            <Route path="/services/software-solutions" component={SoftwareSolutionsPage} />
            <Route path="/services/internship-programs" component={InternshipProgramsPage} />
            <Route path="/training" component={Training} />
            <Route path="/internships" component={Internships} />
            <Route path="/contact" component={Contact} />
            <Route path="/admin-login" component={AdminLogin} />
            <Route path="/admin" component={Admin} />
            <Route path="/admin-content" component={AdminContentPage} />
            <Route path="/admin/content" component={AdminContentPage} />
            <Route path="/admin/site-settings" component={SiteSettingsPage} />
            <Route path="/admin/accepted-internships" component={AcceptedInternshipsPage} />
            <Route path="/admin/accepted-trainings" component={AcceptedTrainingsPage} />
            <Route path="/apply" component={ApplyPage} />
            <Route path="/apply/:type" component={ApplyPage} />
            <Route component={NotFound} />
          </Switch>
        </PageTransition>
      </AnimatePresence>
    </>
  );
}

// WhatsApp float button component that uses the context
function WhatsAppFloatButton() {
  const { formattedWhatsappNumber } = useSiteSettings();
  
  return (
    <div className="fixed bottom-6 right-6 z-50">
      <a 
        href={`https://wa.me/${formattedWhatsappNumber}`}
        target="_blank" 
        rel="noopener noreferrer"
        className="bg-green-500 hover:bg-green-600 text-white rounded-full w-14 h-14 flex items-center justify-center shadow-lg transition-all duration-300 hover:scale-110 pulse-animation"
        title="Contact us on WhatsApp"
      >
        <i className="fab fa-whatsapp text-2xl"></i>
      </a>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <SiteSettingsProvider>
      <div className="flex flex-col min-h-screen overflow-x-hidden">
        <Header />
        <main className="flex-grow">
          <Router />
        </main>
        <Footer />
          <WhatsAppFloatButton />
      </div>
      <Toaster />
      </SiteSettingsProvider>
    </QueryClientProvider>
  );
}

export default App;
