import { Link } from "wouter";
import { useSiteSettings } from "@/contexts/site-settings-context";

export default function Footer() {
  // Use the site settings context
  const { siteName, logoUrl, whatsappNumber, formattedWhatsappNumber, phoneNumber, email, address } = useSiteSettings();

  // Format address for display with line breaks
  const formattedAddress = () => {
    return address.split(',').map((line, index) => (
      <span key={index}>
        {line.trim()}{index < address.split(',').length - 1 ? ',' : ''}
        <br />
      </span>
    ));
  };

  return (
    <footer className="bg-gray-900 text-white pt-16 pb-10">
      <div className="container mx-auto px-6 sm:px-8 lg:px-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-x-12 gap-y-10 mb-16">
          <div className="max-w-xs">
            <div className="flex items-center mb-6">
              {logoUrl ? (
                <div className="h-10 w-auto mr-3">
                  <img 
                    src={logoUrl} 
                    alt={siteName}
                    className="h-full w-auto object-contain"
                    onError={(e) => {
                      const target = e.target as HTMLImageElement;
                      target.style.display = "none";
                    }}
                  />
                </div>
              ) : (
                <div className="h-10 w-10 rounded-md bg-[#4285F4] flex items-center justify-center mr-3">
                  <span className="text-white font-bold">CC</span>
              </div>
              )}
              <span className="text-xl font-bold">{siteName}</span>
            </div>
            <p className="text-gray-400 mb-8">
              Empowering tech careers through quality education, mentorship, and hands-on experience.
            </p>
            <div className="flex space-x-5">
              <a
                href="#"
                className="text-gray-400 hover:text-white transition duration-300"
                aria-label="Facebook"
              >
                <i className="fab fa-facebook-f"></i>
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-white transition duration-300"
                aria-label="Twitter"
              >
                <i className="fab fa-twitter"></i>
              </a>
              <a
                href="https://www.instagram.com/codecrafterspvtltd?igsh=NzljaGJ6cDFvMTM4"
                className="text-gray-400 hover:text-white transition duration-300"
                aria-label="Instagram"
                target="_blank"
                rel="noopener noreferrer"
              >
                <i className="fab fa-instagram"></i>
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-white transition duration-300"
                aria-label="LinkedIn"
              >
                <i className="fab fa-linkedin-in"></i>
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6">Quick Links</h3>
            <ul className="space-y-3.5">
              <li>
                <Link href="/">
                  <a className="text-gray-400 hover:text-white transition duration-300">Home</a>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <a className="text-gray-400 hover:text-white transition duration-300">About Us</a>
                </Link>
              </li>
              <li>
                <Link href="/services">
                  <a className="text-gray-400 hover:text-white transition duration-300">Services</a>
                </Link>
              </li>
              <li>
                <Link href="/training">
                  <a className="text-gray-400 hover:text-white transition duration-300">Training Programs</a>
                </Link>
              </li>
              <li>
                <Link href="/internships">
                  <a className="text-gray-400 hover:text-white transition duration-300">Internships</a>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <a className="text-gray-400 hover:text-white transition duration-300">Contact Us</a>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6">Programs</h3>
            <ul className="space-y-3.5">
              <li>
                <Link href="/training#cyber-security">
                  <a className="text-gray-400 hover:text-white transition duration-300">
                    Cyber Security & Ethical Hacking
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/training#full-stack">
                  <a className="text-gray-400 hover:text-white transition duration-300">
                    Full Stack Web Development
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/training#cloud-computing">
                  <a className="text-gray-400 hover:text-white transition duration-300">
                    Cloud Computing
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/training#ai-ml">
                  <a className="text-gray-400 hover:text-white transition duration-300">
                    AI & Machine Learning
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <a className="text-gray-400 hover:text-white transition duration-300">
                    Corporate Training
                  </a>
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-6">Contact</h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <i className="fas fa-map-marker-alt mt-1 mr-3 text-gray-400"></i>
                <span className="text-gray-400">
                  {formattedAddress()}
                </span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-phone-alt mr-3 text-gray-400"></i>
                <span className="text-gray-400">{phoneNumber}</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-envelope mr-3 text-gray-400"></i>
                <span className="text-gray-400">{email}</span>
              </li>
              <li>
                <a 
                  href={`https://wa.me/${formattedWhatsappNumber}`} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="mt-5 flex items-center bg-green-50 text-green-800 py-3 px-4 rounded-md hover:bg-green-100 transition-colors"
                >
                  <i className="fab fa-whatsapp text-green-600 text-xl mr-3"></i>
                  <div>
                    <div className="font-medium">Chat on WhatsApp</div>
                    <div className="text-xs text-green-700">Quick responses during business hours</div>
                  </div>
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} Codecrafters IT Training and Solutions. All rights reserved.
            </p>
            <div className="flex space-x-8">
              <a href="#" className="text-gray-400 hover:text-white text-sm transition duration-300">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition duration-300">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 hover:text-white text-sm transition duration-300">
                Sitemap
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
