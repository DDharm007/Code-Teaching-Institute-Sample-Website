import { Link, useLocation } from "wouter";
import { useState, useEffect } from "react";
import MobileMenu from "@/components/ui/mobile-menu";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown, GraduationCap, Shield, Code, Cloud, Brain, ArrowRight, UserPlus, Settings } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useSiteSettings } from "@/contexts/site-settings-context";

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [location] = useLocation();
  const [isHovered, setIsHovered] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  
  // Use the site settings context
  const { siteName, logoUrl } = useSiteSettings();

  useEffect(() => {
    const auth = sessionStorage.getItem("adminAuthenticated");
    setIsAdmin(auth === "true");
  }, [location]);

  const isActive = (path: string) => {
    return location === path;
  };

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/about", label: "About" },
    { href: "/services", label: "Services" },
    { href: "/training", label: "Training" },
    { href: "/internships", label: "Internships" },
    { href: "/contact", label: "Contact" },
  ];

  const trainingLinks = [
    { href: "/training", label: "All Programs", icon: <GraduationCap className="h-4 w-4 mr-2" /> },
    { href: "/training#cyber-security", label: "Cyber Security", icon: <Shield className="h-4 w-4 mr-2" /> },
    { href: "/training#full-stack", label: "Full Stack Development", icon: <Code className="h-4 w-4 mr-2" /> },
    { href: "/training#cloud-computing", label: "Cloud Computing", icon: <Cloud className="h-4 w-4 mr-2" /> },
    { href: "/training#ai-ml", label: "AI & ML", icon: <Brain className="h-4 w-4 mr-2" /> },
  ];

  // Animation variants for the header
  const headerVariants = {
    hidden: { opacity: 0, y: -20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: {
        duration: 0.5,
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const navItemVariants = {
    hidden: { opacity: 0, y: -10 },
    visible: { opacity: 1, y: 0 }
  };

  const logoVariants = {
    hidden: { scale: 0.8, opacity: 0 },
    visible: { 
      scale: 1, 
      opacity: 1,
      transition: { type: "spring", stiffness: 300, damping: 20 }
    },
    hover: { 
      scale: 1.05,
      transition: { type: "spring", stiffness: 400, damping: 10 }
    }
  };

  return (
    <motion.header 
      className={`bg-white/95 backdrop-blur-sm fixed w-full z-50 ${isScrolled ? "shadow-md" : ""} transition-all duration-300`}
      initial="hidden"
      animate="visible"
      variants={headerVariants}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/">
              <motion.div 
                className="flex-shrink-0 flex items-center" 
                variants={logoVariants}
                whileHover="hover"
              >
                <div className="flex items-center">
                  {logoUrl ? (
                    <div className="h-9 w-auto mr-2">
                      <img 
                        src={logoUrl} 
                        alt={siteName}
                        className="h-full object-contain"
                        onError={(e) => {
                          // Fallback to default logo on error
                          const target = e.target as HTMLImageElement;
                          target.style.display = "none";
                        }}
                      />
                    </div>
                  ) : (
                    <div className="relative h-9 w-9 overflow-hidden rounded-md bg-[#4285F4] flex items-center justify-center mr-2 shadow-md">
                    <motion.span 
                      className="text-white font-bold text-lg"
                      animate={{ 
                        scale: [1, 1.1, 1],
                        rotateZ: [0, 5, -5, 0]
                      }}
                      transition={{ 
                        duration: 3,
                        repeat: Infinity,
                        repeatType: "loop",
                        ease: "easeInOut",
                        times: [0, 0.2, 0.8, 1]
                      }}
                    >
                      CC
                    </motion.span>
                    <motion.div 
                      className="absolute -bottom-3 -right-3 w-6 h-6 bg-blue-300/30 rounded-full"
                      animate={{ 
                        scale: [0.8, 1.2, 0.8],
                        opacity: [0.5, 0.8, 0.5]
                      }}
                      transition={{ 
                        duration: 3, 
                        repeat: Infinity,
                        repeatType: "loop"
                      }}
                    />
                  </div>
                  )}
                  <motion.span 
                    className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-gray-800 to-gray-600"
                  >
                    {siteName}
                  </motion.span>
                </div>
              </motion.div>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-6">
            {navLinks.slice(0, 3).map((link, index) => (
              <motion.div key={link.href} variants={navItemVariants}>
                <Link href={link.href}>
                  <motion.span 
                    className={`font-medium relative animated-underline ${isActive(link.href) ? "text-primary" : "text-gray-800 hover:text-primary"}`}
                    onHoverStart={() => setIsHovered(link.href)}
                    onHoverEnd={() => setIsHovered("")}
                  >
                    {link.label}
                    {isActive(link.href) && (
                      <motion.div 
                        className="absolute -bottom-1 left-0 h-0.5 bg-primary rounded-full"
                        layoutId="activeNavIndicator"
                        initial={{ width: 0 }}
                        animate={{ width: '100%' }}
                        transition={{ duration: 0.3 }}
                      />
                    )}
                  </motion.span>
                </Link>
              </motion.div>
            ))}
            
            <motion.div variants={navItemVariants}>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <motion.button 
                    className={`font-medium flex items-center relative animated-underline focus:outline-none ${isActive("/training") ? "text-primary" : "text-gray-800 hover:text-primary"}`}
                    onHoverStart={() => setIsHovered("/training")}
                    onHoverEnd={() => setIsHovered("")}
                  >
                    Training 
                    <motion.div
                      animate={{ rotate: isHovered === "/training" ? 180 : 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      <ChevronDown className="h-4 w-4 ml-1" />
                    </motion.div>
                    {isActive("/training") && (
                      <motion.div 
                        className="absolute -bottom-1 left-0 h-0.5 bg-primary rounded-full"
                        layoutId="activeNavIndicator"
                        initial={{ width: 0 }}
                        animate={{ width: '100%' }}
                        transition={{ duration: 0.3 }}
                      />
                    )}
                  </motion.button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="center" sideOffset={20} className="border border-gray-200 shadow-xl animate-in slide-in-from-top-5 fade-in-20 w-56">
                  {trainingLinks.map((link) => (
                    <Link key={link.href} href={link.href}>
                      <DropdownMenuItem className="cursor-pointer hover:bg-gray-50">
                        <motion.div 
                          className="flex items-center w-full"
                          whileHover={{ x: 5 }}
                          transition={{ type: "spring", stiffness: 400, damping: 15 }}
                        >
                          {link.icon}
                          <span>{link.label}</span>
                        </motion.div>
                      </DropdownMenuItem>
                    </Link>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </motion.div>
            
            {navLinks.slice(4).map((link, index) => (
              <motion.div key={link.href} variants={navItemVariants}>
                <Link href={link.href}>
                  <motion.span 
                    className={`font-medium relative animated-underline ${isActive(link.href) ? "text-primary" : "text-gray-800 hover:text-primary"}`}
                    onHoverStart={() => setIsHovered(link.href)}
                    onHoverEnd={() => setIsHovered("")}
                  >
                    {link.label}
                    {isActive(link.href) && (
                      <motion.div 
                        className="absolute -bottom-1 left-0 h-0.5 bg-primary rounded-full"
                        layoutId="activeNavIndicator"
                        initial={{ width: 0 }}
                        animate={{ width: '100%' }}
                        transition={{ duration: 0.3 }}
                      />
                    )}
                  </motion.span>
                </Link>
              </motion.div>
            ))}
          </div>
          
          <div className="hidden md:flex items-center space-x-2">
            <Link href="/apply?internship=Full%20Stack%20Development%20Intern">
              <motion.div 
                whileHover={{ scale: 1.05 }} 
                whileTap={{ scale: 0.95 }}
                className="mr-2"
              >
                <Button variant="outline" className="relative overflow-hidden group border-blue-500 text-blue-600 hover:text-white">
                  <span className="relative z-10 flex items-center">
                    <UserPlus className="h-4 w-4 mr-1" />
                    Apply Now
                  </span>
                  <span className="absolute inset-0 h-full w-0 bg-gradient-to-r from-blue-500 to-blue-600 transition-all duration-300 group-hover:w-full"></span>
                </Button>
              </motion.div>
            </Link>
            
            <Link href="/contact">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button className="relative overflow-hidden group">
                  <span className="relative z-10 flex items-center">
                    Get Started
                    <motion.div 
                      className="ml-1"
                      animate={{ x: [0, 4, 0] }}
                      transition={{ 
                        duration: 1.5, 
                        repeat: Infinity,
                        repeatType: "loop",
                        ease: "easeInOut"
                      }}
                    >
                      <ArrowRight className="h-4 w-4" />
                    </motion.div>
                  </span>
                  <span className="absolute inset-0 h-full w-0 bg-gradient-to-r from-blue-400 to-blue-500 transition-all duration-300 group-hover:w-full"></span>
                </Button>
              </motion.div>
            </Link>
            
            <Link href="/admin-login">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button variant="ghost" className="text-gray-700 hover:text-gray-900">
                  Admin Login
                </Button>
              </motion.div>
            </Link>
          </div>
          
          <div className="flex items-center md:hidden">
            <MobileMenu navLinks={navLinks} />
          </div>
        </div>
      </div>
    </motion.header>
  );
}
