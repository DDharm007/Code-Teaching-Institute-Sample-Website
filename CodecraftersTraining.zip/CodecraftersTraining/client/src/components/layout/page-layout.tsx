import { ReactNode } from "react";
import { motion } from "framer-motion";
import { GradientText } from "@/components/ui/gradient-text";

interface PageLayoutProps {
  title: string;
  subtitle?: string;
  description?: string;
  children: ReactNode;
}

export default function PageLayout({ title, subtitle, description, children }: PageLayoutProps) {
  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-10">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl font-bold mb-4">
            {title.split(' ').slice(0, -1).join(' ')}{' '}
            <GradientText>{title.split(' ').slice(-1)[0]}</GradientText>
          </h1>
          
          {subtitle && (
            <h2 className="text-xl text-gray-700 mb-3">{subtitle}</h2>
          )}
          
          {description && (
            <p className="text-gray-600 max-w-2xl mx-auto">
              {description}
            </p>
          )}
        </motion.div>
      </div>
      
      {children}
    </div>
  );
} 