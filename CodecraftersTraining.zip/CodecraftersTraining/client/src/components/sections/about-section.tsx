import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { CheckCircle, Lightbulb, Eye } from "lucide-react";

export default function AboutSection() {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <h2 className="text-3xl font-bold mb-6">About Codecrafters</h2>
            <p className="text-gray-700 mb-4">
              Codecrafters IT Training and Solutions was founded with a mission to bridge the gap between academic learning and industry requirements. We empower individuals with cutting-edge technical skills and practical knowledge.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-lg font-bold mb-2 flex items-center">
                  <span className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                    <Lightbulb className="text-primary h-4 w-4" />
                  </span>
                  Our Mission
                </h3>
                <p className="text-gray-600">
                  To create industry-ready tech professionals through immersive, hands-on learning experiences.
                </p>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-lg font-bold mb-2 flex items-center">
                  <span className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-2">
                    <Eye className="text-green-600 h-4 w-4" />
                  </span>
                  Our Vision
                </h3>
                <p className="text-gray-600">
                  To become the premier destination for tech education and innovative digital solutions.
                </p>
              </div>
            </div>

            <div className="border-t border-gray-200 pt-6">
              <h3 className="text-xl font-bold mb-4">Core Values</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center">
                  <CheckCircle className="text-primary mr-2 h-4 w-4" />
                  <span className="text-gray-700">Industry Excellence</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="text-primary mr-2 h-4 w-4" />
                  <span className="text-gray-700">Practical Learning</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="text-primary mr-2 h-4 w-4" />
                  <span className="text-gray-700">Innovation First</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="text-primary mr-2 h-4 w-4" />
                  <span className="text-gray-700">Student Success</span>
                </div>
              </div>
            </div>
            
            <div className="mt-6">
              <Link href="/about/overview">
                <Button variant="outline" className="mt-2">Learn More About Us</Button>
              </Link>
            </div>
          </div>
          <div className="order-1 md:order-2">
            <div className="rounded-lg shadow-xl w-full md:max-w-md mx-auto overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Codecrafters team collaborating" 
                className="w-full h-full object-cover"
              />
              <div className="bg-blue-600 text-white p-4">
                <div className="flex items-center">
                  <div className="flex -space-x-2 mr-4">
                    <div className="h-8 w-8 rounded-full border-2 border-blue-600 bg-gray-300 shadow-lg"></div>
                    <div className="h-8 w-8 rounded-full border-2 border-blue-600 bg-gray-300 shadow-lg"></div>
                    <div className="h-8 w-8 rounded-full border-2 border-blue-600 bg-gray-300 shadow-lg"></div>
                  </div>
                  <p className="text-sm font-medium">Join 2,500+ students already learning with us</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
