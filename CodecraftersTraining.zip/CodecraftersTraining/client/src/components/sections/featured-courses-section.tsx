import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Code, Shield, Database, Brain } from "lucide-react";

export default function FeaturedCoursesSection() {
  const courses = [
    {
      id: 1,
      title: "Advanced Ethical Hacking",
      description: "Master advanced penetration testing techniques and security assessments. Learn to identify and exploit vulnerabilities in networks and systems ethically.",
      icon: <Shield className="h-10 w-10 text-primary" />,
      duration: "12 Weeks",
      level: "Advanced",
      students: "250+ Enrolled"
    },
    {
      id: 2,
      title: "React & Next.js Mastery",
      description: "Build modern, SEO-friendly web applications using React and Next.js. Learn state management, server-side rendering, and deployment strategies.",
      icon: <Code className="h-10 w-10 text-primary" />,
      duration: "10 Weeks",
      level: "Intermediate",
      students: "320+ Enrolled"
    },
    {
      id: 3,
      title: "Big Data Analytics",
      description: "Analyze large datasets using tools like Hadoop, Spark, and NoSQL databases. Learn data visualization techniques and predictive modeling.",
      icon: <Database className="h-10 w-10 text-primary" />,
      duration: "14 Weeks",
      level: "Intermediate",
      students: "180+ Enrolled"
    },
    {
      id: 4,
      title: "Artificial Intelligence Foundations",
      description: "Understand core AI concepts, algorithms, and applications. Build intelligent systems using machine learning, neural networks, and natural language processing.",
      icon: <Brain className="h-10 w-10 text-primary" />,
      duration: "16 Weeks",
      level: "Beginner to Intermediate",
      students: "420+ Enrolled"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Featured Courses</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Explore our most popular specialized courses designed to enhance your skills 
            and accelerate your career in the technology sector.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {courses.map((course) => (
            <motion.div
              key={course.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: course.id * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full border-none shadow-lg hover:shadow-xl transition-all duration-300 hover:translate-y-[-5px]">
                <CardContent className="p-6">
                  <div className="rounded-full bg-blue-50 p-4 w-16 h-16 flex items-center justify-center mb-4">
                    {course.icon}
                  </div>
                  <h3 className="text-xl font-bold mb-2">{course.title}</h3>
                  <p className="text-gray-600 mb-4 text-sm">{course.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    <Badge variant="outline" className="bg-blue-50">
                      {course.duration}
                    </Badge>
                    <Badge variant="outline" className="bg-blue-50">
                      {course.level}
                    </Badge>
                    <Badge variant="outline" className="bg-blue-50">
                      {course.students}
                    </Badge>
                  </div>
                  <Link href="/training">
                    <Button variant="outline" className="w-full">Learn More</Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-10 text-center"
        >
          <Link href="/training">
            <Button size="lg" className="px-8">
              View All Courses
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
} 