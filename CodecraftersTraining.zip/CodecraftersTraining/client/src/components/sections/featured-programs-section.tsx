import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Star, Sparkles, ArrowRight } from "lucide-react";

export default function FeaturedProgramsSection() {
  const programs = [
    {
      id: 1,
      title: "Full Stack Web Development Bootcamp",
      image: "https://images.unsplash.com/photo-1516116216624-53e697fedbea?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
      rating: 4.9,
      reviews: 420,
      description: "Our most comprehensive program covering frontend, backend, databases, and deployment. Build real-world applications with modern technologies.",
      duration: "16 weeks",
      highlights: [
        "MERN Stack (MongoDB, Express, React, Node)",
        "Real-world project portfolio",
        "Weekly 1:1 mentoring sessions",
        "Job placement assistance"
      ]
    },
    {
      id: 2,
      title: "Data Science & Machine Learning",
      image: "https://images.unsplash.com/photo-1543286386-713bdd548da4?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
      rating: 4.8,
      reviews: 375,
      description: "Master the essentials of data science, from data manipulation to advanced machine learning algorithms and deployment.",
      duration: "20 weeks",
      highlights: [
        "Python, Pandas, NumPy, Scikit-learn",
        "Deep learning with TensorFlow",
        "Natural Language Processing",
        "Kaggle competition participation"
      ]
    },
    {
      id: 3,
      title: "Cyber Security Professional",
      image: "https://images.unsplash.com/photo-1507721999472-8ed4421c4af2?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80",
      rating: 4.7,
      reviews: 290,
      description: "Develop essential security skills to protect organizations from cyber threats, including ethical hacking and security analysis.",
      duration: "14 weeks",
      highlights: [
        "Network security fundamentals",
        "Ethical hacking techniques",
        "Security certification prep",
        "Security operations center training"
      ]
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Featured Programs</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Our most popular bootcamps and professional training programs designed to
            transform your skills and launch your career in tech.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {programs.map((program) => (
            <motion.div
              key={program.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: program.id * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full overflow-hidden shadow-lg">
                <CardContent className="p-0">
                  <div className="relative h-48 overflow-hidden">
                    <img 
                      src={program.image}
                      alt={program.title}
                      className="w-full h-full object-cover transition-transform duration-700 hover:scale-110"
                    />
                    <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-transparent to-black/60"></div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white">{program.title}</h3>
                      <div className="flex items-center mt-1">
                        <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                        <span className="text-yellow-400 ml-1 font-medium">{program.rating}</span>
                        <span className="text-white/80 ml-1 text-sm">({program.reviews} reviews)</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <div className="flex items-center mb-2">
                      <Sparkles className="h-4 w-4 text-blue-500 mr-2" />
                      <span className="text-sm font-medium text-blue-700">{program.duration} intensive training</span>
                    </div>
                    
                    <p className="text-gray-600 mb-4">{program.description}</p>
                    
                    <ul className="space-y-2 mb-6">
                      {program.highlights.map((highlight, index) => (
                        <li key={index} className="flex items-start">
                          <span className="text-green-500 mr-2">✓</span>
                          <span className="text-sm text-gray-700">{highlight}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <Link href="/training">
                      <Button className="w-full group">
                        Learn More 
                        <ArrowRight className="h-4 w-4 ml-2 transition-transform group-hover:translate-x-1" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <Link href="/training">
            <Button variant="outline" className="px-8">
              View All Programs
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
} 