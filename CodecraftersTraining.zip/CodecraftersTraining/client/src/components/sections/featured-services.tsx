import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Laptop, 
  GraduationCap, 
  Code, 
  ChevronRight 
} from "lucide-react";

export default function FeaturedServices() {
  const services = [
    {
      id: "training",
      title: "IT Training Programs",
      description: "Career-focused 8-month courses taught by industry experts in cybersecurity, web development, cloud computing, and AI.",
      icon: <Laptop className="text-primary text-xl" />,
      link: "/training",
      linkText: "Explore Programs",
      iconBg: "bg-blue-100",
      linkColor: "text-primary hover:text-blue-700",
    },
    {
      id: "internships",
      title: "Industry Internships",
      description: "Gain real-world experience through our structured internship programs with mentoring and hands-on project work.",
      icon: <GraduationCap className="text-green-600 text-xl" />,
      link: "/internships",
      linkText: "View Opportunities",
      iconBg: "bg-green-100",
      linkColor: "text-green-600 hover:text-green-700",
    },
    {
      id: "solutions",
      title: "Digital Solutions",
      description: "Custom software development, digital marketing services, and business automation solutions for modern enterprises.",
      icon: <Code className="text-indigo-500 text-xl" />,
      link: "/services",
      linkText: "View Services",
      iconBg: "bg-indigo-100",
      linkColor: "text-indigo-500 hover:text-indigo-700",
    },
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Our Premium Offerings</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Discover our industry-leading training programs, internship opportunities, and software solutions tailored for the modern tech landscape.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service) => (
            <Card key={service.id} className="bg-gray-50 hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-6">
                <div className={`w-12 h-12 ${service.iconBg} rounded-md flex items-center justify-center mb-4`}>
                  {service.icon}
                </div>
                <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <Link href={service.link}>
                  <a className={`font-medium inline-flex items-center ${service.linkColor}`}>
                    {service.linkText}
                    <ChevronRight className="h-4 w-4 ml-1" />
                  </a>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="bg-gray-100 mt-12 relative overflow-hidden">
          <div className="absolute top-0 right-0 -mt-4 -mr-4 h-24 w-24 bg-yellow-400 opacity-20 rounded-full"></div>
          <div className="absolute bottom-0 left-0 -mb-8 -ml-8 h-32 w-32 bg-primary opacity-10 rounded-full"></div>

          <CardContent className="p-8">
            <div className="relative z-10 flex flex-col md:flex-row items-center justify-between">
              <div className="mb-6 md:mb-0 md:mr-8">
                <h3 className="text-2xl font-bold mb-2">Ready to Start Your Tech Journey?</h3>
                <p className="text-gray-600">
                  Join thousands of successful graduates who've transformed their careers with Codecrafters.
                </p>
              </div>
              <Link href="/contact">
                <Button className="whitespace-nowrap">Get Started Today</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
