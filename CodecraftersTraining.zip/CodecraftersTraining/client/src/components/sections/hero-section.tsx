import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { YellowGradientText } from "@/components/ui/gradient-text";
import { 
  AnimatedSection, 
  AnimatedContainer, 
  AnimatedItem 
} from "@/components/ui/animated-section";
import { motion } from "framer-motion";

export default function HeroSection() {
  // Typing animation for the title
  const titleWords = ["Innovative.", "Practical.", "Future-Ready."];
  
  return (
    <section id="home" className="pt-24 pb-16 md:pt-28 md:pb-24 bg-gradient-to-r from-blue-500 to-indigo-500 relative overflow-hidden">
      {/* Animated background circles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-white opacity-10"
            style={{
              width: `${Math.random() * 200 + 50}px`,
              height: `${Math.random() * 200 + 50}px`,
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
            animate={{
              x: [0, Math.random() * 100 - 50],
              y: [0, Math.random() * 100 - 50],
            }}
            transition={{
              duration: Math.random() * 10 + 15,
              repeat: Infinity,
              repeatType: "reverse",
              ease: "easeInOut",
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <AnimatedContainer>
            <AnimatedItem>
              <div className="text-white">
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5 }}
                >
                  <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 leading-tight">
                    Accelerate Your <YellowGradientText>Tech Career</YellowGradientText> with Expert Training
                  </h1>
                </motion.div>
                
                <motion.div 
                  className="h-8 my-2 overflow-hidden"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.7, duration: 0.5 }}
                >
                  <motion.h2 
                    className="text-xl md:text-2xl font-semibold gradient-title-secondary"
                    animate={{ y: titleWords.length * -40 }}
                    transition={{ 
                      repeat: Infinity, 
                      repeatType: "loop", 
                      duration: 6,
                      repeatDelay: 1,
                      ease: "easeInOut",
                    }}
                  >
                    {titleWords.map((word, i) => (
                      <div key={i} className="h-8">{word}</div>
                    ))}
                  </motion.h2>
                </motion.div>
                
                <AnimatedSection delay={0.3} direction="up">
                  <p className="text-lg mb-8 text-gray-100">
                    Codecrafters offers industry-aligned IT training programs, internships, and digital solutions to launch your tech career.
                  </p>
                </AnimatedSection>
                
                <AnimatedSection delay={0.5} direction="up">
                  <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                    <Link href="/training">
                      <Button className="bg-white text-primary hover:bg-gray-100 font-bold py-3 px-6 rounded-md w-full sm:w-auto relative overflow-hidden group">
                        <span className="relative z-10">Explore Courses</span>
                        <span className="absolute inset-0 h-full w-0 bg-gradient-to-r from-blue-400 to-indigo-500 transition-all duration-300 group-hover:w-full"></span>
                        <span className="absolute inset-0 h-full w-0 bg-gradient-to-r from-blue-400 to-indigo-500 opacity-50 blur-xl transition-all duration-300 group-hover:w-full"></span>
                      </Button>
                    </Link>
                    <Link href="/contact">
                      <Button variant="outline" className="bg-transparent border-2 border-white text-white hover:bg-white hover:bg-opacity-10 font-bold py-3 px-6 rounded-md w-full sm:w-auto transition-all duration-300 hover:shadow-[0_0_15px_rgba(255,255,255,0.3)]">
                        Contact Us
                      </Button>
                    </Link>
                  </div>
                </AnimatedSection>
                
                <AnimatedSection delay={0.7} direction="up">
                  <div className="mt-8 flex items-center text-gray-100">
                    <motion.div 
                      className="flex -space-x-2 mr-4"
                      initial={{ x: -20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: 0.9, duration: 0.5 }}
                    >
                      <div className="h-8 w-8 rounded-full border-2 border-white bg-gray-300 shadow-lg"></div>
                      <div className="h-8 w-8 rounded-full border-2 border-white bg-gray-300 shadow-lg"></div>
                      <div className="h-8 w-8 rounded-full border-2 border-white bg-gray-300 shadow-lg"></div>
                    </motion.div>
                    <motion.p 
                      className="text-sm"
                      initial={{ x: 20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: 1.1, duration: 0.5 }}
                    >
                      Join <span className="font-bold">2,500+</span> students already learning with us
                    </motion.p>
                  </div>
                </AnimatedSection>
              </div>
            </AnimatedItem>
          </AnimatedContainer>
          
          <AnimatedSection delay={0.3} direction="left">
            <div className="rounded-lg shadow-xl bg-white/10 backdrop-blur-sm p-6 border border-white/20 relative">
              <div className="absolute -top-4 -left-4 w-16 h-16 bg-blue-500 rounded-full opacity-20 floating-animation"></div>
              <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-indigo-500 rounded-full opacity-20 floating-animation" style={{ animationDelay: '1s' }}></div>
              
              <div className="grid grid-cols-2 gap-4">
                {[
                  { icon: "🚀", title: "Career Growth", desc: "Up to 200% salary increase" },
                  { icon: "👩‍💻", title: "Expert Mentors", desc: "Industry professionals" },
                  { icon: "🔥", title: "Practical Skills", desc: "Real-world projects" },
                  { icon: "🌐", title: "Global Network", desc: "Connect with peers" }
                ].map((item, i) => (
                  <motion.div
                    key={i}
                    className="bg-white/10 backdrop-blur-sm rounded-lg p-4 hover-card-effect"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4 + (i * 0.1), duration: 0.5 }}
                  >
                    <div className="text-3xl mb-2">{item.icon}</div>
                    <h3 className="font-bold text-white text-lg">{item.title}</h3>
                    <p className="text-gray-200 text-sm">{item.desc}</p>
                  </motion.div>
                ))}
              </div>
              
              <motion.div 
                className="mt-6 bg-gradient-to-r from-yellow-500/80 to-amber-500/80 p-4 rounded-lg"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.9, duration: 0.5 }}
              >
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-2xl mr-4">🎓</div>
                  <div>
                    <h3 className="font-bold text-white">New Batch Starting Soon!</h3>
                    <p className="text-white/90 text-sm">Limited seats available for our next cohort</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </AnimatedSection>
        </div>
      </div>
    </section>
  );
}
