import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function IndustryPartnersSection() {
  const partners = [
    {
      id: 1,
      name: "Microsoft",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/4/44/Microsoft_logo.svg/200px-Microsoft_logo.svg.png",
      category: "Technology",
      hires: 45
    },
    {
      id: 2,
      name: "Amazon",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/Amazon_logo.svg/200px-Amazon_logo.svg.png",
      category: "E-commerce & Cloud",
      hires: 38
    },
    {
      id: 3,
      name: "IBM",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/51/IBM_logo.svg/200px-IBM_logo.svg.png",
      category: "Technology",
      hires: 32
    },
    {
      id: 4,
      name: "Accenture",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/c/cd/Accenture.svg/200px-Accenture.svg.png",
      category: "Consulting",
      hires: 29
    },
    {
      id: 5,
      name: "Infosys",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Infosys_logo.svg/200px-Infosys_logo.svg.png",
      category: "IT Services",
      hires: 27
    },
    {
      id: 6,
      name: "Wipro",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Wipro_Primary_Logo_Color_RGB.svg/200px-Wipro_Primary_Logo_Color_RGB.svg.png",
      category: "IT Services",
      hires: 23
    },
    {
      id: 7,
      name: "TCS",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b1/Tata_Consultancy_Services_Logo.svg/200px-Tata_Consultancy_Services_Logo.svg.png",
      category: "IT Services",
      hires: 35
    },
    {
      id: 8,
      name: "Cognizant",
      logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/Cognizant_logo_2022.svg/200px-Cognizant_logo_2022.svg.png",
      category: "IT Services",
      hires: 19
    }
  ];

  const categories = ["Technology", "E-commerce & Cloud", "Consulting", "IT Services"];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Our Industry Partners</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            We collaborate with leading companies that hire our graduates and contribute to our curriculum development to ensure industry-relevant training.
          </p>
        </motion.div>

        <div className="mb-8 flex flex-wrap justify-center gap-3">
          <motion.button
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            viewport={{ once: true }}
            className="bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium hover:bg-blue-200 transition-colors"
          >
            All Partners
          </motion.button>
          
          {categories.map((category, index) => (
            <motion.button
              key={category}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 * (index + 1) }}
              viewport={{ once: true }}
              className="bg-gray-100 text-gray-800 px-4 py-2 rounded-full text-sm font-medium hover:bg-gray-200 transition-colors"
            >
              {category}
            </motion.button>
          ))}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-6">
          {partners.map((partner) => (
            <motion.div
              key={partner.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: partner.id * 0.05 }}
              viewport={{ once: true }}
            >
              <Card className="h-full border hover:shadow-md transition-shadow">
                <CardContent className="p-6 flex flex-col items-center justify-center">
                  <div className="h-16 flex items-center justify-center mb-4">
                    <img 
                      src={partner.logo} 
                      alt={partner.name} 
                      className="max-h-full max-w-[120px] object-contain"
                    />
                  </div>
                  <h3 className="font-medium text-center mb-1">{partner.name}</h3>
                  <p className="text-xs text-gray-500 text-center mb-2">{partner.category}</p>
                  <div className="text-xs text-blue-600 font-medium">
                    {partner.hires} graduates hired
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-12 text-center space-y-2"
        >
          <h3 className="text-xl font-bold">Interested in becoming a hiring partner?</h3>
          <p className="text-gray-600 mb-4 max-w-2xl mx-auto">
            Join our network of industry partners and get access to our talented pool of graduates.
          </p>
          <Link href="/contact">
            <Button variant="outline" className="px-8">
              Partner With Us
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
} 