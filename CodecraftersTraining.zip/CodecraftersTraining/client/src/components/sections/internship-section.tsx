import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { internships } from "@/lib/data";
import { 
  zodResolver 
} from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { internshipApplicationSchema, type InternshipApplicationFormValues } from "@shared/schema";

export default function InternshipSection() {
  const [category, setCategory] = useState("All Categories");
  const { toast } = useToast();

  const filteredInternships = category === "All Categories" 
    ? internships.slice(0, 2) 
    : internships.filter(intern => intern.category === category).slice(0, 2);

  const form = useForm<InternshipApplicationFormValues>({
    resolver: zodResolver(internshipApplicationSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      internshipType: "",
      coverLetter: "",
    },
  });

  const mutation = useMutation({
    mutationFn: (data: InternshipApplicationFormValues) => {
      return apiRequest("POST", "/api/internship-application", data);
    },
    onSuccess: async (response) => {
      const data = await response.json();
      toast({
        title: "Application Submitted",
        description: data.message,
      });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InternshipApplicationFormValues) => {
    mutation.mutate(data);
  };

  return (
    <section id="internship" className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Internship Opportunities</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Gain practical experience working on real-world projects with guidance from industry experts.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <Card className="mb-8">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-xl font-bold">Available Internship Programs</h3>
                  <div className="relative">
                    <Select
                      value={category}
                      onValueChange={setCategory}
                    >
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder="All Categories" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="All Categories">All Categories</SelectItem>
                        <SelectItem value="Software Development">Software Development</SelectItem>
                        <SelectItem value="Digital Marketing">Digital Marketing</SelectItem>
                        <SelectItem value="Cybersecurity">Cybersecurity</SelectItem>
                        <SelectItem value="Data Science">Data Science</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {filteredInternships.map((internship) => (
                  <div key={internship.id} className="border border-gray-200 rounded-lg p-5 mb-4 hover:border-primary transition-colors duration-300">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="text-lg font-bold mb-1">{internship.title}</h4>
                        <p className="text-gray-600 mb-3">Duration: {internship.duration}</p>
                      </div>
                      <Badge variant={internship.type === "Remote" ? "default" : "secondary"}>
                        {internship.type}
                      </Badge>
                    </div>

                    <div className="mb-3">
                      <h5 className="font-medium mb-2">Responsibilities:</h5>
                      <ul className="text-gray-700 space-y-1 pl-5 list-disc">
                        {internship.responsibilities.map((item, index) => (
                          <li key={index}>{item}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="mb-3">
                      <h5 className="font-medium mb-2">Requirements:</h5>
                      <ul className="text-gray-700 space-y-1 pl-5 list-disc">
                        {internship.requirements.map((item, index) => (
                          <li key={index}>{item}</li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200">
                      <div className="flex items-center">
                        <i className="fas fa-certificate text-yellow-500 mr-2"></i>
                        <span className="text-gray-700">Certificate & Recommendation Letter</span>
                      </div>
                      <Link href="#application-form">
                        <Button size="sm">Apply Now</Button>
                      </Link>
                    </div>
                  </div>
                ))}

                <div className="text-center mt-6">
                  <Link href="/internships">
                    <a className="inline-flex items-center text-primary font-medium">
                      View All Opportunities
                      <i className="fas fa-chevron-right ml-1 text-xs"></i>
                    </a>
                  </Link>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-6">Student Success Stories</h3>

                <div className="border-l-4 border-primary pl-4 mb-6">
                  <p className="text-gray-700 italic mb-2">
                    "The internship at Codecrafters gave me real-world exposure to enterprise software development. The mentorship I received helped me secure a full-time role at a leading tech company."
                  </p>
                  <p className="text-gray-900 font-medium">- Sarah J., Software Development Intern</p>
                </div>

                <div className="border-l-4 border-primary pl-4">
                  <p className="text-gray-700 italic mb-2">
                    "During my digital marketing internship, I managed real client campaigns that delivered measurable results. The hands-on experience was invaluable for my career growth."
                  </p>
                  <p className="text-gray-900 font-medium">- Raj M., Digital Marketing Intern</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div id="application-form">
            <Card className="sticky top-24">
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-6">Apply for Internship</h3>

                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="fullName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Your name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email</FormLabel>
                          <FormControl>
                            <Input placeholder="Your email" type="email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone</FormLabel>
                          <FormControl>
                            <Input placeholder="Your phone number" type="tel" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="internshipType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Internship Type</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select internship" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="full-stack">Full Stack Development</SelectItem>
                              <SelectItem value="digital-marketing">Digital Marketing</SelectItem>
                              <SelectItem value="cybersecurity">Cybersecurity</SelectItem>
                              <SelectItem value="data-science">Data Science</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div>
                      <FormLabel className="block text-gray-700 font-medium mb-2">Resume/CV</FormLabel>
                      <div className="border border-dashed border-gray-300 rounded-md p-6 text-center">
                        <input type="file" id="resume" className="hidden" accept=".pdf,.doc,.docx" />
                        <label htmlFor="resume" className="cursor-pointer block">
                          <i className="fas fa-cloud-upload-alt text-primary text-2xl mb-2"></i>
                          <p className="text-gray-700">Click to upload your Resume/CV</p>
                          <p className="text-gray-500 text-sm">(PDF, DOC, DOCX)</p>
                        </label>
                      </div>
                    </div>

                    <FormField
                      control={form.control}
                      name="coverLetter"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Cover Letter</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell us why you're interested in this internship" 
                              className="resize-none" 
                              rows={4}
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full"
                      disabled={mutation.isPending}
                    >
                      {mutation.isPending ? (
                        <span className="flex items-center">
                          <i className="fas fa-spinner fa-spin mr-2"></i>
                          Submitting...
                        </span>
                      ) : (
                        <span className="flex items-center justify-center">
                          <i className="fas fa-paper-plane mr-2"></i>
                          Submit Application
                        </span>
                      )}
                    </Button>

                    <p className="text-gray-500 text-sm text-center">
                      By submitting, you agree to our <a href="#" className="text-primary">Terms & Conditions</a> and <a href="#" className="text-primary">Privacy Policy</a>.
                    </p>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
