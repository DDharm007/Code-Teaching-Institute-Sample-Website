import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Code, Database, Shield, Brain, ArrowRight, Clock, Users, Trophy } from "lucide-react";

export default function LearningPathsSection() {
  const paths = [
    {
      id: 1,
      title: "Frontend Development Path",
      icon: <Code className="h-12 w-12 text-blue-500" />,
      duration: "6-8 months",
      level: "Beginner to Advanced",
      students: "1,200+ enrolled",
      description: "Master modern frontend development with HTML, CSS, JavaScript, React, and more.",
      milestones: [
        "HTML5 & CSS3 Fundamentals",
        "JavaScript & ES6+",
        "React.js Development",
        "UI/UX Best Practices"
      ],
      color: "from-blue-500 to-indigo-500"
    },
    {
      id: 2,
      title: "Backend Engineering Path",
      icon: <Database className="h-12 w-12 text-green-500" />,
      duration: "8-10 months",
      level: "Intermediate",
      students: "950+ enrolled",
      description: "Build scalable backend systems with Node.js, Python, databases, and cloud services.",
      milestones: [
        "Node.js & Express",
        "Database Design",
        "API Development",
        "Cloud Deployment"
      ],
      color: "from-green-500 to-teal-500"
    },
    {
      id: 3,
      title: "Cloud & DevOps Path",
      icon: <Shield className="h-12 w-12 text-purple-500" />,
      duration: "6-8 months",
      level: "Intermediate to Advanced",
      students: "750+ enrolled",
      description: "Learn cloud platforms, containerization, CI/CD, and infrastructure automation.",
      milestones: [
        "AWS/Azure Fundamentals",
        "Docker & Kubernetes",
        "CI/CD Pipelines",
        "Infrastructure as Code"
      ],
      color: "from-purple-500 to-pink-500"
    },
    {
      id: 4,
      title: "AI & ML Engineering Path",
      icon: <Brain className="h-12 w-12 text-orange-500" />,
      duration: "10-12 months",
      level: "Advanced",
      students: "600+ enrolled",
      description: "Dive into machine learning, deep learning, and AI model deployment.",
      milestones: [
        "Machine Learning Basics",
        "Deep Learning & Neural Networks",
        "Computer Vision & NLP",
        "MLOps & Deployment"
      ],
      color: "from-orange-500 to-red-500"
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Learning Paths</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Choose your career path and follow our structured learning roadmap to become
            an industry-ready professional.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {paths.map((path) => (
            <motion.div
              key={path.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: path.id * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full overflow-hidden shadow-lg group">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <div className={`rounded-2xl bg-gradient-to-br ${path.color} p-4 text-white`}>
                      {path.icon}
                    </div>
                    <div>
                      <h3 className="text-xl font-bold mb-2">{path.title}</h3>
                      <p className="text-gray-600 text-sm">{path.description}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4 my-6">
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{path.duration}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Trophy className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{path.level}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{path.students}</span>
                    </div>
                  </div>

                  <div className="space-y-3 mb-6">
                    {path.milestones.map((milestone, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <div className={`h-2 w-2 rounded-full bg-gradient-to-r ${path.color}`} />
                        <span className="text-sm text-gray-700">{milestone}</span>
                      </div>
                    ))}
                  </div>

                  <Link href="/training">
                    <Button className="w-full group">
                      Start This Path
                      <ArrowRight className="h-4 w-4 ml-2 transition-transform group-hover:translate-x-1" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <Link href="/training">
            <Button variant="outline" className="px-8">
              View All Learning Paths
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
} 