import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { 
  ChevronRight, Search, Megaphone, Hash, Pen, Laptop, 
  Smartphone, Bot, Cog, ChartGantt, UserRoundCheck, 
  Award, Briefcase, ArrowRight 
} from "lucide-react";
import { motion } from "framer-motion";
import { 
  AnimatedSection, 
  AnimatedContainer, 
  AnimatedItem,
  AnimatedCard 
} from "@/components/ui/animated-section";

export default function ServicesSection() {
  const services = [
    {
      id: "digital-marketing",
      title: "Digital Marketing",
      image: "bg-gradient-to-r from-blue-600 to-blue-400",
      color: "blue",
      items: [
        { icon: <Search className="text-blue-500 mt-1 mr-2 h-4 w-4" />, text: "Search Engine Optimization" },
        { icon: <Megaphone className="text-blue-500 mt-1 mr-2 h-4 w-4" />, text: "Search Engine Marketing" },
        { icon: <Hash className="text-blue-500 mt-1 mr-2 h-4 w-4" />, text: "Social Media Marketing" },
        { icon: <Pen className="text-blue-500 mt-1 mr-2 h-4 w-4" />, text: "Content Creation" }
      ],
      description: "Boost your online presence and drive qualified traffic with our comprehensive digital marketing strategies tailored to your business goals."
    },
    {
      id: "software-solutions",
      title: "Software Solutions",
      image: "bg-gradient-to-r from-indigo-600 to-purple-400",
      color: "indigo",
      items: [
        { icon: <Laptop className="text-indigo-500 mt-1 mr-2 h-4 w-4" />, text: "Custom Web Development" },
        { icon: <Smartphone className="text-indigo-500 mt-1 mr-2 h-4 w-4" />, text: "Mobile App Development" },
        { icon: <Bot className="text-indigo-500 mt-1 mr-2 h-4 w-4" />, text: "Business Automation" },
        { icon: <Cog className="text-indigo-500 mt-1 mr-2 h-4 w-4" />, text: "Enterprise Solutions" }
      ],
      description: "From concept to deployment, our experienced developers create custom software solutions that solve complex business challenges."
    },
    {
      id: "internship-programs",
      title: "Internship Programs",
      image: "bg-gradient-to-r from-green-600 to-emerald-400",
      color: "green",
      items: [
        { icon: <ChartGantt className="text-green-600 mt-1 mr-2 h-4 w-4" />, text: "Real-time Projects" },
        { icon: <UserRoundCheck className="text-green-600 mt-1 mr-2 h-4 w-4" />, text: "Industry Mentoring" },
        { icon: <Award className="text-green-600 mt-1 mr-2 h-4 w-4" />, text: "Professional Certification" },
        { icon: <Briefcase className="text-green-600 mt-1 mr-2 h-4 w-4" />, text: "Placement Assistance" }
      ],
      description: "Our structured internship programs provide hands-on experience working alongside industry professionals on real client projects."
    }
  ];

  const getColorClasses = (color: string) => {
    switch(color) {
      case 'blue':
        return {
          bg: "bg-blue-50",
          border: "border-blue-200",
          text: "text-blue-600",
          hover: "group-hover:text-blue-700",
          iconBg: "bg-blue-100",
          button: "from-blue-600 to-blue-500"
        };
      case 'indigo':
        return {
          bg: "bg-indigo-50",
          border: "border-indigo-200",
          text: "text-indigo-600",
          hover: "group-hover:text-indigo-700",
          iconBg: "bg-indigo-100",
          button: "from-indigo-600 to-indigo-500"
        };
      case 'green':
        return {
          bg: "bg-green-50",
          border: "border-green-200",
          text: "text-green-600",
          hover: "group-hover:text-green-700",
          iconBg: "bg-green-100",
          button: "from-green-600 to-green-500"
        };
      default:
        return {
          bg: "bg-blue-50",
          border: "border-blue-200",
          text: "text-blue-600",
          hover: "group-hover:text-blue-700",
          iconBg: "bg-blue-100",
          button: "from-blue-600 to-blue-500"
        };
    }
  };

  return (
    <section id="services" className="py-16 bg-gradient-to-b from-white to-gray-50 relative overflow-hidden">
      {/* Decorative background elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-primary/5 rounded-full -translate-y-1/2 translate-x-1/3 blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-500/5 rounded-full translate-y-1/3 -translate-x-1/3 blur-2xl"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <AnimatedSection direction="up">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 gradient-title">Our Services</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Comprehensive tech solutions to help businesses and individuals succeed in the digital age.
            </p>
          </div>
        </AnimatedSection>

        <AnimatedContainer className="grid grid-cols-1 lg:grid-cols-3 gap-8" staggerChildren={0.15}>
          {services.map((service, index) => {
            const colorClasses = getColorClasses(service.color);
            
            return (
              <AnimatedItem key={service.id}>
                <AnimatedCard className="group overflow-hidden shadow-md hover:shadow-xl transition-all duration-500 rounded-xl border border-gray-200 h-full flex flex-col">
                  <div className={`h-48 ${service.image} relative overflow-hidden`}>
                    {/* Animated floating shapes */}
                    <motion.div 
                      className="absolute w-16 h-16 rounded-full bg-white/20"
                      style={{ top: '10%', left: '10%' }}
                      animate={{ y: [0, 15, 0], opacity: [0.2, 0.3, 0.2] }}
                      transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                    />
                    <motion.div 
                      className="absolute w-12 h-12 rounded-full bg-white/20"
                      style={{ bottom: '20%', right: '15%' }}
                      animate={{ y: [0, -20, 0], opacity: [0.1, 0.25, 0.1] }}
                      transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                    />
                    
                    {/* Gradient overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent"></div>
                    
                    {/* Icon */}
                    <motion.div 
                      className="absolute top-6 right-6 w-16 h-16 flex items-center justify-center bg-white/20 backdrop-blur-md rounded-full"
                      whileHover={{ scale: 1.1, rotate: 5 }}
                    >
                      {service.id === "digital-marketing" && <Megaphone className="h-8 w-8 text-white" />}
                      {service.id === "software-solutions" && <Laptop className="h-8 w-8 text-white" />}
                      {service.id === "internship-programs" && <ChartGantt className="h-8 w-8 text-white" />}
                    </motion.div>
                    
                    {/* Title */}
                    <motion.div 
                      className="absolute bottom-0 left-0 p-6 w-full"
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2, duration: 0.5 }}
                      viewport={{ once: true }}
                    >
                      <h3 className="text-2xl font-bold text-white">{service.title}</h3>
                    </motion.div>
                  </div>
                  
                  <CardContent className="p-6 flex-grow flex flex-col">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                      {service.items.map((item, itemIndex) => (
                        <motion.div 
                          key={itemIndex} 
                          className="flex items-start"
                          initial={{ opacity: 0, x: -10 }}
                          whileInView={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.2 + (itemIndex * 0.1) }}
                          viewport={{ once: true }}
                        >
                          <div className={`flex-shrink-0 ${colorClasses.iconBg} rounded-full p-1.5 mt-0.5 mr-3`}>
                            {item.icon}
                          </div>
                          <span className="text-gray-700">{item.text}</span>
                        </motion.div>
                      ))}
                    </div>
                    
                    <p className="text-gray-600 mb-6 flex-grow">{service.description}</p>
                    
                    <motion.div 
                      className="mt-auto"
                      whileHover={{ x: 5 }}
                    >
                      <Link href={`/services/${service.id}`}>
                        <a className={`inline-flex items-center font-medium text-gray-700 group-hover:text-${service.color}-600 transition-colors duration-300`}>
                          <span className="mr-2">Learn more about {service.title}</span>
                          <span className={`inline-flex items-center justify-center w-6 h-6 rounded-full bg-gradient-to-r ${colorClasses.button} text-white transition-transform duration-300 group-hover:translate-x-1`}>
                            <ArrowRight className="h-3 w-3" />
                          </span>
                        </a>
                      </Link>
                    </motion.div>
                  </CardContent>
                </AnimatedCard>
              </AnimatedItem>
            );
          })}
        </AnimatedContainer>
      </div>
    </section>
  );
}
