import { motion } from "framer-motion";
import { Users, Award, TrendingUp, Building } from "lucide-react";

export default function StatisticsSection() {
  const stats = [
    {
      id: 1,
      value: "5,000+",
      label: "Students Trained",
      description: "Learners who have completed our courses and programs",
      icon: Users,
      color: "text-blue-500"
    },
    {
      id: 2,
      value: "92%",
      label: "Placement Rate",
      description: "Of our graduates find relevant jobs within 3 months",
      icon: Building,
      color: "text-green-500"
    },
    {
      id: 3,
      value: "₹4.2L",
      label: "Avg. Salary Increase",
      description: "Average salary growth after completing our programs",
      icon: TrendingUp,
      color: "text-purple-500"
    },
    {
      id: 4,
      value: "50+",
      label: "Industry Partners",
      description: "Companies that hire and trust our graduates",
      icon: Award,
      color: "text-orange-500"
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Our Impact in Numbers</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Codecrafters has helped thousands of students transform their careers
            and achieve their professional goals in the tech industry.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat) => (
            <motion.div
              key={stat.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: stat.id * 0.1 }}
              viewport={{ once: true }}
              className="bg-white rounded-lg shadow-lg p-6 text-center hover:shadow-xl transition-all duration-300"
            >
              <div className="flex justify-center mb-4">
                <div className={`p-3 rounded-full bg-opacity-10 ${stat.color.replace('text', 'bg')}`}>
                  <stat.icon className={`h-8 w-8 ${stat.color}`} />
                </div>
              </div>
              <h3 className="text-3xl font-extrabold mb-2">{stat.value}</h3>
              <h4 className="text-lg font-semibold mb-2">{stat.label}</h4>
              <p className="text-gray-600 text-sm">{stat.description}</p>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <div className="inline-flex items-center justify-center p-4 bg-gray-100 rounded-lg">
            <span className="text-sm font-medium text-gray-800">
              Based on data collected from 2020-2023
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  );
} 