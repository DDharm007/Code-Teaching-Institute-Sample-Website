import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { 
  BookOpen, 
  Video, 
  Users, 
  MessageSquare, 
  Code2, 
  Laptop, 
  GraduationCap,
  Lightbulb,
  ArrowRight
} from "lucide-react";

export default function StudentResourcesSection() {
  const resources = [
    {
      id: 1,
      title: "Learning Hub",
      icon: <BookOpen className="h-6 w-6" />,
      description: "Access our comprehensive library of tutorials, documentation, and learning materials.",
      features: [
        "Interactive tutorials",
        "Code examples",
        "Best practices guides",
        "Industry case studies"
      ],
      link: "/resources/learning"
    },
    {
      id: 2,
      title: "Video Library",
      icon: <Video className="h-6 w-6" />,
      description: "Watch recorded lectures, workshops, and expert sessions on various tech topics.",
      features: [
        "Expert lectures",
        "Workshop recordings",
        "Tech talks",
        "Project walkthroughs"
      ],
      link: "/resources/videos"
    },
    {
      id: 3,
      title: "Community Forum",
      icon: <Users className="h-6 w-6" />,
      description: "Connect with fellow students, alumni, and mentors to share knowledge and experiences.",
      features: [
        "Discussion boards",
        "Project showcases",
        "Job opportunities",
        "Networking events"
      ],
      link: "/community"
    },
    {
      id: 4,
      title: "Mentorship Program",
      icon: <MessageSquare className="h-6 w-6" />,
      description: "Get personalized guidance from industry experts through our mentorship program.",
      features: [
        "1:1 mentoring",
        "Career guidance",
        "Code reviews",
        "Mock interviews"
      ],
      link: "/mentorship"
    },
    {
      id: 5,
      title: "Practice Lab",
      icon: <Code2 className="h-6 w-6" />,
      description: "Sharpen your coding skills with our interactive practice environments and challenges.",
      features: [
        "Coding challenges",
        "Practice projects",
        "Real-world scenarios",
        "Assessment tests"
      ],
      link: "/practice"
    },
    {
      id: 6,
      title: "Tools & Resources",
      icon: <Laptop className="h-6 w-6" />,
      description: "Access premium development tools, cloud credits, and learning resources.",
      features: [
        "AWS/Azure credits",
        "Development tools",
        "Learning platforms",
        "Software licenses"
      ],
      link: "/resources/tools"
    }
  ];

  const highlights = [
    {
      icon: <GraduationCap className="h-8 w-8 text-blue-500" />,
      title: "24/7 Learning Support",
      description: "Get help anytime through our support channels"
    },
    {
      icon: <Lightbulb className="h-8 w-8 text-yellow-500" />,
      title: "Project-Based Learning",
      description: "Apply your skills to real-world projects"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Student Resources</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Access our comprehensive collection of learning resources, tools, and support
            services designed to help you succeed in your tech journey.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {resources.map((resource) => (
            <motion.div
              key={resource.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: resource.id * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="rounded-full bg-blue-50 p-3 w-12 h-12 flex items-center justify-center mb-4">
                    <div className="text-blue-500">
                      {resource.icon}
                    </div>
                  </div>

                  <h3 className="text-xl font-bold mb-2">{resource.title}</h3>
                  <p className="text-gray-600 text-sm mb-4">{resource.description}</p>

                  <ul className="space-y-2 mb-6">
                    {resource.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm text-gray-600">
                        <div className="h-1.5 w-1.5 rounded-full bg-blue-500 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>

                  <Link href={resource.link}>
                    <Button variant="outline" className="w-full group">
                      Access Resource
                      <ArrowRight className="h-4 w-4 ml-2 transition-transform group-hover:translate-x-1" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {highlights.map((highlight, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
              viewport={{ once: true }}
              className="bg-gray-50 rounded-lg p-6 flex items-center gap-4"
            >
              <div className="shrink-0">
                {highlight.icon}
              </div>
              <div>
                <h3 className="font-bold text-lg mb-1">{highlight.title}</h3>
                <p className="text-gray-600">{highlight.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
} 