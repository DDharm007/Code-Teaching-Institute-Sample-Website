import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BriefcaseIcon, GraduationCapIcon } from "lucide-react";

export default function SuccessStoriesSection() {
  const successStories = [
    {
      id: 1,
      name: "Arjun Sharma",
      image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
      program: "Full Stack Web Development",
      company: "Microsoft",
      role: "Software Engineer",
      story: "Coming from a non-technical background, I was worried about transitioning to tech. The program's hands-on approach and mentoring helped me land a job at Microsoft within 3 months of graduation.",
      salary: "180% Salary Increase"
    },
    {
      id: 2,
      name: "Priya Patel",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
      program: "Cyber Security & Ethical Hacking",
      company: "Deloitte",
      role: "Security Analyst",
      story: "The practical labs and industry-focused curriculum gave me real-world experience that impressed employers. I received multiple job offers and chose Deloitte for my cybersecurity career.",
      salary: "165% Salary Increase"
    },
    {
      id: 3,
      name: "Vikram Malhotra",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
      program: "AI & Machine Learning",
      company: "Amazon",
      role: "ML Engineer",
      story: "The AI program's project-based learning approach helped me build an impressive portfolio. The career support team connected me with Amazon, where I now work on exciting ML projects.",
      salary: "210% Salary Increase"
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Success Stories</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Our alumni have gone on to build successful careers at top companies. 
            Read their inspiring journeys from training to career transformation.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {successStories.map((story) => (
            <motion.div
              key={story.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: story.id * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full border-none shadow-lg overflow-hidden">
                <CardContent className="p-0">
                  <div className="bg-gradient-to-r from-blue-600 to-indigo-700 p-6 relative">
                    <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 translate-y-1/2">
                      <img 
                        src={story.image} 
                        alt={story.name}
                        className="w-24 h-24 rounded-full border-4 border-white object-cover"
                      />
                    </div>
                  </div>
                  
                  <div className="pt-16 p-6 text-center">
                    <h3 className="text-xl font-bold">{story.name}</h3>
                    <div className="flex items-center justify-center gap-2 mt-1 mb-3">
                      <Badge className="bg-blue-100 text-blue-800 border-blue-200">
                        <GraduationCapIcon className="h-3 w-3 mr-1" />
                        {story.program}
                      </Badge>
                    </div>
                    
                    <div className="flex items-center justify-center gap-2 mb-4">
                      <Badge variant="outline">
                        <BriefcaseIcon className="h-3 w-3 mr-1" />
                        {story.role} at {story.company}
                      </Badge>
                    </div>
                    
                    <p className="text-gray-600 italic mb-4">"{story.story}"</p>
                    
                    <div className="bg-green-50 text-green-800 font-semibold rounded-full px-4 py-1 text-sm inline-block">
                      {story.salary}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <div className="bg-white p-6 rounded-lg shadow-md max-w-2xl mx-auto">
            <h3 className="text-xl font-bold mb-2">Ready to Write Your Success Story?</h3>
            <p className="text-gray-600 mb-0">
              Join our training programs and transform your career. Our 94% placement rate speaks for itself.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
} 