import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { motion, AnimatePresence } from "framer-motion";
import { 
  AnimatedSection, 
  AnimatedContainer, 
  AnimatedItem 
} from "@/components/ui/animated-section";

// Define testimonial type
interface Testimonial {
  id: number;
  name: string;
  program: string;
  content: string;
}

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0); // -1 for left, 1 for right
  const [autoplay, setAutoplay] = useState(true);

  const { data: testimonials, isLoading } = useQuery<Testimonial[]>({
    queryKey: ["/api/testimonials"],
    staleTime: 60000, // 1 minute
  });

  // Autoplay testimonials every 5 seconds
  useEffect(() => {
    if (!autoplay || !testimonials || testimonials.length <= 1) return;
    
    const interval = setInterval(() => {
      handleNext();
    }, 5000);
    
    return () => clearInterval(interval);
  }, [autoplay, currentIndex, testimonials]);

  // Pause autoplay when user interacts with controls
  const pauseAutoplay = () => {
    setAutoplay(false);
    const timeout = setTimeout(() => setAutoplay(true), 10000); // Resume after 10 seconds of inactivity
    return () => clearTimeout(timeout);
  };

  const handlePrev = () => {
    if (testimonials && testimonials.length > 0) {
      setDirection(-1);
      pauseAutoplay();
      setCurrentIndex((prevIndex) => 
        prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
      );
    }
  };

  const handleNext = () => {
    if (testimonials && testimonials.length > 0) {
      setDirection(1);
      pauseAutoplay();
      setCurrentIndex((prevIndex) => 
        prevIndex === testimonials.length - 1 ? 0 : prevIndex + 1
      );
    }
  };

  const handleDotClick = (index: number) => {
    pauseAutoplay();
    setDirection(index > currentIndex ? 1 : -1);
    setCurrentIndex(index);
  };

  const variants = {
    enter: (direction: number) => {
      return {
        x: direction > 0 ? 300 : -300,
        opacity: 0
      };
    },
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1
    },
    exit: (direction: number) => {
      return {
        zIndex: 0,
        x: direction < 0 ? 300 : -300,
        opacity: 0
      };
    }
  };

  const shimmerVariants = {
    animate: {
      x: ["0%", "100%", "0%"],
      transition: {
        duration: 2.5,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  };

  return (
    <section className="py-16 bg-gradient-to-b from-gray-50 to-white relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 left-0 w-32 h-32 bg-primary/5 rounded-full -translate-x-1/2 -translate-y-1/2"></div>
      <div className="absolute bottom-0 right-0 w-40 h-40 bg-primary/5 rounded-full translate-x-1/2 translate-y-1/2"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <AnimatedSection direction="up">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4 gradient-title">What Our Students Say</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Hear from our graduates who have successfully transitioned into rewarding tech careers.
            </p>
          </div>
        </AnimatedSection>

        <div className="testimonial-slider max-w-4xl mx-auto relative">
          {isLoading ? (
            <AnimatedSection direction="up" delay={0.2}>
              <Card className="shadow-lg border-0">
                <CardContent className="p-6 md:p-8">
                  <div className="flex items-center mb-4">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <div className="ml-4 space-y-2">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-3 w-48" />
                    </div>
                    <div className="ml-auto">
                      <div className="flex space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <Skeleton key={i} className="h-4 w-4" />
                        ))}
                      </div>
                    </div>
                  </div>
                  
                  <div className="relative overflow-hidden">
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-5/6 mb-2" />
                    <Skeleton className="h-4 w-11/12" />
                    
                    <motion.div 
                      className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/30 to-transparent"
                      variants={shimmerVariants}
                      animate="animate"
                    />
                  </div>
                </CardContent>
              </Card>
            </AnimatedSection>
          ) : testimonials && testimonials.length > 0 ? (
            <AnimatedSection direction="up" delay={0.2}>
              <div className="relative mb-12">
                <div className="absolute -right-8 -top-8 text-primary/10">
                  <Quote size={120} />
                </div>
                
                <Card className="shadow-lg border-0 bg-white">
                  <CardContent className="p-6 md:p-8 relative">
                    <AnimatePresence initial={false} custom={direction} mode="wait">
                      <motion.div
                        key={currentIndex}
                        custom={direction}
                        variants={variants}
                        initial="enter"
                        animate="center"
                        exit="exit"
                        transition={{
                          x: { type: "spring", stiffness: 300, damping: 30 },
                          opacity: { duration: 0.2 }
                        }}
                      >
                        <div className="flex items-center mb-6">
                          <div className="flex-shrink-0 bg-primary h-16 w-16 rounded-full flex items-center justify-center text-white text-xl font-bold">
                            {testimonials[currentIndex].name.charAt(0)}
                          </div>
                          <div className="ml-4">
                            <h4 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-500">
                              {testimonials[currentIndex].name}
                            </h4>
                            <p className="text-gray-600">
                              {testimonials[currentIndex].program}
                            </p>
                          </div>
                          <div className="ml-auto">
                            <div className="flex text-yellow-400">
                              {[...Array(5)].map((_, i) => (
                                <motion.i 
                                  key={i} 
                                  className="fas fa-star"
                                  initial={{ opacity: 0, scale: 0 }}
                                  animate={{ opacity: 1, scale: 1 }}
                                  transition={{ delay: 0.1 * i, duration: 0.3 }}
                                />
                              ))}
                            </div>
                          </div>
                        </div>
                        
                        <motion.div
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.2, duration: 0.5 }}
                        >
                          <p className="text-gray-700 text-lg leading-relaxed">
                            "{testimonials[currentIndex].content}"
                          </p>
                        </motion.div>
                      </motion.div>
                    </AnimatePresence>
                  </CardContent>
                </Card>
              </div>
            </AnimatedSection>
          ) : (
            <AnimatedSection direction="up" delay={0.2}>
              <Card className="shadow-lg border-0">
                <CardContent className="p-6 md:p-8 text-center">
                  <p className="text-gray-500">No testimonials available at the moment.</p>
                </CardContent>
              </Card>
            </AnimatedSection>
          )}

          {/* Navigation controls */}
          <div className="flex justify-center items-center space-x-4">
            {/* Navigation arrows */}
            <motion.button 
              className="bg-white rounded-full p-3 shadow-md text-primary hover:text-white hover:bg-primary transition-colors duration-300"
              onClick={handlePrev}
              aria-label="Previous testimonial"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <ChevronLeft className="h-5 w-5" />
            </motion.button>
            
            {/* Pagination dots */}
            {testimonials && testimonials.length > 0 && (
              <div className="flex justify-center space-x-2">
                {testimonials.map((_, index) => (
                  <motion.button
                    key={index}
                    className={`h-3 w-3 rounded-full transition-all duration-300 ${
                      index === currentIndex ? "bg-primary scale-125" : "bg-gray-300"
                    }`}
                    onClick={() => handleDotClick(index)}
                    aria-label={`Go to testimonial ${index + 1}`}
                    whileHover={{ scale: 1.2 }}
                    animate={{
                      scale: index === currentIndex ? 1.2 : 1,
                      backgroundColor: index === currentIndex ? "#3b82f6" : "#d1d5db"
                    }}
                  />
                ))}
              </div>
            )}
            
            <motion.button 
              className="bg-white rounded-full p-3 shadow-md text-primary hover:text-white hover:bg-primary transition-colors duration-300"
              onClick={handleNext}
              aria-label="Next testimonial"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <ChevronRight className="h-5 w-5" />
            </motion.button>
          </div>
        </div>
      </div>
    </section>
  );
}
