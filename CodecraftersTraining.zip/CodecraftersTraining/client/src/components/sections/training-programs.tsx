import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { CheckCircle } from "lucide-react";
import { trainingPrograms } from "@/lib/data";
import { useSiteSettings } from "@/contexts/site-settings-context";

export default function TrainingPrograms() {
  const [activeTab, setActiveTab] = useState("cyber");
  
  // Use the site settings context
  const { formattedWhatsappNumber } = useSiteSettings();

  const handleTabClick = (tabId: string) => {
    setActiveTab(tabId);
  };

  const activeProgram = trainingPrograms.find((program) => program.id === activeTab);

  return (
    <section id="training" className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Career-Oriented IT Courses (8 Months)</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Industry-aligned training programs designed to transform beginners into job-ready professionals with hands-on projects and mentoring.
          </p>
        </div>

        {/* Training Programs Navigation Tabs */}
        <div className="border-b border-gray-200 mb-8">
          <nav className="flex flex-wrap -mb-px">
            {trainingPrograms.map((program) => (
              <button
                key={program.id}
                className={`mr-8 py-4 px-1 border-b-2 font-medium ${
                  activeTab === program.id
                    ? "border-primary text-primary"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
                onClick={() => handleTabClick(program.id)}
              >
                {program.shortTitle}
              </button>
            ))}
          </nav>
        </div>

        {/* Training Program Content */}
        {activeProgram && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <h3 className="text-2xl font-bold mb-4">{activeProgram.title}</h3>
              <p className="text-gray-700 mb-6">{activeProgram.description}</p>

              <div className="mb-6">
                <h4 className="text-lg font-bold mb-3">Course Modules</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {activeProgram.modules.map((module, index) => (
                    <div key={index} className="bg-gray-50 p-3 rounded-lg">
                      <span className="font-medium">{module}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mb-6">
                <h4 className="text-lg font-bold mb-3">Tools & Technologies</h4>
                <div className="flex flex-wrap gap-2">
                  {activeProgram.tools.map((tool, index) => (
                    <span key={index} className="bg-blue-100 text-primary px-3 py-1 rounded-full text-sm">
                      {tool}
                    </span>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6 mb-6">
                <div>
                  <h4 className="text-lg font-bold mb-2">Duration</h4>
                  <p className="text-gray-700">8 Months (Weekend & Evening Batches)</p>
                </div>
                <div>
                  <h4 className="text-lg font-bold mb-2">Certification</h4>
                  <p className="text-gray-700">Industry-recognized Codecrafters certification</p>
                </div>
              </div>
            </div>

            <Card className="bg-gray-50 shadow-md">
              <CardContent className="p-6">
                <h4 className="text-xl font-bold mb-4">Program Highlights</h4>
                <ul className="space-y-3 mb-6">
                  {activeProgram.highlights.map((highlight, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle className="text-green-500 mt-1 mr-2 h-4 w-4" />
                      <span className="text-gray-700">{highlight}</span>
                    </li>
                  ))}
                </ul>

                <Link href={`/apply/training?program=${activeProgram.id}`}>
                  <Button className="w-full">Apply Now</Button>
                </Link>

                <div className="mt-4 pt-4 border-t border-gray-200">
                  <h4 className="font-bold mb-2 text-center">Have Questions?</h4>
                  <a 
                    href={`https://wa.me/${formattedWhatsappNumber}`} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-center text-primary hover:text-blue-700"
                  >
                    <i className="fab fa-whatsapp mr-2 text-green-500"></i>
                    Chat with an Advisor
                  </a>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </section>
  );
}
