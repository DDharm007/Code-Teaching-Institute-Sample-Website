import { motion } from "framer-motion";

export default function TrustedBySection() {
  const partners = [
    {
      id: 1,
      name: "TechCorp",
      logo: "https://cdn-icons-png.flaticon.com/512/2111/2111432.png",
    },
    {
      id: 2,
      name: "InnovateTech",
      logo: "https://cdn-icons-png.flaticon.com/512/5968/5968853.png",
    },
    {
      id: 3,
      name: "GlobalSoft",
      logo: "https://cdn-icons-png.flaticon.com/512/5968/5968866.png",
    },
    {
      id: 4,
      name: "DataSystems",
      logo: "https://cdn-icons-png.flaticon.com/512/5968/5968350.png",
    },
    {
      id: 5,
      name: "CloudNexus",
      logo: "https://cdn-icons-png.flaticon.com/512/5968/5968672.png",
    },
    {
      id: 6,
      name: "SecureIT",
      logo: "https://cdn-icons-png.flaticon.com/512/5968/5968292.png",
    },
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Trusted By Industry Leaders</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Our programs are recognized and endorsed by leading technology companies, 
            ensuring our students receive industry-relevant training and certification.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8">
          {partners.map((partner) => (
            <motion.div
              key={partner.id}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: partner.id * 0.1 }}
              viewport={{ once: true }}
              className="flex items-center justify-center"
            >
              <div className="bg-white p-4 rounded-lg shadow-md w-full h-24 flex items-center justify-center hover:shadow-lg transition-shadow duration-300">
                <img
                  src={partner.logo}
                  alt={`${partner.name} logo`}
                  className="max-h-12 max-w-full opacity-70 hover:opacity-100 transition-opacity duration-300"
                />
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <p className="text-gray-600 font-medium">
            Our graduates are working at leading tech companies worldwide
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-x-8 gap-y-4">
            <span className="text-gray-800 font-semibold">• Microsoft</span>
            <span className="text-gray-800 font-semibold">• Google</span>
            <span className="text-gray-800 font-semibold">• Amazon</span>
            <span className="text-gray-800 font-semibold">• IBM</span>
            <span className="text-gray-800 font-semibold">• Accenture</span>
            <span className="text-gray-800 font-semibold">• TCS</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
} 