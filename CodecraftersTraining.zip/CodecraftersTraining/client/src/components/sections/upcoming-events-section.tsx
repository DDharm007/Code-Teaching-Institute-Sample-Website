import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Users, MapPin, Clock, ExternalLink } from "lucide-react";
import { Link } from "wouter";

export default function UpcomingEventsSection() {
  const events = [
    {
      id: 1,
      title: "Cybersecurity in the Age of AI Workshop",
      type: "Workshop",
      date: "April 15, 2023",
      time: "10:00 AM - 1:00 PM",
      location: "Online (Zoom)",
      description: "Learn about emerging threats and defense strategies in the evolving landscape of AI-powered cyber attacks.",
      speaker: "Dr. Rajiv Mehra, Security Expert",
      seats: "50 seats available",
      isFree: false,
      price: "₹499"
    },
    {
      id: 2,
      title: "Web3 Development Essentials",
      type: "Webinar",
      date: "April 22, 2023",
      time: "6:00 PM - 7:30 PM",
      location: "Online (YouTube Live)",
      description: "Introduction to blockchain development, smart contracts, and building decentralized applications.",
      speaker: "Ananya Singh, Blockchain Developer",
      seats: "Unlimited",
      isFree: true,
      price: "Free"
    },
    {
      id: 3,
      title: "Career Fair: Tech Jobs 2023",
      type: "Networking",
      date: "May 5, 2023",
      time: "11:00 AM - 4:00 PM",
      location: "Codecrafters Campus, Bangalore",
      description: "Connect with over 25 hiring companies looking for fresh tech talent. Bring your resume and portfolio!",
      speaker: "",
      seats: "200 seats available",
      isFree: true,
      price: "Free"
    },
    {
      id: 4,
      title: "Data Science Bootcamp Preview",
      type: "Info Session",
      date: "May 12, 2023",
      time: "5:00 PM - 6:30 PM",
      location: "Online (Teams)",
      description: "Learn about our upcoming 12-week Data Science Bootcamp. Meet instructors and ask questions live.",
      speaker: "Dr. Preeti Sharma, Lead Data Scientist",
      seats: "100 seats available",
      isFree: true,
      price: "Free"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl font-bold mb-4">Upcoming Events</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Join our workshops, webinars, and networking events to enhance your skills
            and connect with industry professionals.
          </p>
        </motion.div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {events.map((event) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: event.id * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full overflow-hidden shadow">
                <CardContent className="p-0">
                  <div className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <Badge className={event.type === "Workshop" ? "bg-purple-100 text-purple-800" :
                                        event.type === "Webinar" ? "bg-blue-100 text-blue-800" :
                                        event.type === "Networking" ? "bg-green-100 text-green-800" :
                                        "bg-orange-100 text-orange-800"}>
                        {event.type}
                      </Badge>
                      <span className={`text-sm font-medium ${event.isFree ? "text-black" : "text-black"}`}>
                        {event.price}
                      </span>
                    </div>
                    
                    <h3 className="text-xl font-bold mb-3">{event.title}</h3>
                    <p className="text-gray-600 mb-4">{event.description}</p>
                    
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-gray-700">
                        <Calendar className="h-4 w-4 mr-2 text-primary" />
                        <span>{event.date}</span>
                      </div>
                      <div className="flex items-center text-gray-700">
                        <Clock className="h-4 w-4 mr-2 text-primary" />
                        <span>{event.time}</span>
                      </div>
                      <div className="flex items-center text-gray-700">
                        <MapPin className="h-4 w-4 mr-2 text-primary" />
                        <span>{event.location}</span>
                      </div>
                      {event.speaker && (
                        <div className="flex items-center text-gray-700">
                          <Users className="h-4 w-4 mr-2 text-primary" />
                          <span>{event.speaker}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex justify-between items-center mt-6">
                      <span className="text-sm text-gray-500">{event.seats}</span>
                      <Button size="sm" className="bg-blue-900 hover:bg-blue-800">
                        Register Now <ExternalLink className="ml-1 h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          viewport={{ once: true }}
          className="mt-10 text-center"
        >
          <Link href="/events">
            <Button variant="outline" size="sm" className="px-8">
              View All Events
            </Button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
} 