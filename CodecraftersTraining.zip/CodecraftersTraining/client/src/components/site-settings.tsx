import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Loader2 } from "lucide-react";
import axios from "axios";
import { useState } from "react";
import { toast } from "sonner";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export type SiteSettings = {
  siteName: string;
  logoUrl: string;
  whatsappNumber: string;
  email: string;
  phoneNumber: string;
  address: string;
};

export default function SiteSettings() {
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [previewLogo, setPreviewLogo] = useState<string | null>(null);
  const [logoUploading, setLogoUploading] = useState(false);

  const getSiteSettingsQuery = useQuery({
    queryKey: ["site-settings"],
    queryFn: async () => {
      const response = await axios.get("/api/site-settings");
      return response.data as SiteSettings;
    },
  });

  const [siteSettings, setSiteSettings] = useState<SiteSettings>(
    getSiteSettingsQuery.data || {
      siteName: "",
      logoUrl: "",
      whatsappNumber: "",
      email: "",
      phoneNumber: "",
      address: "",
    }
  );

  // Update local state when query data becomes available
  if (getSiteSettingsQuery.data && !siteSettings.siteName) {
    setSiteSettings(getSiteSettingsQuery.data);
    if (getSiteSettingsQuery.data.logoUrl) {
      setPreviewLogo(getSiteSettingsQuery.data.logoUrl);
    }
  }

  const updateSiteSettingMutation = useMutation({
    mutationFn: async (settings: SiteSettings) => {
      const response = await axios.post("/api/site-settings", settings);
      return response.data;
    },
    onSuccess: () => {
      toast.success("Site settings updated successfully");
      getSiteSettingsQuery.refetch();
    },
    onError: (error) => {
      toast.error("Failed to update site settings");
      console.error(error);
    },
  });

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setLogoFile(file);
      setPreviewLogo(URL.createObjectURL(file));
    }
  };

  const uploadLogo = async () => {
    if (!logoFile) return null;

    try {
      setLogoUploading(true);
      const formData = new FormData();
      formData.append("file", logoFile);

      const response = await axios.post("/api/upload", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      setLogoUploading(false);
      return response.data.url;
    } catch (error) {
      console.error("Error uploading logo:", error);
      setLogoUploading(false);
      toast.error("Failed to upload logo");
      return null;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    let updatedSettings = { ...siteSettings };
    
    if (logoFile) {
      const logoUrl = await uploadLogo();
      if (logoUrl) {
        updatedSettings.logoUrl = logoUrl;
      }
    }
    
    updateSiteSettingMutation.mutate(updatedSettings);
  };

  if (getSiteSettingsQuery.isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Site Settings</h1>
      
      <Tabs defaultValue="general" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8">
          <TabsTrigger value="general">General Settings</TabsTrigger>
          <TabsTrigger value="contact">Contact Information</TabsTrigger>
        </TabsList>
        
        <form onSubmit={handleSubmit}>
          <TabsContent value="general">
            <Card>
              <CardHeader>
                <CardTitle>General Settings</CardTitle>
                <CardDescription>
                  Update your site name and logo that appear across the website.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="siteName">Site Name</Label>
                  <Input
                    id="siteName"
                    placeholder="Enter site name"
                    value={siteSettings.siteName}
                    onChange={(e) =>
                      setSiteSettings({ ...siteSettings, siteName: e.target.value })
                    }
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="logo">Logo</Label>
                  <div className="flex items-start gap-6">
                    <div className="border p-4 rounded-md h-32 w-32 flex items-center justify-center bg-gray-50">
                      {previewLogo ? (
                        <img
                          src={previewLogo}
                          alt="Logo Preview"
                          className="max-h-full max-w-full object-contain"
                        />
                      ) : (
                        <div className="text-gray-400 text-sm text-center">
                          No logo uploaded
                        </div>
                      )}
                    </div>
                    <div className="flex-1 space-y-4">
                      <div>
                        <Input
                          id="logo"
                          type="file"
                          accept="image/*"
                          onChange={handleLogoChange}
                          className="cursor-pointer"
                        />
                        <p className="text-sm text-gray-500 mt-2">
                          Recommended: Square image, max 1MB, PNG or JPG
                        </p>
                      </div>
                      {previewLogo && (
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => {
                            setPreviewLogo(null);
                            setLogoFile(null);
                            if (siteSettings.logoUrl) {
                              setSiteSettings({
                                ...siteSettings,
                                logoUrl: "",
                              });
                            }
                          }}
                          size="sm"
                        >
                          Remove Logo
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="contact">
            <Card>
              <CardHeader>
                <CardTitle>Contact Information</CardTitle>
                <CardDescription>
                  Update your contact details that appear on the website.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="whatsappNumber">WhatsApp Number</Label>
                    <Input
                      id="whatsappNumber"
                      placeholder="Enter WhatsApp number"
                      value={siteSettings.whatsappNumber}
                      onChange={(e) =>
                        setSiteSettings({
                          ...siteSettings,
                          whatsappNumber: e.target.value,
                        })
                      }
                    />
                    <p className="text-xs text-gray-500">
                      Format: Country code + number (e.g., 919876543210)
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phoneNumber">Phone Number</Label>
                    <Input
                      id="phoneNumber"
                      placeholder="Enter phone number"
                      value={siteSettings.phoneNumber}
                      onChange={(e) =>
                        setSiteSettings({
                          ...siteSettings,
                          phoneNumber: e.target.value,
                        })
                      }
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter email address"
                    value={siteSettings.email}
                    onChange={(e) =>
                      setSiteSettings({ ...siteSettings, email: e.target.value })
                    }
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <Textarea
                    id="address"
                    placeholder="Enter address"
                    value={siteSettings.address}
                    onChange={(e) =>
                      setSiteSettings({ ...siteSettings, address: e.target.value })
                    }
                    rows={3}
                  />
                  <p className="text-xs text-gray-500">
                    Use commas to separate address lines
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <div className="mt-6 flex justify-end">
            <Button
              type="submit"
              disabled={updateSiteSettingMutation.isPending || logoUploading}
              className="min-w-28"
            >
              {updateSiteSettingMutation.isPending || logoUploading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Changes"
              )}
            </Button>
          </div>
        </form>
      </Tabs>
    </div>
  );
} 