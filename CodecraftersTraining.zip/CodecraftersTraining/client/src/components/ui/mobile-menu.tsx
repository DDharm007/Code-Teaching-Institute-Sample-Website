import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { X, Menu, Home, Info, Settings, GraduationCap, Briefcase, Mail, ArrowRight, UserPlus } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

type MobileMenuProps = {
  navLinks: {
    href: string;
    label: string;
  }[];
};

export default function MobileMenu({ navLinks }: MobileMenuProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();

  // Close menu when navigating to a new page
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  // Prevent scrolling when menu is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }

    return () => {
      document.body.style.overflow = "auto";
    };
  }, [isOpen]);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const closeMenu = () => {
    setIsOpen(false);
  };

  const getIcon = (label: string) => {
    switch (label.toLowerCase()) {
      case "home": return <Home className="h-5 w-5 mr-3" />;
      case "about": return <Info className="h-5 w-5 mr-3" />;
      case "services": return <Settings className="h-5 w-5 mr-3" />;
      case "training": return <GraduationCap className="h-5 w-5 mr-3" />;
      case "internships": return <Briefcase className="h-5 w-5 mr-3" />;
      case "contact": return <Mail className="h-5 w-5 mr-3" />;
      default: return null;
    }
  };

  // Animation variants
  const menuVariants = {
    closed: {
      opacity: 0,
      x: "100%",
      transition: {
        type: "spring",
        stiffness: 400,
        damping: 40,
        when: "afterChildren",
        staggerChildren: 0.05,
        staggerDirection: -1
      }
    },
    open: {
      opacity: 1,
      x: 0,
      transition: {
        type: "spring",
        stiffness: 400,
        damping: 30,
        when: "beforeChildren",
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    closed: { 
      opacity: 0, 
      x: 50, 
      transition: { type: "spring", stiffness: 300, damping: 30 } 
    },
    open: { 
      opacity: 1, 
      x: 0, 
      transition: { type: "spring", stiffness: 300, damping: 30 } 
    }
  };

  const buttonVariants = {
    closed: { 
      scale: 0, 
      opacity: 0, 
      transition: { type: "spring", stiffness: 300, damping: 30 } 
    },
    open: { 
      scale: 1, 
      opacity: 1, 
      transition: { 
        type: "spring", 
        stiffness: 400, 
        damping: 15, 
        delay: 0.5 
      } 
    }
  };

  return (
    <div className="md:hidden">
      <motion.button
        type="button"
        onClick={toggleMenu}
        className="text-gray-800 hover:text-primary relative z-50"
        aria-label="Toggle mobile menu"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <motion.div
              key="close"
              initial={{ opacity: 0, rotate: -90 }}
              animate={{ opacity: 1, rotate: 0 }}
              exit={{ opacity: 0, rotate: 90 }}
              transition={{ duration: 0.2 }}
            >
              <X className="h-6 w-6" />
            </motion.div>
          ) : (
            <motion.div
              key="menu"
              initial={{ opacity: 0, rotate: 90 }}
              animate={{ opacity: 1, rotate: 0 }}
              exit={{ opacity: 0, rotate: -90 }}
              transition={{ duration: 0.2 }}
            >
              <Menu className="h-6 w-6" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div 
            className="fixed inset-0 z-40 flex"
            initial="closed"
            animate="open"
            exit="closed"
            variants={{
              open: { opacity: 1 },
              closed: { opacity: 0 }
            }}
          >
            {/* Backdrop */}
            <motion.div 
              className="absolute inset-0 bg-black/10 backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeMenu}
            />
            
            {/* Mobile menu panel */}
            <motion.div 
              className="relative ml-auto w-4/5 max-w-xs h-full bg-white shadow-xl flex flex-col"
              variants={menuVariants}
            >
              <div className="flex-1 overflow-y-auto py-6 px-4">
                <div className="mb-6 flex items-center px-2">
                  <div className="h-8 w-8 rounded-md bg-gradient-to-r from-blue-500 to-indigo-500 flex items-center justify-center mr-2">
                    <span className="text-white font-bold">CC</span>
                  </div>
                  <span className="text-xl font-bold text-gray-800">Codecrafters</span>
                </div>
                
                <div className="space-y-3">
                  {navLinks.map((link, index) => (
                    <motion.div
                      key={link.href}
                      variants={itemVariants}
                      custom={index}
                    >
                      <Link
                        href={link.href}
                        onClick={closeMenu}
                      >
                        <motion.div 
                          className={`flex items-center px-3 py-3 rounded-md text-base font-medium ${location === link.href ? 'bg-blue-50 text-primary' : 'text-gray-800 hover:bg-gray-50'}`}
                          whileHover={{ x: 5 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          {getIcon(link.label)}
                          {link.label}
                          {location === link.href && (
                            <motion.div 
                              className="ml-auto w-1.5 h-6 bg-primary rounded-full"
                              layoutId="mobileActiveIndicator"
                            />
                          )}
                        </motion.div>
                      </Link>
                    </motion.div>
                  ))}
                </div>
              </div>
              
              <div className="p-4 space-y-3">
                <motion.div
                  variants={buttonVariants}
                >
                  <Link
                    href="/apply?internship=Full%20Stack%20Development%20Intern"
                    onClick={closeMenu}
                  >
                    <motion.div 
                      className="flex items-center justify-center w-full py-3 px-4 rounded-md text-base font-medium border border-blue-500 text-blue-600"
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <UserPlus className="h-5 w-5 mr-2" />
                      <span>Apply Now</span>
                    </motion.div>
                  </Link>
                </motion.div>

                <motion.div
                  variants={buttonVariants}
                >
                  <Link
                    href="/contact"
                    onClick={closeMenu}
                  >
                    <motion.div 
                      className="flex items-center justify-center w-full py-3 px-4 rounded-md text-base font-medium bg-gradient-to-r from-primary to-blue-600 text-white shadow-md"
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <span>Get Started</span>
                      <motion.div 
                        className="ml-2"
                        animate={{ x: [0, 3, 0] }}
                        transition={{ 
                          duration: 1.5, 
                          repeat: Infinity,
                          repeatType: "loop" 
                        }}
                      >
                        <ArrowRight className="h-5 w-5" />
                      </motion.div>
                    </motion.div>
                  </Link>
                </motion.div>

                <motion.div
                  variants={buttonVariants}
                  className="mt-3"
                >
                  <Link
                    href="/admin-login"
                    onClick={closeMenu}
                  >
                    <motion.div 
                      className="flex items-center justify-center w-full py-3 px-4 rounded-md text-base font-medium border border-gray-300 text-gray-700"
                      whileHover={{ scale: 1.03 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <span>Admin Login</span>
                    </motion.div>
                  </Link>
                </motion.div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
