import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { getSiteSettings } from "@/lib/mock-api";

// Define the types for our context
interface SiteSettingsContextType {
  siteName: string;
  logoUrl: string;
  whatsappNumber: string;
  formattedWhatsappNumber: string;
  phoneNumber: string;
  email: string;
  address: string;
  isLoading: boolean;
  refresh: () => Promise<void>;
}

// Default values
const defaultSettings = {
  siteName: "CodeCrafter",
  logoUrl: "",
  whatsappNumber: "+91 90233 62937",
  formattedWhatsappNumber: "919023362937",
  phoneNumber: "+91 90233 62937",
  email: "info@codecrafters.com",
  address: "Codecrafter, Vaikuntha Char Rasta, Waghodia Rd, near Waghodia, Chowkdi, Kendranagar, Vadodara, Gujarat 390019",
  isLoading: true,
  refresh: async () => {},
};

// Create the context with default values
const SiteSettingsContext = createContext<SiteSettingsContextType>(defaultSettings);

// Provider component
export function SiteSettingsProvider({ children }: { children: ReactNode }) {
  const [siteName, setSiteName] = useState(defaultSettings.siteName);
  const [logoUrl, setLogoUrl] = useState(defaultSettings.logoUrl);
  const [whatsappNumber, setWhatsappNumber] = useState(defaultSettings.whatsappNumber);
  const [formattedWhatsappNumber, setFormattedWhatsappNumber] = useState(defaultSettings.formattedWhatsappNumber);
  const [phoneNumber, setPhoneNumber] = useState(defaultSettings.phoneNumber);
  const [email, setEmail] = useState(defaultSettings.email);
  const [address, setAddress] = useState(defaultSettings.address);
  const [isLoading, setIsLoading] = useState(true);

  // Function to load settings with retry mechanism
  const loadSettings = async (retryCount = 0): Promise<void> => {
    try {
      setIsLoading(true);
      const settings = await getSiteSettings();
      
      // Process each setting individually
      settings.forEach(setting => {
        switch(setting.key) {
          case "site_name":
            if (setting.value) {
              setSiteName(setting.value);
              document.title = setting.value;
            }
            break;
          case "logo":
            if (setting.value) setLogoUrl(setting.value);
            break;
          case "whatsapp_number":
            if (setting.value) {
              setWhatsappNumber(setting.value);
              // Format the number (remove spaces, +, etc.)
              const formattedNumber = setting.value.replace(/\D/g, '');
              setFormattedWhatsappNumber(formattedNumber);
            }
            break;
          case "phone":
            if (setting.value) setPhoneNumber(setting.value);
            break;
          case "email":
            if (setting.value) setEmail(setting.value);
            break;
          case "address":
            if (setting.value) setAddress(setting.value);
            break;
        }
      });
    } catch (error) {
      console.error(`Error loading site settings (attempt ${retryCount + 1}):`, error);
      
      // Implement retry logic with exponential backoff
      if (retryCount < 3) {
        const backoffTime = Math.pow(2, retryCount) * 1000; // 1s, 2s, 4s
        setTimeout(() => loadSettings(retryCount + 1), backoffTime);
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Load settings when the provider mounts
  useEffect(() => {
    loadSettings();
    
    // Set up periodic refresh of settings
    const refreshInterval = setInterval(() => loadSettings(), 60000); // Refresh every minute
    
    return () => clearInterval(refreshInterval);
  }, []);

  // Refresh function that can be called manually
  const refresh = async (): Promise<void> => {
    await loadSettings();
  };

  const value = {
    siteName, 
    logoUrl, 
    whatsappNumber, 
    formattedWhatsappNumber,
    phoneNumber,
    email,
    address,
    isLoading,
    refresh
  };

  return (
    <SiteSettingsContext.Provider value={value}>
      {children}
    </SiteSettingsContext.Provider>
  );
}

// Custom hook to use the site settings context - defined as a named constant function to work with HMR
export const useSiteSettings = () => useContext(SiteSettingsContext); 