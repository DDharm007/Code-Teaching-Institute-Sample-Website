export const trainingPrograms = [
  {
    id: "cyber",
    shortTitle: "Cyber Security & Ethical Hacking",
    title: "Cyber Security & Ethical Hacking",
    description: "Master the techniques to identify, prevent, and mitigate cyber threats. This comprehensive program prepares you for a career in information security with hands-on labs and real-world scenarios.",
    modules: [
      "Network Security Fundamentals",
      "Vulnerability Assessment",
      "Penetration Testing",
      "Security Auditing & Compliance",
      "Cryptography & Encryption",
      "Incident Response & Recovery"
    ],
    tools: ["Kali Linux", "Wireshark", "Metasploit", "Nmap", "Burp Suite", "OWASP ZAP"],
    highlights: [
      "24/7 Lab Access for Practical Training",
      "Industry Mentors from Top Cybersecurity Firms",
      "Capstone Project: Security Audit of Real Systems",
      "Job Placement Assistance",
      "Preparation for Security+ & CEH Certification"
    ],
    careers: [
      "Security Analyst",
      "Penetration Tester",
      "Security Consultant",
      "Compliance Specialist",
      "Security Operations Center (SOC) Analyst"
    ]
  },
  {
    id: "fullstack",
    shortTitle: "Full Stack Web Development",
    title: "Full Stack Web Development using AI",
    description: "Master both frontend and backend development skills enhanced with AI capabilities. Build responsive, intelligent web applications with the latest frameworks and tools.",
    modules: [
      "Frontend Development (HTML/CSS/JS)",
      "React.js & State Management",
      "Backend with Node.js & Express",
      "Database Design & Management",
      "AI Integration & APIs",
      "Deployment & DevOps Basics"
    ],
    tools: ["React", "Node.js", "MongoDB", "Express", "OpenAI API", "Git"],
    highlights: [
      "Build 5+ Production-Ready Projects",
      "AI-Enhanced Development Techniques",
      "Capstone Project: Full Stack Application",
      "Job Placement Assistance",
      "Regular Code Reviews by Industry Experts"
    ],
    careers: [
      "Full Stack Developer",
      "Frontend Developer",
      "Backend Developer",
      "Web Application Developer",
      "AI Integration Specialist"
    ]
  },
  {
    id: "cloud",
    shortTitle: "Cloud Computing",
    title: "Cloud Computing",
    description: "Gain expertise in designing, deploying, and managing cloud infrastructure. Learn the major cloud platforms, serverless architectures, and DevOps practices.",
    modules: [
      "Cloud Architecture Fundamentals",
      "AWS/Azure/GCP Services",
      "Infrastructure as Code",
      "Containerization & Orchestration",
      "Cloud Security & Compliance",
      "Serverless Computing"
    ],
    tools: ["AWS", "Docker", "Kubernetes", "Terraform", "Jenkins", "GitHub Actions"],
    highlights: [
      "Cloud Platform Certifications Preparation",
      "Real-world Cloud Migration Projects",
      "Multi-cloud Environment Experience",
      "DevOps Integration",
      "Cost Optimization Techniques"
    ],
    careers: [
      "Cloud Solutions Architect",
      "Cloud Administrator",
      "DevOps Engineer",
      "Site Reliability Engineer",
      "Cloud Security Specialist"
    ]
  },
  {
    id: "ai",
    shortTitle: "AI & ML",
    title: "Artificial Intelligence & Machine Learning",
    description: "Master the fundamentals and advanced concepts of AI and ML. Learn to build intelligent systems, train models, and implement real-world AI applications.",
    modules: [
      "Machine Learning Fundamentals",
      "Deep Learning & Neural Networks",
      "Natural Language Processing",
      "Computer Vision",
      "Reinforcement Learning",
      "AI Ethics & Responsible AI"
    ],
    tools: ["Python", "TensorFlow", "PyTorch", "Scikit-learn", "Jupyter", "Hugging Face"],
    highlights: [
      "Industry-focused AI Project Portfolio",
      "Access to GPU Computing Resources",
      "Kaggle Competition Participation",
      "AI Research Paper Discussion Sessions",
      "Real-world Dataset Experience"
    ],
    careers: [
      "Machine Learning Engineer",
      "AI Researcher",
      "Data Scientist",
      "Computer Vision Engineer",
      "NLP Specialist"
    ]
  }
];

export const internships = [
  {
    id: 1,
    title: "Full Stack Development Intern",
    duration: "3 Months (Extendable)",
    type: "Remote",
    category: "Software Development",
    responsibilities: [
      "Develop and maintain web applications using React.js and Node.js",
      "Collaborate with the team on database design and API development",
      "Participate in code reviews and implement feedback"
    ],
    requirements: [
      "Basic knowledge of JavaScript, HTML, and CSS",
      "Familiarity with React.js or similar frontend frameworks",
      "Eager to learn and work in a collaborative environment"
    ]
  },
  {
    id: 2,
    title: "Digital Marketing Intern",
    duration: "3 Months (Extendable)",
    type: "Hybrid",
    category: "Digital Marketing",
    responsibilities: [
      "Assist in creating and implementing digital marketing campaigns",
      "Manage social media accounts and create engaging content",
      "Analyze campaign performance and prepare reports"
    ],
    requirements: [
      "Understanding of digital marketing concepts",
      "Creative mindset with good writing skills",
      "Basic knowledge of social media platforms and analytics"
    ]
  },
  {
    id: 3,
    title: "Cybersecurity Intern",
    duration: "3 Months (Extendable)",
    type: "Remote",
    category: "Cybersecurity",
    responsibilities: [
      "Assist in vulnerability assessments and penetration testing",
      "Monitor security logs and identify potential threats",
      "Help develop security documentation and policies"
    ],
    requirements: [
      "Basic understanding of network security concepts",
      "Familiarity with security tools like Wireshark, Nmap",
      "Strong analytical and problem-solving skills"
    ]
  },
  {
    id: 4,
    title: "Data Science Intern",
    duration: "3 Months (Extendable)",
    type: "Hybrid",
    category: "Data Science",
    responsibilities: [
      "Collect and preprocess data for analysis",
      "Develop and implement machine learning models",
      "Create visualizations and reports from data insights"
    ],
    requirements: [
      "Basic knowledge of Python and data analysis libraries",
      "Understanding of statistical concepts",
      "Experience with data visualization tools"
    ]
  }
];
