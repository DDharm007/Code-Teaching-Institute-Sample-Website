 // Mock API service for site settings

// Define the interface for site settings
export interface SiteSetting {
  id: number;
  key: string;
  value: string;
  description: string;
  updatedAt: string;
}

// Default site settings to use if none exist
const defaultSettings = {
  site_name: "CodeCrafter",
  logo: "", // Empty logo by default
  whatsapp_number: "+91 90233 62937",
  phone: "+91 90233 62937",
  email: "info@codecrafters.com",
  address: "Codecrafter, Vaikuntha Char Rasta, Waghodia Rd, near Waghodia, Chowkdi, Kendranagar, Vadodara, Gujarat 390019"
};

/**
 * Helper function to get setting description
 */
function getSettingDescription(key: string): string {
  const descriptions: Record<string, string> = {
    site_name: "Name of your site displayed in the header, footer, and browser tab",
    logo: "Your site logo used in header and footer",
    whatsapp_number: "WhatsApp contact number with country code",
    phone: "Contact phone number displayed in the footer",
    email: "Contact email address displayed in the footer",
    address: "Physical address displayed in the footer"
  };
  
  return descriptions[key] || "";
}

/**
 * Get all site settings
 */
export async function getSiteSettings(): Promise<SiteSetting[]> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  try {
    // Get settings from localStorage or use defaults
    const storedSettings = localStorage.getItem('siteSettings');
    const settings = storedSettings ? JSON.parse(storedSettings) : defaultSettings;
    
    // Convert object to array format
    return Object.entries(settings).map(([key, value], index) => ({
      id: index + 1,
      key,
      value: value as string,
      description: getSettingDescription(key),
      updatedAt: new Date().toISOString()
    }));
  } catch (error) {
    console.error("Error getting site settings:", error);
    return [];
  }
}

/**
 * Update a site setting
 */
export async function updateSiteSetting(key: string, value: string): Promise<SiteSetting> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 300));
  
  try {
    // Get existing settings
    const storedSettings = localStorage.getItem('siteSettings');
    const settings = storedSettings ? JSON.parse(storedSettings) : defaultSettings;
    
    // Update the setting
    settings[key] = value;
    
    // Save back to localStorage
    localStorage.setItem('siteSettings', JSON.stringify(settings));
    
    // Return the updated setting
    return {
      id: 0,
      key,
      value,
      description: getSettingDescription(key),
      updatedAt: new Date().toISOString()
    };
  } catch (error) {
    console.error("Error updating site setting:", error);
    throw new Error("Failed to update setting");
  }
} 