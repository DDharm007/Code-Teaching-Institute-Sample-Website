import AboutSection from "@/components/sections/about-section";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { GradientText } from "@/components/ui/gradient-text";

export default function About() {
  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">About <GradientText>Codecrafters</GradientText></h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Learn more about our mission, values, and vision for transforming IT education
          </p>
        </div>
        
        <Separator className="my-8" />
      </div>
      
      <AboutSection />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <Card className="bg-gray-50">
          <CardContent className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div>
                <h2 className="text-2xl font-bold mb-4">Our History</h2>
                <p className="text-gray-700 mb-4">
                  Codecrafters was founded in 2015 by a team of industry professionals who recognized a significant gap between academic education and the practical skills needed in the IT industry.
                </p>
                <p className="text-gray-700">
                  What started as a small training center with just two courses has now grown into a comprehensive IT training and solutions provider with multiple program offerings, a robust internship platform, and professional services for businesses of all sizes.
                </p>
              </div>
              
              <div>
                <h2 className="text-2xl font-bold mb-4">Our Approach</h2>
                <p className="text-gray-700 mb-4">
                  We believe in learning by doing. Our training methodology combines theoretical knowledge with extensive hands-on practice, industry-relevant projects, and mentorship from experienced professionals.
                </p>
                <p className="text-gray-700">
                  We continuously update our curriculum to align with the latest industry trends and technologies, ensuring our students graduate with the most relevant skills employers are seeking.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
