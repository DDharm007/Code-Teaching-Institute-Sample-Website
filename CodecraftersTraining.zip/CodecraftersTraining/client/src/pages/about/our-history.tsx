import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { GradientText } from "@/components/ui/gradient-text";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft, Clock } from "lucide-react";

export default function OurHistoryPage() {
  const milestones = [
    {
      year: "2015",
      title: "Foundation",
      description: "Codecrafters founded with a vision to bridge the gap between academic education and industry requirements.",
      image: "https://images.unsplash.com/photo-1515187029135-18ee286d815b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    },
    {
      year: "2016",
      title: "First Training Center",
      description: "Opened our first training center with two flagship courses: Full Stack Development and Cyber Security.",
      image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    },
    {
      year: "2017",
      title: "Corporate Partnerships",
      description: "Established our first corporate partnerships for internship placements and training programs.",
      image: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    },
    {
      year: "2018",
      title: "Curriculum Expansion",
      description: "Added Cloud Computing and AI & Machine Learning to our course offerings.",
      image: "https://images.unsplash.com/photo-1629904853716-f0bc54eea481?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    },
    {
      year: "2020",
      title: "Online Learning Platform",
      description: "Launched our comprehensive online learning platform in response to the global pandemic.",
      image: "https://images.unsplash.com/photo-1603969072881-b0fc7f3d77d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    },
    {
      year: "2022",
      title: "Expansion",
      description: "Expanded to a larger facility to accommodate growing student enrollment and new program offerings.",
      image: "https://images.unsplash.com/photo-1497366811353-6870744d04b2?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    },
    {
      year: "2023",
      title: "Industry Recognition",
      description: "Received industry recognition for our innovative training methodologies and student success rates.",
      image: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    },
    {
      year: "Today",
      title: "Looking Forward",
      description: "Continuing to innovate and expand our offerings to meet the evolving needs of the tech industry.",
      image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
    }
  ];

  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="mb-8">
          <Link href="/about">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to About
            </Button>
          </Link>
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Our <GradientText>History</GradientText></h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              The journey of Codecrafters from its founding to where we are today
            </p>
          </div>
        </div>
        
        <Separator className="my-8" />
        
        <div className="max-w-3xl mx-auto my-16">
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-0 md:left-1/2 transform md:-translate-x-1/2 h-full w-1 bg-gray-200"></div>
            
            {/* Timeline items */}
            {milestones.map((milestone, index) => (
              <div key={index} className={`relative mb-20 ${index % 2 === 0 ? 'md:pr-12 md:text-right md:mr-auto md:ml-0' : 'md:pl-12 md:ml-auto md:mr-0'} md:w-1/2 z-10`}>
                {/* Year circle */}
                <div className={`absolute top-0 ${index % 2 === 0 ? 'md:right-[-24px]' : 'md:left-[-24px]'} left-[-24px] w-12 h-12 rounded-full bg-primary text-white flex items-center justify-center shadow-lg`}>
                  <Clock className="h-6 w-6" />
                </div>
                
                <Card className={`overflow-hidden hover:shadow-lg transition-all duration-300 ${index % 2 === 0 ? 'md:mr-6' : 'md:ml-6'}`}>
                  <div className="h-48 overflow-hidden">
                    <img 
                      src={milestone.image} 
                      alt={milestone.title} 
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                    />
                    <div className="absolute top-4 left-4 bg-white px-3 py-1 rounded-full text-primary font-bold">
                      {milestone.year}
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-bold mb-2">{milestone.title}</h3>
                    <p className="text-gray-600">{milestone.description}</p>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
} 