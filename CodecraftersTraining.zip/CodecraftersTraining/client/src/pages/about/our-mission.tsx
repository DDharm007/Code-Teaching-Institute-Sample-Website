import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { GradientText } from "@/components/ui/gradient-text";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft, Target, TrendingUp, Users, Award, Zap, Globe } from "lucide-react";

export default function OurMissionPage() {
  const values = [
    {
      icon: <Target className="h-8 w-8 text-primary" />,
      title: "Excellence",
      description: "We strive for excellence in everything we do, from curriculum development to student support."
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-primary" />,
      title: "Innovation",
      description: "We embrace innovation and continuously update our methods to stay ahead of industry trends."
    },
    {
      icon: <Users className="h-8 w-8 text-primary" />,
      title: "Community",
      description: "We foster a supportive community where students and professionals can learn and grow together."
    },
    {
      icon: <Award className="h-8 w-8 text-primary" />,
      title: "Integrity",
      description: "We operate with transparency and honesty in all our interactions with students and partners."
    },
    {
      icon: <Zap className="h-8 w-8 text-primary" />,
      title: "Practical Learning",
      description: "We believe in hands-on, practical learning experiences that prepare students for real-world challenges."
    },
    {
      icon: <Globe className="h-8 w-8 text-primary" />,
      title: "Global Perspective",
      description: "We prepare our students to succeed in a global marketplace with internationally relevant skills."
    }
  ];

  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="mb-8">
          <Link href="/about">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to About
            </Button>
          </Link>
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Our <GradientText>Mission & Values</GradientText></h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Learn about our purpose and the core values that drive everything we do
            </p>
          </div>
        </div>
        
        <Separator className="my-8" />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 my-16">
          <Card className="p-8 h-full">
            <h2 className="text-2xl font-bold mb-4">Our Mission</h2>
            <p className="text-gray-700 mb-6">
              At Codecrafters, our mission is to bridge the gap between theoretical knowledge and practical industry requirements through immersive, hands-on learning experiences.
            </p>
            <p className="text-gray-700 mb-6">
              We aim to empower individuals with the technical skills, problem-solving abilities, and professional mindset needed to thrive in the rapidly evolving technology landscape.
            </p>
            <p className="text-gray-700">
              By cultivating a community of lifelong learners and industry-ready professionals, we contribute to both individual career growth and the advancement of the tech industry as a whole.
            </p>
          </Card>
          
          <Card className="p-8 h-full">
            <h2 className="text-2xl font-bold mb-4">Our Vision</h2>
            <p className="text-gray-700 mb-6">
              We envision a future where quality tech education is accessible to all who seek it, regardless of their background or prior experience.
            </p>
            <p className="text-gray-700 mb-6">
              Codecrafters aims to be recognized globally as a premier destination for technology education and solutions, known for producing graduates who are not just job-ready but industry-leading.
            </p>
            <p className="text-gray-700">
              Through continuous innovation in our teaching methodologies and curriculum, we strive to stay ahead of industry trends and prepare our students for the technologies of tomorrow.
            </p>
          </Card>
        </div>
        
        <h2 className="text-3xl font-bold text-center mb-12">Our Core Values</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {values.map((value, index) => (
            <Card key={index} className="p-6 hover:shadow-md transition-all duration-300">
              <div className="mb-4">{value.icon}</div>
              <h3 className="text-xl font-bold mb-2">{value.title}</h3>
              <p className="text-gray-600">{value.description}</p>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
} 