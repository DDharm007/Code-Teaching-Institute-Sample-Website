import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { GradientText } from "@/components/ui/gradient-text";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function OurTeamPage() {
  // Team members data
  const teamMembers = [
    {
      name: "Ankit Patel",
      role: "Founder & CEO",
      bio: "With over 15 years of experience in IT and education, Ankit founded Codecrafters with a vision to bridge the gap between academic learning and industry requirements.",
      image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80"
    },
    {
      name: "Priya Sharma",
      role: "Training Director",
      bio: "Priya leads our training programs with her expertise in curriculum development and 10+ years of experience in technical education.",
      image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80"
    },
    {
      name: "Rajesh Kumar",
      role: "Technical Lead",
      bio: "A software architect with expertise in multiple technologies, Rajesh ensures our training content stays up-to-date with industry standards.",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80"
    },
    {
      name: "Meera Desai",
      role: "Placement Coordinator",
      bio: "Meera manages our internship programs and helps students connect with the right opportunities in the industry.",
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80"
    },
    {
      name: "Vikram Joshi",
      role: "Chief Technology Officer",
      bio: "With a background in enterprise solutions, Vikram oversees our technical infrastructure and consulting services.",
      image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80"
    },
    {
      name: "Aarti Singh",
      role: "Student Success Manager",
      bio: "Aarti works closely with students to ensure they receive the support they need throughout their learning journey.",
      image: "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80"
    }
  ];

  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="mb-8">
          <Link href="/about">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to About
            </Button>
          </Link>
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Our <GradientText>Team</GradientText></h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Meet the passionate professionals behind Codecrafters who are dedicated to transforming IT education
            </p>
          </div>
        </div>
        
        <Separator className="my-8" />
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
          {teamMembers.map((member, index) => (
            <Card key={index} className="overflow-hidden transition-all duration-300 hover:shadow-lg">
              <div className="aspect-square overflow-hidden">
                <img 
                  src={member.image} 
                  alt={member.name} 
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
              </div>
              <CardContent className="p-6">
                <h3 className="text-xl font-bold mb-1">{member.name}</h3>
                <p className="text-primary font-medium mb-3">{member.role}</p>
                <p className="text-gray-600">{member.bio}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
} 