import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { GradientText } from "@/components/ui/gradient-text";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft, Target, Lightbulb, GraduationCap, Building, Award, Star } from "lucide-react";

export default function OverviewPage() {
  // Core values
  const coreValues = [
    "Excellence in education and training",
    "Practical, hands-on learning approach",
    "Innovation in teaching methodologies",
    "Industry relevance in all programs",
    "Student success and career growth",
    "Community and collaborative learning"
  ];

  // Student success stories
  const successStories = [
    {
      name: "Rahul Verma",
      course: "Full Stack Development",
      company: "TechGiant Inc.",
      role: "Senior Developer",
      quote: "The hands-on projects at Codecrafters were exactly what I needed to bridge the gap between academic knowledge and industry requirements.",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80"
    },
    {
      name: "Sneha Patel",
      course: "Cloud Computing",
      company: "CloudNova",
      role: "Cloud Architect",
      quote: "The mentorship I received at Codecrafters helped me transition into cloud architecture with confidence and practical skills.",
      image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80"
    },
    {
      name: "Arjun Singh",
      course: "Cyber Security",
      company: "SecureShield",
      role: "Security Analyst",
      quote: "The real-world security scenarios we tackled in the program prepared me for actual challenges I face in my role every day.",
      image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=256&q=80"
    }
  ];

  // Facilities features
  const facilities = [
    {
      title: "Modern Classrooms",
      description: "Equipped with the latest technology, our classrooms provide an optimal learning environment."
    },
    {
      title: "Tech Labs",
      description: "Hands-on labs with industry-standard hardware and software for practical learning experiences."
    },
    {
      title: "Collaboration Spaces",
      description: "Dedicated areas for group projects, peer learning, and community building."
    },
    {
      title: "Resource Library",
      description: "Extensive digital and physical resources to support learning beyond the classroom."
    },
    {
      title: "Innovation Hub",
      description: "A space for students to experiment with emerging technologies and work on innovative projects."
    },
    {
      title: "Career Center",
      description: "Resources and support for job placement, interview preparation, and career development."
    }
  ];

  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="mb-8">
          <Link href="/about">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to About
            </Button>
          </Link>
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">About <GradientText>Codecrafters</GradientText></h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              A comprehensive overview of our company, mission, values, and approach to education
            </p>
          </div>
        </div>
        
        <Separator className="my-8" />
        
        {/* Mission and Vision */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Our Mission & Vision</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="p-8 h-full">
              <div className="flex items-center mb-4">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <Target className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-2xl font-bold">Our Mission</h3>
              </div>
              <p className="text-gray-700">
                At Codecrafters, our mission is to bridge the gap between theoretical knowledge and practical industry requirements through immersive, hands-on learning experiences. We aim to empower individuals with the technical skills, problem-solving abilities, and professional mindset needed to thrive in the rapidly evolving technology landscape.
              </p>
            </Card>
            
            <Card className="p-8 h-full">
              <div className="flex items-center mb-4">
                <div className="bg-blue-100 p-3 rounded-full mr-4">
                  <svg className="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </div>
                <h3 className="text-2xl font-bold">Our Vision</h3>
              </div>
              <p className="text-gray-700">
                We envision a future where quality tech education is accessible to all who seek it. Codecrafters aims to be recognized globally as a premier destination for technology education and solutions, known for producing graduates who are not just job-ready but industry-leading.
              </p>
            </Card>
          </div>
        </section>
        
        {/* Core Values */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Our Core Values</h2>
          <Card className="p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
              {coreValues.map((value, index) => (
                <div key={index} className="flex items-start">
                  <Star className="text-primary mr-3 mt-1 h-5 w-5 flex-shrink-0" />
                  <p className="text-gray-700">{value}</p>
                </div>
              ))}
            </div>
          </Card>
        </section>
        
        {/* Our Approach */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Our Educational Approach</h2>
          <Card className="overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="p-8">
                <div className="flex items-center mb-6">
                  <div className="bg-indigo-100 p-3 rounded-full mr-4">
                    <Lightbulb className="h-6 w-6 text-indigo-600" />
                  </div>
                  <h3 className="text-2xl font-bold">Learn by Doing</h3>
                </div>
                
                <p className="text-gray-700 mb-6">
                  Our educational philosophy centers on practical, hands-on learning. We believe that true mastery comes from applying knowledge to real-world scenarios.
                </p>
                
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <div className="bg-green-100 rounded-full p-1 mr-3 mt-1">
                      <svg className="h-4 w-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <p className="text-gray-700">Project-based curriculum with real-world applications</p>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-green-100 rounded-full p-1 mr-3 mt-1">
                      <svg className="h-4 w-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <p className="text-gray-700">Industry-partnered case studies and challenges</p>
                  </li>
                  <li className="flex items-start">
                    <div className="bg-green-100 rounded-full p-1 mr-3 mt-1">
                      <svg className="h-4 w-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <p className="text-gray-700">Practical labs and simulated work environments</p>
                  </li>
                </ul>
              </div>
              
              <div className="bg-gray-100 flex items-center justify-center">
                <img 
                  src="https://images.unsplash.com/photo-1522071901873-411886a10004?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                  alt="Students working on a project" 
                  className="object-cover h-full w-full"
                />
              </div>
            </div>
          </Card>
        </section>
        
        {/* Student Success Stories */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Student Success Stories</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {successStories.map((story, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                <div className="flex flex-col items-center pt-8 px-6">
                  <div className="w-24 h-24 rounded-full overflow-hidden mb-4 border-4 border-primary/10">
                    <img 
                      src={story.image} 
                      alt={story.name} 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="text-xl font-bold text-center">{story.name}</h3>
                  <p className="text-primary text-sm mb-1">{story.role}</p>
                  <p className="text-gray-500 text-sm mb-4">{story.company}</p>
                </div>
                
                <CardContent className="p-6 bg-gray-50 border-t">
                  <div className="mb-4 text-amber-500 flex justify-center">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-700 italic text-center">"{story.quote}"</p>
                  <p className="text-gray-500 text-sm text-center mt-3">{story.course} Program</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
        
        {/* Our Facilities */}
        <section>
          <h2 className="text-3xl font-bold mb-8 text-center">Our Facilities</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {facilities.map((facility, index) => (
              <Card key={index} className="hover:shadow-md transition-all duration-300">
                <CardContent className="p-6">
                  <div className="rounded-full bg-blue-100 w-12 h-12 flex items-center justify-center mb-4">
                    {index === 0 ? (
                      <Building className="h-6 w-6 text-blue-600" />
                    ) : index === 1 ? (
                      <svg className="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                      </svg>
                    ) : index === 2 ? (
                      <svg className="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                      </svg>
                    ) : index === 3 ? (
                      <svg className="h-6 w-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                      </svg>
                    ) : index === 4 ? (
                      <Lightbulb className="h-6 w-6 text-blue-600" />
                    ) : (
                      <GraduationCap className="h-6 w-6 text-blue-600" />
                    )}
                  </div>
                  <h3 className="text-xl font-bold mb-2">{facility.title}</h3>
                  <p className="text-gray-600">{facility.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
} 