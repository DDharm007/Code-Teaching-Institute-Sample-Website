import { useEffect } from "react";
import { useLocation } from "wouter";

export default function AdminContentRedirect() {
  const [, navigate] = useLocation();
  
  useEffect(() => {
    // Get any query parameters
    const urlParams = new URLSearchParams(window.location.search);
    const queryString = urlParams.toString();
    
    // Redirect to the new path with any query parameters
    navigate(`/admin/content${queryString ? `?${queryString}` : ''}`);
  }, [navigate]);
  
  return null;
} 