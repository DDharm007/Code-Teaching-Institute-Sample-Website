import { useState, useEffect } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { GradientText } from "@/components/ui/gradient-text";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, BookOpen, BriefcaseBusiness, GraduationCap, Mail, MessageSquare, Plus, Settings } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";

type ContactMessage = {
  id: number;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: string;
  emailSent: number;
  createdAt: string;
};

type InternshipApplication = {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  internshipType: string;
  coverLetter?: string;
  resumeUrl?: string;
  status: string;
  smsSent: number;
  createdAt: string;
};

export default function AdminDashboard() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("contacts");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    // Check authentication status when component mounts
    const auth = sessionStorage.getItem("adminAuthenticated");
    if (auth !== "true") {
      toast({
        title: "Authentication Required",
        description: "Please login to access the admin dashboard",
        variant: "destructive",
      });
      navigate("/admin-login");
    } else {
      setIsAuthenticated(true);
    }
  }, [navigate, toast]);

  // Handle logout
  const handleLogout = () => {
    sessionStorage.removeItem("adminAuthenticated");
    toast({
      title: "Logged Out",
      description: "You have been logged out successfully",
    });
    navigate("/admin-login");
  };

  // Fetch contact messages
  const {
    data: contactMessages,
    isLoading: isLoadingContacts,
    isError: isContactsError,
  } = useQuery<ContactMessage[]>({
    queryKey: ["/api/admin/contacts"],
    enabled: isAuthenticated,
  });

  // Fetch internship applications
  const {
    data: internshipApplications,
    isLoading: isLoadingApplications,
    isError: isApplicationsError,
  } = useQuery<InternshipApplication[]>({
    queryKey: ["/api/admin/internship-applications"],
    enabled: isAuthenticated,
  });

  // Update contact message status mutation
  const updateContactStatus = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => {
      return apiRequest("POST", `/api/admin/contact/${id}/status`, { status });
    },
    onSuccess: async () => {
      toast({
        title: "Status Updated",
        description: "Contact message status has been updated",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/contacts"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update contact status",
        variant: "destructive",
      });
    },
  });

  // Update internship application status mutation
  const updateInternshipStatus = useMutation({
    mutationFn: ({ id, status }: { id: number; status: string }) => {
      return apiRequest("POST", `/api/admin/internship/${id}/status`, { status });
    },
    onSuccess: async () => {
      toast({
        title: "Status Updated",
        description: "Internship application status has been updated",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/internship-applications"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update internship status",
        variant: "destructive",
      });
    },
  });

  // Handle contact status change
  const handleContactStatus = (id: number, status: string) => {
    updateContactStatus.mutate({ id, status });
  };

  // Handle internship status change
  const handleInternshipStatus = (id: number, status: string) => {
    updateInternshipStatus.mutate({ id, status });
  };

  // Get status badge variant
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case "accepted":
        return "success";
      case "rejected":
        return "destructive";
      default:
        return "default";
    }
  };

  if (!isAuthenticated) {
    return null; // Don't render anything while checking authentication
  }

  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="flex justify-between items-center mb-12">
          <h1 className="text-4xl font-bold">
            Admin <GradientText>Dashboard</GradientText>
          </h1>
          <div className="space-x-4 flex">
            <Button onClick={() => navigate("/admin/content")} size="lg" className="bg-blue-600 hover:bg-blue-700 font-semibold">
              Manage Website Content
            </Button>
            <Button variant="destructive" onClick={handleLogout}>Logout</Button>
          </div>
        </div>
        <p className="text-gray-600 max-w-2xl mb-8">
          Manage and view submissions from your website visitors
        </p>

        <Separator className="my-8" />

        <div className="mb-8 grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="hover:shadow-md transition-shadow border-blue-100">
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center">
                <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <Settings className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-bold mb-2">Site Settings</h3>
                <p className="text-gray-600 mb-4">Edit your logo, site name, and contact information</p>
                <Button onClick={() => navigate("/admin/content?tab=site-settings")} className="w-full bg-blue-600 hover:bg-blue-700">
                  Manage Settings
                </Button>
              </div>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-md transition-shadow border-blue-100">
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center">
                <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <MessageSquare className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-bold mb-2">Applications</h3>
                <p className="text-gray-600 mb-4">Review applications for internships and training programs</p>
                <Button onClick={() => navigate("/admin/content?tab=internship-applications")} className="w-full bg-blue-600 hover:bg-blue-700">
                  Manage Applications
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs
          defaultValue="contacts"
          value={activeTab}
          onValueChange={setActiveTab}
          className="w-full"
        >
          <TabsList className="grid w-full grid-cols-1 mb-8">
            <TabsTrigger value="contacts">Contact Messages</TabsTrigger>
          </TabsList>

          <TabsContent value="contacts">
            <Card>
              <CardHeader>
                <CardTitle>Contact Form Submissions</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingContacts || updateContactStatus.isPending ? (
                  <div className="flex justify-center p-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-primary"></div>
                  </div>
                ) : isContactsError ? (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>
                      Failed to load contact messages. Please try again later.
                    </AlertDescription>
                  </Alert>
                ) : contactMessages && contactMessages.length > 0 ? (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Subject</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {contactMessages.map((contact) => (
                          <TableRow key={contact.id}>
                            <TableCell>{contact.id}</TableCell>
                            <TableCell>{contact.name}</TableCell>
                            <TableCell>{contact.email}</TableCell>
                            <TableCell>{contact.subject}</TableCell>
                            <TableCell>
                              {new Date(contact.createdAt).toLocaleDateString()}
                            </TableCell>
                            <TableCell>
                              <Badge variant={getStatusBadgeVariant(contact.status)}>
                                {contact.status.charAt(0).toUpperCase() + contact.status.slice(1)}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="space-x-2">
                                <Button 
                                  size="sm" 
                                  variant="success"
                                  disabled={contact.status !== "pending"}
                                  onClick={() => handleContactStatus(contact.id, "accepted")}
                                >
                                  Accept
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="destructive"
                                  disabled={contact.status !== "pending"}
                                  onClick={() => handleContactStatus(contact.id, "rejected")}
                                >
                                  Reject
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="text-center p-8 text-gray-500">
                    No contact messages found
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
} 