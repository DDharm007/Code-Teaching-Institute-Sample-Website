import { useState, useEffect } from "react";
import AdminLayout from "@/components/admin/admin-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import {
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader,
  TableRow 
} from "@/components/ui/table";
import { ArrowLeft, Download, Mail, PhoneCall, Trash2 } from "lucide-react";

interface InternshipApplication {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  internshipType: string;
  coverLetter?: string;
  resumeUrl?: string;
  status: string;
  smsSent: boolean | number;
  createdAt: string;
}

export default function AcceptedInternshipsPage() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();

  // Check authentication
  useEffect(() => {
    const auth = sessionStorage.getItem("adminAuthenticated");
    if (auth !== "true") {
      toast({
        title: "Authentication Required",
        description: "Please login to access the admin dashboard",
        variant: "destructive",
      });
      navigate("/admin-login");
    }
  }, [navigate, toast]);

  // Fetch internship applications
  const { data: internshipApplications = [] as InternshipApplication[], isLoading } = useQuery({
    queryKey: ["internship-applications"],
    queryFn: async () => {
      try {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 300));
        
        // Retrieve applications from localStorage
        const storedApplications = localStorage.getItem('internshipApplications');
        const applications = storedApplications ? 
          JSON.parse(storedApplications) as InternshipApplication[] : 
          [];
          
        // Filter only accepted applications
        return applications.filter(app => app.status === 'accepted');
      } catch (error) {
        console.error("Error fetching internship applications:", error);
        return [] as InternshipApplication[];
      }
    }
  });
  
  // Format phone number for display (Indian format)
  const formatPhoneNumber = (phone: string) => {
    // Remove all non-digit characters
    const cleaned = phone.replace(/\D/g, '');
    
    // If the number doesn't start with country code, add +91
    const withCountryCode = cleaned.startsWith('91') 
      ? cleaned 
      : cleaned.length === 10 
        ? '91' + cleaned 
        : cleaned;
    
    // Format as +91 XXXXX XXXXX
    try {
      if (withCountryCode.length >= 12) {
        return `+${withCountryCode.slice(0, 2)} ${withCountryCode.slice(2, 7)} ${withCountryCode.slice(7)}`;
      } else if (withCountryCode.length >= 10) {
        return `+91 ${withCountryCode.slice(-10, -5)} ${withCountryCode.slice(-5)}`;
      }
      return `+91 ${phone}`; // Fallback
    } catch (error) {
      console.error("Error formatting phone number:", error);
      return phone; // Return original if formatting fails
    }
  };

  // Format date time for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  // Function to send WhatsApp message
  const sendWhatsAppMessage = (phoneNumber: string, message: string) => {
    // Remove any non-numeric characters from the phone number
    const cleanedNumber = phoneNumber.replace(/\D/g, "");
    
    // Format with Nigeria country code if needed (for non-Nigerian numbers, adjust as required)
    let formattedPhone = cleanedNumber;
    if (!cleanedNumber.startsWith("234")) {
      formattedPhone = `234${cleanedNumber}`;
    }
    
    // Encode the message for URL
    const encodedMessage = encodeURIComponent(message);
    
    // Log for debugging
    console.log(`Opening WhatsApp with phone: ${formattedPhone}`);
    console.log(`Message: ${encodedMessage.substring(0, 50)}...`);
    
    // Use https://api.whatsapp.com/send instead of wa.me for more consistent results
    const whatsappUrl = `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  // Function to delete an internship application
  const deleteApplication = (id: number) => {
    try {
      // Get applications from localStorage
      const storedApplications = localStorage.getItem('internshipApplications');
      if (!storedApplications) {
        toast({
          title: "Error",
          description: "No applications found",
          variant: "destructive"
        });
        return;
      }
      
      // Parse applications
      const applications = JSON.parse(storedApplications) as InternshipApplication[];
      
      // Filter out the deleted application
      const updatedApplications = applications.filter(app => app.id !== id);
      
      // Save back to localStorage
      localStorage.setItem('internshipApplications', JSON.stringify(updatedApplications));
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ["internship-applications"] });
      
      toast({
        title: "Application Deleted",
        description: "The application has been removed",
      });
    } catch (error) {
      console.error("Error deleting internship application:", error);
      toast({
        title: "Error",
        description: "Failed to delete application",
        variant: "destructive"
      });
    }
  };

  return (
    <AdminLayout title="Accepted Internship Applications">
      <div className="container py-6">
        <div className="flex justify-between items-center mb-6">
          <Button variant="ghost" onClick={() => navigate("/admin/content?tab=internship-applications")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Applications
          </Button>
          
          <Badge className="bg-green-600 text-white py-1 px-3">
            {internshipApplications.length} Accepted Applications
          </Badge>
        </div>
        
        {isLoading ? (
          <div className="py-8 text-center">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-2"></div>
            <p>Loading applications...</p>
          </div>
        ) : internshipApplications.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-gray-500">No accepted internship applications yet.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {internshipApplications.map((application) => (
              <Card key={application.id} className="overflow-hidden">
                <CardHeader className="bg-green-50 border-b">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle>{application.fullName}</CardTitle>
                      <CardDescription>{application.internshipType}</CardDescription>
                    </div>
                    <Badge className="bg-green-600">Accepted</Badge>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="font-semibold text-lg">Applicant Details</h3>
                      
                      <div className="grid grid-cols-1 gap-3">
                        <div>
                          <p className="text-sm text-gray-500">Email Address</p>
                          <div className="flex items-center mt-1">
                            <Mail className="h-4 w-4 mr-2 text-gray-400" />
                            <a href={`mailto:${application.email}`} className="text-blue-600 hover:underline">
                              {application.email}
                            </a>
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-500">Phone Number</p>
                          <div className="flex items-center mt-1">
                            <PhoneCall className="h-4 w-4 mr-2 text-gray-400" />
                            <a href={`tel:${application.phone}`} className="text-blue-600 hover:underline">
                              {formatPhoneNumber(application.phone)}
                            </a>
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-500">Application Date</p>
                          <p className="mt-1 font-medium">{formatDate(application.createdAt)}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="font-semibold text-lg">Cover Letter</h3>
                      <div className="bg-gray-50 p-4 rounded-md h-48 overflow-y-auto">
                        {application.coverLetter ? (
                          <p className="whitespace-pre-line">{application.coverLetter}</p>
                        ) : (
                          <p className="text-gray-400 italic">No cover letter provided</p>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-6 pt-4 border-t flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-500">Status</p>
                      <div className="flex items-center mt-1">
                        <Badge className="bg-green-600">Accepted</Badge>
                        <span className="ml-2 text-sm text-gray-500">
                          {application.smsSent ? "WhatsApp notification sent" : "WhatsApp notification pending"}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        onClick={() => {
                          // Create message
                          const message = `Hello ${application.fullName}, 
                          
I hope this message finds you well. We're reaching out regarding your internship application for the ${application.internshipType} position.

Is there a convenient time this week when we could schedule a call to discuss the internship details further?

Looking forward to your response!

Regards,
Codecrafters Team`;
                          
                          // Use the sendWhatsAppMessage function
                          sendWhatsAppMessage(application.phone, message);
                          
                          toast({
                            title: "WhatsApp Opening",
                            description: "Sending message to " + formatPhoneNumber(application.phone)
                          });
                        }}
                      >
                        <Mail className="mr-2 h-4 w-4" />
                        Contact Applicant
                      </Button>

                      <Button 
                        variant="ghost" 
                        className="text-red-500 hover:text-red-700 hover:bg-red-50"
                        onClick={() => {
                          if (window.confirm("Are you sure you want to delete this application?")) {
                            deleteApplication(application.id);
                          }
                        }}
                      >
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AdminLayout>
  );
} 