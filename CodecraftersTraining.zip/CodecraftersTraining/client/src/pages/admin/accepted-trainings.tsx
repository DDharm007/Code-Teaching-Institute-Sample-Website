import { useState, useEffect } from "react";
import AdminLayout from "@/components/admin/admin-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import {
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader,
  TableRow 
} from "@/components/ui/table";
import { ArrowLeft, BookOpen, Calendar, Mail, MessageSquare, PhoneCall, Pencil, Trash2, Phone } from "lucide-react";
import { trainingPrograms } from "@/lib/data";
import { Link } from "wouter";

interface TrainingApplication {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  programId: string;
  message?: string;
  status: string;
  emailSent?: boolean;
  createdAt: string;
}

type TrainingStatus = "PENDING" | "ACCEPTED" | "REJECTED" | "WAITLISTED";

const trainingStatusColors: Record<TrainingStatus, string> = {
  PENDING: "bg-yellow-200 text-yellow-800",
  ACCEPTED: "bg-green-200 text-green-800",
  REJECTED: "bg-red-200 text-red-800",
  WAITLISTED: "bg-blue-200 text-blue-800",
};

export default function AcceptedTrainingsPage() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();

  // Check authentication
  useEffect(() => {
    const auth = sessionStorage.getItem("adminAuthenticated");
    if (auth !== "true") {
      toast({
        title: "Authentication Required",
        description: "Please login to access the admin dashboard",
        variant: "destructive",
      });
      navigate("/admin-login");
    }
  }, [navigate, toast]);

  // Fetch training applications
  const { data: trainingApplications = [] as TrainingApplication[], isLoading } = useQuery({
    queryKey: ["training-applications"],
    queryFn: async () => {
      try {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 300));
        
        // Retrieve applications from localStorage
        const storedApplications = localStorage.getItem('trainingApplications');
        const applications = storedApplications ? 
          JSON.parse(storedApplications) as TrainingApplication[] : 
          [];
          
        // Filter only accepted applications
        return applications.filter(app => app.status === 'accepted');
      } catch (error) {
        console.error("Error fetching training applications:", error);
        return [] as TrainingApplication[];
      }
    }
  });
  
  // Format phone number for display
  const formatPhoneNumber = (phoneNumber: string) => {
    // Remove all non-digits
    const cleaned = phoneNumber.replace(/\D/g, '');
    
    // For Indian numbers, if it's 10 digits, format as +91 XXXXX XXXXX
    if (cleaned.length === 10) {
      return `+91 ${cleaned.slice(0, 5)} ${cleaned.slice(5)}`;
    }
    
    // If it's 12 digits and starts with 91, format as +91 XXXXX XXXXX
    if (cleaned.length === 12 && cleaned.startsWith('91')) {
      return `+${cleaned.slice(0, 2)} ${cleaned.slice(2, 7)} ${cleaned.slice(7)}`;
    }
    
    // Otherwise return original
    return phoneNumber;
  };

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Function to send WhatsApp message
  const sendWhatsAppMessage = (phoneNumber: string, message: string) => {
    // Remove any non-numeric characters from the phone number
    const cleanedNumber = phoneNumber.replace(/\D/g, "");
    
    // Format phone number with country code if needed
    let formattedPhone = cleanedNumber;
    if (!cleanedNumber.startsWith("91")) {
      formattedPhone = `91${cleanedNumber}`;
    }
    
    // Encode the message for URL - double encode to handle special characters better
    const encodedMessage = encodeURIComponent(message);
    
    // Log for debugging
    console.log(`Opening WhatsApp with phone: ${formattedPhone}`);
    console.log(`Message: ${encodedMessage.substring(0, 50)}...`);
    
    // Use https://api.whatsapp.com/send instead of wa.me for more consistent results
    const whatsappUrl = `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  // Get program details by ID
  const getProgramDetails = (programId: string) => {
    return trainingPrograms.find(program => program.id === programId) || {
      title: programId,
      description: "Training program",
      modules: [],
      tools: []
    };
  };

  // Delete training application
  const deleteApplication = (id: number) => {
    try {
      // Get applications from localStorage
      const storedApplications = localStorage.getItem('trainingApplications');
      if (!storedApplications) {
        toast({
          title: "Error",
          description: "No applications found",
          variant: "destructive"
        });
        return;
      }
      
      // Parse applications
      const applications = JSON.parse(storedApplications) as TrainingApplication[];
      
      // Filter out the deleted application
      const updatedApplications = applications.filter(app => app.id !== id);
      
      // Save back to localStorage
      localStorage.setItem('trainingApplications', JSON.stringify(updatedApplications));
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ["training-applications"] });
      
      toast({
        title: "Application Deleted",
        description: "The application has been removed",
      });
    } catch (error) {
      console.error("Error deleting training application:", error);
      toast({
        title: "Error",
        description: "Failed to delete application",
        variant: "destructive"
      });
    }
  };

  return (
    <AdminLayout title="Accepted Training Applications">
      <div className="container py-6">
        <div className="flex justify-between items-center mb-6">
          <Button variant="ghost" onClick={() => navigate("/admin/content?tab=training-applications")}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Applications
          </Button>
          
          <Badge className="bg-green-600 text-white py-1 px-3">
            {trainingApplications.length} Accepted Applications
          </Badge>
        </div>
        
        {isLoading ? (
          <div className="py-8 text-center">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full mx-auto mb-2"></div>
            <p>Loading applications...</p>
          </div>
        ) : trainingApplications.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center">
              <p className="text-gray-500">No accepted training applications yet.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {trainingApplications.map((application) => {
              const program = getProgramDetails(application.programId);
              
              return (
                <Card key={application.id} className="overflow-hidden">
                  <CardHeader className="bg-green-50 border-b">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{application.fullName}</CardTitle>
                        <CardDescription>{program.title}</CardDescription>
                      </div>
                      <Badge className="bg-green-600">Accepted</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h3 className="font-semibold text-lg">Applicant Details</h3>
                        
                        <div className="grid grid-cols-1 gap-3">
                          <div>
                            <p className="text-sm text-gray-500">Email Address</p>
                            <div className="flex items-center mt-1">
                              <Mail className="h-4 w-4 mr-2 text-gray-400" />
                              <a href={`mailto:${application.email}`} className="text-blue-600 hover:underline">
                                {application.email}
                              </a>
                            </div>
                          </div>
                          
                          <div>
                            <p className="text-sm text-gray-500">Phone Number</p>
                            <div className="flex items-center mt-1">
                              <PhoneCall className="h-4 w-4 mr-2 text-gray-400" />
                              <a href={`tel:${application.phone}`} className="text-blue-600 hover:underline">
                                {formatPhoneNumber(application.phone)}
                              </a>
                            </div>
                          </div>
                          
                          <div>
                            <p className="text-sm text-gray-500">Application Date</p>
                            <p className="mt-1 font-medium">{formatDate(application.createdAt)}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-4">
                        <h3 className="font-semibold text-lg">Program & Message</h3>
                        
                        <div>
                          <p className="text-sm text-gray-500">Program</p>
                          <div className="flex items-center mt-1">
                            <BookOpen className="h-4 w-4 mr-2 text-gray-400" />
                            <p className="font-medium">{program.title}</p>
                          </div>
                          <p className="text-sm text-gray-600 mt-1">{program.description}</p>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-500">Message from Applicant</p>
                          <div className="bg-gray-50 p-4 rounded-md mt-1 max-h-36 overflow-y-auto">
                            {application.message ? (
                              <p className="whitespace-pre-line">{application.message}</p>
                            ) : (
                              <p className="text-gray-400 italic">No message provided</p>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6">
                      <h3 className="font-semibold text-lg">Program Details</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                        <div>
                          <h4 className="font-medium text-gray-700">Modules</h4>
                          <ul className="mt-2 space-y-1">
                            {program.modules && program.modules.length > 0 ? program.modules.map((module, i) => (
                              <li key={i} className="flex items-start">
                                <span className="text-sm text-primary mr-2">•</span>
                                <span className="text-sm">{module}</span>
                              </li>
                            )) : (
                              <li className="text-gray-400 italic">No modules available</li>
                            )}
                          </ul>
                        </div>
                        
                        <div>
                          <h4 className="font-medium text-gray-700">Tools & Technologies</h4>
                          <div className="mt-2 flex flex-wrap gap-2">
                            {program.tools && program.tools.length > 0 ? program.tools.map((tool, i) => (
                              <span key={i} className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-full">
                                {tool}
                              </span>
                            )) : (
                              <span className="text-gray-400 italic">No tools available</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="mt-6 pt-4 border-t flex justify-between items-center">
                      <div>
                        <p className="text-sm text-gray-500">Status</p>
                        <div className="flex items-center mt-1">
                          <Badge className="bg-green-600">Accepted</Badge>
                          <span className="ml-2 text-sm text-gray-500">
                            {application.emailSent ? "WhatsApp notification sent" : "WhatsApp notification pending"}
                          </span>
                        </div>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          onClick={() => {
                            // Get course start date (example: 2 weeks from now)
                            const startDate = new Date();
                            startDate.setDate(startDate.getDate() + 14);
                            const formattedStartDate = startDate.toLocaleDateString('en-IN', {
                              day: '2-digit',
                              month: 'short',
                              year: 'numeric'
                            });
                            
                            // Create WhatsApp message
                            const message = `Hello ${application.fullName}, 
                            
I hope this message finds you well. We're reaching out regarding your training application for the ${program.title} program.

We're excited to inform you that your training program will begin on *${formattedStartDate}*.

Please prepare the following for your first session:
1. Laptop with recommended specifications
2. Valid ID proof for enrollment completion
3. Program fees payment (details to be shared separately)

Is there a convenient time this week when we could schedule a call to discuss further details?

Regards,
Codecrafters Team`;
                            
                            // Send WhatsApp message
                            sendWhatsAppMessage(application.phone, message);
                            
                            toast({
                              title: "WhatsApp Opening",
                              description: "Sending schedule to " + formatPhoneNumber(application.phone)
                            });
                          }}
                        >
                          <Calendar className="mr-2 h-4 w-4" />
                          Send Schedule
                        </Button>
                        
                        <Button 
                          variant="outline" 
                          onClick={() => {
                            // Create message
                            const message = `Hello ${application.fullName}, 
                            
I hope this message finds you well. We're reaching out regarding your training application for the ${program.title} program.

We'd like to provide you with information about your upcoming training program. Could you please confirm your availability for a quick call to discuss the details?

Thank you for choosing Codecrafters for your learning journey.

Regards,
Codecrafters Team`;
                            
                            // Send WhatsApp message
                            sendWhatsAppMessage(application.phone, message);

                            toast({
                              title: "WhatsApp Opening",
                              description: "Opening chat with " + formatPhoneNumber(application.phone)
                            });
                          }}
                        >
                          <Phone className="mr-2 h-4 w-4" />
                          Contact
                        </Button>

                        <Button 
                          variant="ghost" 
                          className="text-red-500 hover:text-red-700 hover:bg-red-50"
                          onClick={() => {
                            if (window.confirm("Are you sure you want to delete this application?")) {
                              deleteApplication(application.id);
                            }
                          }}
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </AdminLayout>
  );
} 