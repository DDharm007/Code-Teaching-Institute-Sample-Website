import { useState, useEffect } from "react";
import AdminLayout from "@/components/admin/admin-layout";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader,
  TableRow 
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import axios from "axios";
import { Edit, Trash2, Plus, Save, Image, GraduationCap, Briefcase, ArrowLeft, Upload, MessageSquare } from "lucide-react";
import { useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { getSiteSettings, updateSiteSetting, SiteSetting } from "@/lib/mock-api";

// Define types for our data
// Using the SiteSetting interface from mock-api.ts

// Remove training programs and internship positions interfaces
interface InternshipApplication {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  internshipType: string;
  createdAt: string;
  status: string;
}

interface TrainingApplication {
  id: number;
  fullName: string;
  email: string;
  phone: string;
  programId: string;
  createdAt: string;
  status: string;
  emailSent?: boolean;
  message?: string;
}

export default function AdminContentPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("site-settings");
  
  const [siteLogoUrl, setSiteLogoUrl] = useState("");
  const [siteName, setSiteName] = useState("");
  const [whatsappNumber, setWhatsappNumber] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [logoPreview, setLogoPreview] = useState("");

  // Check authentication
  useEffect(() => {
    const auth = sessionStorage.getItem("adminAuthenticated");
    if (auth !== "true") {
      toast({
        title: "Authentication Required",
        description: "Please login to access the admin dashboard",
        variant: "destructive",
      });
      navigate("/admin-login");
    }
  }, [navigate, toast]);
  
  // Check for tab parameter in URL
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const tabParam = urlParams.get("tab");
    if (tabParam && ["site-settings", "internship-applications", "training-applications"].includes(tabParam)) {
      setActiveTab(tabParam);
    }
  }, []);

  // Handle direct file upload for logo
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setSiteLogoUrl(result); // Store the entire data URL
      setLogoPreview(result);
      toast({
        title: "Logo Uploaded",
        description: "Your logo has been uploaded. Save changes to apply.",
      });
    };
    reader.readAsDataURL(file);
  };

  // Fetch site settings
  const { data: siteSettings = [], isLoading: isLoadingSettings } = useQuery({
    queryKey: ["site-settings"],
    queryFn: async () => {
      return await getSiteSettings();
      }
  });

  // Load initial values from site settings when data is available
  useEffect(() => {
    if (siteSettings && siteSettings.length > 0) {
      const siteNameSetting = siteSettings.find((s: SiteSetting) => s.key === "site_name");
      const logoSetting = siteSettings.find((s: SiteSetting) => s.key === "logo");
      const whatsappSetting = siteSettings.find((s: SiteSetting) => s.key === "whatsapp_number");

      if (siteNameSetting) setSiteName(siteNameSetting.value);
      if (logoSetting) {
        setSiteLogoUrl(logoSetting.value);
        setLogoPreview(logoSetting.value);
      }
      if (whatsappSetting) setWhatsappNumber(whatsappSetting.value);
    }
  }, [siteSettings]);

  // Create update site setting mutation
  const updateSiteSettingMutation = useMutation({
    mutationFn: async (data: { key: string; value: string }) => {
      return await updateSiteSetting(data.key, data.value);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["site-settings"] });
    }
  });

  // Fetch internship applications
  const { data: internshipApplications = [] as InternshipApplication[], isLoading: isLoadingInternshipApps } = useQuery({
    queryKey: ["internship-applications"],
    queryFn: async () => {
      try {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 300));
        
        // Retrieve applications from localStorage
        const storedApplications = localStorage.getItem('internshipApplications');
        return storedApplications ? JSON.parse(storedApplications) as InternshipApplication[] : [];
      } catch (error) {
        console.error("Error fetching internship applications:", error);
        return [] as InternshipApplication[];
      }
    }
  });

  // Fetch training applications
  const { data: trainingApplications = [] as TrainingApplication[], isLoading: isLoadingTrainingApps } = useQuery({
    queryKey: ["training-applications"],
    queryFn: async () => {
      try {
        // Simulate API delay
        await new Promise(resolve => setTimeout(resolve, 300));
        
        // Retrieve applications from localStorage
        const storedApplications = localStorage.getItem('trainingApplications');
        return storedApplications ? JSON.parse(storedApplications) as TrainingApplication[] : [];
      } catch (error) {
        console.error("Error fetching training applications:", error);
        return [] as TrainingApplication[];
      }
    }
  });

  // Handle site settings updates
  const handleSaveSettings = async () => {
    try {
      setIsSaving(true);
      
      // Update site name
      await updateSiteSettingMutation.mutateAsync({
        key: "site_name",
        value: siteName
      });
      
      // Update logo URL
      await updateSiteSettingMutation.mutateAsync({
        key: "logo",
        value: siteLogoUrl
      });
      
      // Update WhatsApp number
      await updateSiteSettingMutation.mutateAsync({
        key: "whatsapp_number",
        value: whatsappNumber
      });

      // Update WhatsApp link in the floating button if applicable
      const whatsappButton = document.querySelector('a[href^="https://wa.me/"]');
      if (whatsappButton && whatsappNumber) {
        // Format the number (remove spaces, +, etc.)
        const formattedNumber = whatsappNumber.replace(/\D/g, '');
        whatsappButton.setAttribute('href', `https://wa.me/${formattedNumber}`);
      }
      
      // Update site title if applicable
      document.title = siteName || "CodeCrafter";
      
      toast({
        title: "Settings Saved",
        description: "Your site settings have been updated successfully",
      });
    } catch (error) {
      toast({
        title: "Error Saving Settings",
        description: "There was a problem saving your settings. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSaving(false);
    }
  };

  // Handle internship application status
  const handleInternshipStatus = (id: number, status: string) => {
    try {
      // Get applications from localStorage
      const storedApplications = localStorage.getItem('internshipApplications');
      if (!storedApplications) {
      toast({
          title: "Error",
          description: "No applications found",
          variant: "destructive"
        });
        return;
      }
      
      // Parse applications
      const applications = JSON.parse(storedApplications) as InternshipApplication[];
      
      // Find the application
      const application = applications.find(app => app.id === id);
      if (!application) {
      toast({
          title: "Error",
          description: "Application not found",
          variant: "destructive"
        });
        return;
      }
      
      // Find and update the application
      const updatedApplications = applications.map(app => {
        if (app.id === id) {
          return { ...app, status };
        }
        return app;
      });
      
      // Save back to localStorage
        localStorage.setItem('internshipApplications', JSON.stringify(updatedApplications));
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ["internship-applications"] });
      
      // Send WhatsApp message
      const statusText = status === 'accepted' ? 'Accepted' : 'Rejected';
      // Format phone number for WhatsApp API (numbers only, with country code)
      const cleaned = application.phone.replace(/\D/g, '');
      const formattedPhone = cleaned.startsWith('91') 
        ? cleaned 
        : cleaned.length === 10 
          ? '91' + cleaned 
          : cleaned;
      
      // Create WhatsApp message
      const message = `Hello ${application.fullName}, 
      
Thank you for applying for the ${application.internshipType} internship at Codecrafters.

We are pleased to inform you that your application has been *${statusText}*.

${status === 'accepted' 
  ? 'Our HR team will contact you shortly with further details about the next steps.' 
  : 'We appreciate your interest and encourage you to apply for future opportunities.'
}

For any queries, please contact us at +91 9023362937.

Regards,
Codecrafters Team`;
      
      // URL encode the message
      const encodedMessage = encodeURIComponent(message);
      
      // Log for debugging
      console.log(`Opening WhatsApp with phone: ${formattedPhone}`);
      console.log(`Message: ${encodedMessage.substr(0, 50)}...`);
      
      // Open WhatsApp with wa.me format
      const whatsappUrl = `https://wa.me/${formattedPhone}?text=${encodedMessage}`;
      window.open(whatsappUrl, '_blank');
      
      toast({
        title: "Status Updated",
        description: `Application ${statusText} and WhatsApp message sent`,
      });
    } catch (error) {
      console.error("Error updating internship status:", error);
      toast({
        title: "Error",
        description: "Failed to update application status",
        variant: "destructive"
      });
    }
  };

  // Handle training application status
  const handleTrainingStatus = (id: number, status: string) => {
    try {
      // Get applications from localStorage
      const storedApplications = localStorage.getItem('trainingApplications');
      if (!storedApplications) {
        toast({
          title: "Error",
          description: "No applications found",
          variant: "destructive"
        });
        return;
      }
      
      // Parse applications
      const applications = JSON.parse(storedApplications) as TrainingApplication[];
      
      // Find the application
      const application = applications.find(app => app.id === id);
      if (!application) {
      toast({
          title: "Error",
          description: "Application not found",
          variant: "destructive"
        });
        return;
      }
      
      // Find and update the application
      const updatedApplications = applications.map(app => {
        if (app.id === id) {
          return { ...app, status };
        }
        return app;
  });

      // Save back to localStorage
      localStorage.setItem('trainingApplications', JSON.stringify(updatedApplications));
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ["training-applications"] });
      
      // Send WhatsApp message
      const statusText = status === 'accepted' ? 'Accepted' : 'Rejected';
      // Format phone number for WhatsApp API (numbers only, with country code)
      const cleaned = application.phone.replace(/\D/g, '');
      const formattedPhone = cleaned.startsWith('91') 
        ? cleaned 
        : cleaned.length === 10 
          ? '91' + cleaned 
          : cleaned;
      
      // Create WhatsApp message
      const message = `Hello ${application.fullName}, 
      
Thank you for applying for the ${application.programId} training program at Codecrafters.

We are pleased to inform you that your application has been *${statusText}*.

${status === 'accepted' 
  ? 'Our team will contact you shortly with further details about the program schedule and payment details.' 
  : 'We appreciate your interest and encourage you to apply for future opportunities.'
}

For any queries, please contact us at +91 9023362937.

Regards,
Codecrafters Team`;
      
      // URL encode the message
      const encodedMessage = encodeURIComponent(message);
      
      // Log for debugging
      console.log(`Opening WhatsApp with phone: ${formattedPhone}`);
      console.log(`Message: ${encodedMessage.substr(0, 50)}...`);
      
      // Open WhatsApp with wa.me format
      const whatsappUrl = `https://wa.me/${formattedPhone}?text=${encodedMessage}`;
      window.open(whatsappUrl, '_blank');
      
      toast({
        title: "Status Updated",
        description: `Application ${statusText} and WhatsApp message sent`,
      });
    } catch (error) {
      console.error("Error updating training status:", error);
      toast({
        title: "Error",
        description: "Failed to update application status",
        variant: "destructive"
      });
    }
  };

  // Format phone number for display (Indian format)
  const formatPhoneNumber = (phone: string) => {
    // Remove all non-digit characters
    const cleaned = phone.replace(/\D/g, '');
    
    // If the number doesn't start with country code, add +91
    const withCountryCode = cleaned.startsWith('91') 
      ? cleaned 
      : cleaned.length === 10 
        ? '91' + cleaned 
        : cleaned;
      
    // Format as +91 XXXXX XXXXX
    try {
      if (withCountryCode.length >= 12) {
        return `+${withCountryCode.slice(0, 2)} ${withCountryCode.slice(2, 7)} ${withCountryCode.slice(7)}`;
      } else if (withCountryCode.length >= 10) {
        return `+91 ${withCountryCode.slice(-10, -5)} ${withCountryCode.slice(-5)}`;
      }
      return `+91 ${phone}`; // Fallback
    } catch (error) {
      console.error("Error formatting phone number:", error);
      return phone; // Return original if formatting fails
    }
  };
    
  // Delete internship application (but don't delete if status is 'accepted')
  const handleDeleteInternshipApplication = (id: number) => {
    try {
      // Get applications from localStorage
      const storedApplications = localStorage.getItem('internshipApplications');
      if (!storedApplications) {
      toast({
          title: "Error",
          description: "No applications found",
          variant: "destructive"
        });
        return;
    }
      
      // Parse applications
      const applications = JSON.parse(storedApplications) as InternshipApplication[];
      
      // Find the application
      const application = applications.find(app => app.id === id);
      if (!application) {
        toast({
          title: "Error",
          description: "Application not found",
          variant: "destructive"
        });
        return;
      }
      
      // Do not delete if the application is already accepted - show warning instead
      if (application.status === 'accepted') {
        toast({
          title: "Cannot Delete",
          description: "Accepted applications can only be deleted from the Accepted Applications page",
          variant: "destructive"
        });
        return;
      }
      
      // Filter out the deleted application
      const updatedApplications = applications.filter(app => app.id !== id);
        
      // Save back to localStorage
      localStorage.setItem('internshipApplications', JSON.stringify(updatedApplications));
      
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ["internship-applications"] });
        
        toast({
        title: "Application Deleted",
        description: "The application has been removed",
      });
    } catch (error) {
      console.error("Error deleting internship application:", error);
      toast({
        title: "Error",
        description: "Failed to delete application",
        variant: "destructive"
        });
      }
  };
  
  // Delete training application (but don't delete if status is 'accepted')
  const handleDeleteTrainingApplication = (id: number) => {
    try {
      // Get applications from localStorage
      const storedApplications = localStorage.getItem('trainingApplications');
      if (!storedApplications) {
        toast({
          title: "Error",
          description: "No applications found",
          variant: "destructive"
        });
        return;
      }
      
      // Parse applications
      const applications = JSON.parse(storedApplications) as TrainingApplication[];
      
      // Find the application
      const application = applications.find(app => app.id === id);
      if (!application) {
        toast({
          title: "Error",
          description: "Application not found",
          variant: "destructive"
        });
        return;
    }
    
      // Do not delete if the application is already accepted - show warning instead
      if (application.status === 'accepted') {
        toast({
          title: "Cannot Delete",
          description: "Accepted applications can only be deleted from the Accepted Applications page",
          variant: "destructive"
        });
        return;
      }
      
      // Filter out the deleted application
      const updatedApplications = applications.filter(app => app.id !== id);
      
      // Save back to localStorage
      localStorage.setItem('trainingApplications', JSON.stringify(updatedApplications));
        
      // Refresh data
      queryClient.invalidateQueries({ queryKey: ["training-applications"] });
        
        toast({
        title: "Application Deleted",
        description: "The application has been removed",
      });
    } catch (error) {
      console.error("Error deleting training application:", error);
      toast({
        title: "Error",
        description: "Failed to delete application",
        variant: "destructive"
        });
      }
  };

  // Function to send WhatsApp message
  const sendWhatsAppMessage = (phoneNumber: string, message: string) => {
    // Remove any non-numeric characters from the phone number
    const cleanedNumber = phoneNumber.replace(/\D/g, "");
    
    // Format with Nigeria country code if needed
    let formattedPhone = cleanedNumber;
    if (!cleanedNumber.startsWith("234")) {
      formattedPhone = `234${cleanedNumber}`;
    }
    
    // Encode the message for URL
    const encodedMessage = encodeURIComponent(message);
    
    // Log for debugging
    console.log(`Opening WhatsApp with phone: ${formattedPhone}`);
    console.log(`Message: ${encodedMessage.substring(0, 50)}...`);
    
    // Use https://api.whatsapp.com/send instead of wa.me for more consistent results
    const whatsappUrl = `https://api.whatsapp.com/send?phone=${formattedPhone}&text=${encodedMessage}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <AdminLayout title="Content Management">
      <div className="container py-6">
        <Tabs 
          value={activeTab} 
          onValueChange={setActiveTab}
          className="space-y-4"
        >
          <TabsList className="grid w-full grid-cols-1 md:grid-cols-3">
            <TabsTrigger value="site-settings">
              Site Settings
            </TabsTrigger>
            {/* Removed training-programs and internship-positions tabs */}
            <TabsTrigger value="internship-applications">
              Internship Applications
            </TabsTrigger>
            <TabsTrigger value="training-applications">
              Training Applications
            </TabsTrigger>
          </TabsList>
          
          {/* Site Settings Tab */}
          <TabsContent value="site-settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Site Settings</CardTitle>
                <CardDescription>
                  Configure your website settings and appearance
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {isLoadingSettings ? (
                  <div className="py-8 text-center">Loading settings...</div>
                ) : (
                  <>
                <div className="space-y-2">
                  <Label htmlFor="siteName">Site Name</Label>
                    <Input 
                    id="siteName" 
                        placeholder="Codecrafters" 
                    value={siteName}
                    onChange={(e) => setSiteName(e.target.value)}
                    />
                  </div>
                
                <div className="space-y-2">
                      <Label htmlFor="logo">Logo</Label>
                      
                      {/* Logo upload and preview section */}
                      <div className="border rounded-md p-4 flex flex-col items-center justify-center">
                        {logoPreview ? (
                          <div className="mb-4 relative group">
                            <img 
                              src={logoPreview} 
                              alt="Logo Preview" 
                              className="h-16 object-contain mx-auto"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.src = 'https://placehold.co/200x60?text=Logo+Preview';
                              }}
                            />
                            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded">
                              <p className="text-white text-xs">Click below to change</p>
                    </div>
                </div>
                ) : (
                          <div className="w-full h-20 bg-gray-100 flex items-center justify-center rounded mb-4">
                            <p className="text-gray-400">No logo uploaded</p>
                          </div>
                        )}
                        
                        <label 
                          htmlFor="content-logo-upload" 
                          className="flex items-center gap-2 py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 cursor-pointer transition-colors"
                        >
                          <Upload className="h-4 w-4" />
                          {logoPreview ? "Change Logo" : "Upload Logo"}
                        </label>
                        <input 
                          id="content-logo-upload" 
                          type="file" 
                          accept="image/*" 
                          className="hidden" 
                          onChange={handleFileUpload}
                        />
                        <p className="text-xs text-gray-500 mt-2">Upload your logo image directly from your device</p>
                      </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="whatsappNumber">WhatsApp Number</Label>
                  <Input 
                    id="whatsappNumber" 
                        placeholder="+91 90233 62937" 
                    value={whatsappNumber}
                    onChange={(e) => setWhatsappNumber(e.target.value)}
                  />
                      <p className="text-xs text-gray-500">This number will be used for the WhatsApp contact button</p>
                </div>
                
                  <Button 
                    onClick={handleSaveSettings}
                      className="w-full"
                      disabled={isSaving}
                  >
                      {isSaving ? (
                        <>
                          <div className="animate-spin h-4 w-4 mr-2 border-2 border-t-transparent rounded-full"></div>
                          Saving...
                        </>
                      ) : (
                        <>
                    <Save className="mr-2 h-4 w-4" />
                          Save Settings
                        </>
                      )}
                  </Button>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Removed training-programs and internship-positions tabs content */}
          
          {/* Internship Applications Tab */}
          <TabsContent value="internship-applications" className="space-y-4">
            <Card>
              <CardHeader>
                    <CardTitle>Internship Applications</CardTitle>
                  <CardDescription>
                  Manage applications for internship positions
                  </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-end mb-4">
                              <Button 
                    onClick={() => navigate("/admin/accepted-internships")}
                    variant="outline" 
                    className="border-green-500 text-green-600 hover:bg-green-50"
                  >
                    <Badge className="mr-2 bg-green-500">
                      {internshipApplications.filter(app => app.status === 'accepted').length}
                    </Badge>
                    View Accepted Applications
                              </Button>
                            </div>
                    <Table>
                  <TableCaption>
                    {internshipApplications.length === 0 ? "No applications yet" : `A list of your internship applications`}
                  </TableCaption>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Phone</TableHead>
                          <TableHead>Position</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                    {internshipApplications.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center">
                          No applications received yet
                            </TableCell>
                      </TableRow>
                    ) : (
                      internshipApplications.map((app) => (
                        <TableRow key={app.id}>
                          <TableCell>{app.fullName}</TableCell>
                          <TableCell>{app.email}</TableCell>
                          <TableCell>{formatPhoneNumber(app.phone)}</TableCell>
                          <TableCell>{app.internshipType}</TableCell>
                            <TableCell>
                            <div className="flex items-center gap-2">
                              <select 
                                value={app.status}
                                onChange={(e) => handleInternshipStatus(app.id, e.target.value)}
                                className="p-1 border rounded text-sm bg-transparent"
                              >
                                <option value="pending" disabled={app.status === 'accepted' || app.status === 'rejected'}>Pending</option>
                                <option value="accepted">Accept</option>
                                <option value="rejected">Reject</option>
                              </select>
                              {app.status === 'accepted' && (
                                <Badge className="bg-green-500">Accepted</Badge>
                              )}
                              {app.status === 'rejected' && (
                                <Badge className="bg-red-500">Rejected</Badge>
                              )}
                            </div>
                            </TableCell>
                            <TableCell>
                            {new Date(app.createdAt).toLocaleDateString()}
                            </TableCell>
                          <TableCell className="text-right">
                                <Button 
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteInternshipApplication(app.id)}
                                >
                              <Trash2 className="h-4 w-4 text-red-500" />
                                </Button>
                            </TableCell>
                          </TableRow>
                      ))
                    )}
                      </TableBody>
                    </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Training Applications Tab */}
          <TabsContent value="training-applications" className="space-y-4">
            <Card>
              <CardHeader>
                    <CardTitle>Training Applications</CardTitle>
                <CardDescription>
                  Manage applications for training programs
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-end mb-4">
                  <Button 
                    onClick={() => navigate("/admin/accepted-trainings")}
                    variant="outline" 
                    className="border-green-500 text-green-600 hover:bg-green-50"
                  >
                    <Badge className="mr-2 bg-green-500">
                      {trainingApplications.filter(app => app.status === 'accepted').length}
                    </Badge>
                    View Accepted Applications
                  </Button>
                  </div>
                    <Table>
                  <TableCaption>
                    {trainingApplications.length === 0 ? "No applications yet" : `A list of your training applications`}
                  </TableCaption>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Phone</TableHead>
                          <TableHead>Program</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                    {trainingApplications.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} className="text-center">
                          No applications received yet
                              </TableCell>
                      </TableRow>
                    ) : (
                      trainingApplications.map((app) => (
                        <TableRow key={app.id}>
                          <TableCell>{app.fullName}</TableCell>
                          <TableCell>{app.email}</TableCell>
                          <TableCell>{formatPhoneNumber(app.phone)}</TableCell>
                          <TableCell>{app.programId}</TableCell>
                              <TableCell>
                            <div className="flex items-center gap-2">
                              <select 
                                value={app.status}
                                onChange={(e) => handleTrainingStatus(app.id, e.target.value)}
                                className="p-1 border rounded text-sm bg-transparent"
                              >
                                <option value="pending" disabled={app.status === 'accepted' || app.status === 'rejected'}>Pending</option>
                                <option value="accepted">Accept</option>
                                <option value="rejected">Reject</option>
                              </select>
                              {app.status === 'accepted' && (
                                <Badge className="bg-green-500">Accepted</Badge>
                              )}
                              {app.status === 'rejected' && (
                                <Badge className="bg-red-500">Rejected</Badge>
                              )}
                            </div>
                              </TableCell>
                              <TableCell>
                            {new Date(app.createdAt).toLocaleDateString()}
                              </TableCell>
                          <TableCell className="text-right">
                                  <Button 
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDeleteTrainingApplication(app.id)}
                                  >
                              <Trash2 className="h-4 w-4 text-red-500" />
                                  </Button>
                              </TableCell>
                            </TableRow>
                      ))
                    )}
                      </TableBody>
                    </Table>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AdminLayout>
  );
} 