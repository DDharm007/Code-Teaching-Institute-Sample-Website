import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import AdminLayout from "@/components/admin/admin-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Save, Upload } from "lucide-react";
import { getSiteSettings, updateSiteSetting, SiteSetting } from "@/lib/mock-api";
import { Textarea } from "@/components/ui/textarea";
import { useSiteSettings } from "@/contexts/site-settings-context";

export default function SiteSettingsPage() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { refresh: refreshSiteSettings } = useSiteSettings();
  
  const [siteLogoUrl, setSiteLogoUrl] = useState("");
  const [siteName, setSiteName] = useState("");
  const [whatsappNumber, setWhatsappNumber] = useState("");
  const [isSaving, setIsSaving] = useState(false);
  const [logoPreview, setLogoPreview] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");

  // Handle file upload for logo - directly store as data URL
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setSiteLogoUrl(result); // Store the entire data URL
      setLogoPreview(result);
      toast({
        title: "Logo Uploaded",
        description: "Your logo has been uploaded. Save changes to apply.",
      });
    };
    reader.readAsDataURL(file);
  };

  // Check authentication
  useEffect(() => {
    const auth = sessionStorage.getItem("adminAuthenticated");
    if (auth !== "true") {
      toast({
        title: "Authentication Required",
        description: "Please login to access the admin dashboard",
        variant: "destructive",
      });
      navigate("/admin-login");
    }
  }, [navigate, toast]);

  // Fetch site settings
  const { data: siteSettings = [], isLoading: isLoadingSettings } = useQuery({
    queryKey: ["site-settings"],
    queryFn: async () => {
      return await getSiteSettings();
    }
  });

  // Set initial values from fetched settings
  useEffect(() => {
    if (siteSettings && siteSettings.length > 0) {
        const logoSetting = siteSettings.find((s: SiteSetting) => s.key === "logo");
        const nameSetting = siteSettings.find((s: SiteSetting) => s.key === "site_name");
        const whatsappSetting = siteSettings.find((s: SiteSetting) => s.key === "whatsapp_number");
      const phoneSetting = siteSettings.find((s: SiteSetting) => s.key === "phone");
      const emailSetting = siteSettings.find((s: SiteSetting) => s.key === "email");
      const addressSetting = siteSettings.find((s: SiteSetting) => s.key === "address");
        
      if (logoSetting) {
        setSiteLogoUrl(logoSetting.value);
        setLogoPreview(logoSetting.value);
      }
        if (nameSetting) setSiteName(nameSetting.value);
        if (whatsappSetting) setWhatsappNumber(whatsappSetting.value);
      if (phoneSetting) setPhoneNumber(phoneSetting.value);
      if (emailSetting) setEmail(emailSetting.value);
      if (addressSetting) setAddress(addressSetting.value);
    }
  }, [siteSettings]);

  // Update site setting mutation
  const updateSiteSettingMutation = useMutation({
    mutationFn: async (data: { key: string; value: string }) => {
      return await updateSiteSetting(data.key, data.value);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["site-settings"] });
    }
  });

  const handleSaveSettings = async () => {
    try {
      setIsSaving(true);
      
      // Update logo
      await updateSiteSettingMutation.mutateAsync({
        key: "logo",
        value: siteLogoUrl
      });
      
      // Update site name
      await updateSiteSettingMutation.mutateAsync({
        key: "site_name",
        value: siteName
      });
      
      // Update WhatsApp number
      await updateSiteSettingMutation.mutateAsync({
        key: "whatsapp_number",
        value: whatsappNumber
      });
      
      // Update phone number
      await updateSiteSettingMutation.mutateAsync({
        key: "phone",
        value: phoneNumber
      });
      
      // Update email
      await updateSiteSettingMutation.mutateAsync({
        key: "email",
        value: email
      });
      
      // Update address
      await updateSiteSettingMutation.mutateAsync({
        key: "address",
        value: address
      });
      
      // Refresh site settings context
      await refreshSiteSettings();
      
      toast({
        title: "Settings Updated",
        description: "Your site settings have been updated successfully."
      });
    } catch (error) {
      console.error("Error saving settings:", error);
      toast({
        title: "Error Saving Settings",
        description: "There was a problem saving your settings. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <AdminLayout title="Site Settings">
      <div className="p-6">
        <Button 
          variant="outline" 
          className="mb-6"
          onClick={() => navigate("/admin/content")}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Content Management
        </Button>

        <Card>
          <CardHeader>
            <CardTitle>Site Settings</CardTitle>
            <CardDescription>
              Manage your website's general settings like logo, site name, and contact information.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {isLoadingSettings ? (
              <div className="flex justify-center p-8">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-primary"></div>
              </div>
            ) : (
              <>
                <div className="space-y-2">
                  <Label htmlFor="logo">Logo</Label>
                  
                  {/* Logo upload and preview section */}
                  <div className="border rounded-md p-4">
                    <div className="flex flex-col items-center justify-center">
                      {logoPreview ? (
                        <div className="mb-4 relative group bg-white p-4 rounded-md shadow-sm">
                          <div className="flex items-center justify-center">
                            <img 
                              src={logoPreview} 
                              alt="Logo Preview" 
                              className="h-16 object-contain"
                              onError={(e) => {
                                const target = e.target as HTMLImageElement;
                                target.src = 'https://placehold.co/200x60?text=Logo+Preview';
                              }}
                            />
                            <span className="text-xl font-bold ml-2">{siteName}</span>
                          </div>
                          <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded">
                            <p className="text-white text-xs">Click below to change</p>
                          </div>
                        </div>
                      ) : (
                        <div className="w-full px-4 py-6 bg-gray-50 flex items-center justify-center rounded mb-4 border border-dashed border-gray-300">
                          <div className="flex items-center">
                            <div className="h-12 w-12 rounded-md bg-[#4285F4] flex items-center justify-center mr-3">
                              <span className="text-white font-bold text-lg">CC</span>
                            </div>
                            <span className="text-xl font-bold">{siteName || "CodeCrafter"}</span>
                          </div>
                        </div>
                      )}
                      
                    <label 
                        htmlFor="logo-upload" 
                        className="flex items-center gap-2 py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 cursor-pointer transition-colors"
                    >
                        <Upload className="h-4 w-4" />
                        {logoPreview ? "Change Logo" : "Upload Logo"}
                    </label>
                    <input 
                        id="logo-upload" 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={handleFileUpload}
                    />
                      <p className="text-xs text-gray-500 mt-2">Upload your logo image directly from your device</p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="siteName">Site Name</Label>
                  <Input 
                    id="siteName" 
                    placeholder="Enter your site name" 
                    value={siteName}
                    onChange={(e) => setSiteName(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="whatsappNumber">WhatsApp Number</Label>
                  <Input 
                    id="whatsappNumber" 
                    placeholder="Enter your WhatsApp number with country code (e.g. +91xxxxxxxxxx)" 
                    value={whatsappNumber}
                    onChange={(e) => setWhatsappNumber(e.target.value)}
                  />
                  <p className="text-xs text-gray-500">This number will be used for the WhatsApp contact button</p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phoneNumber">Phone Number</Label>
                  <Input 
                    id="phoneNumber" 
                    placeholder="Enter your phone number with country code (e.g. +91xxxxxxxxxx)" 
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                  />
                  <p className="text-xs text-gray-500">This number will be displayed in contact information</p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input 
                    id="email" 
                    type="email"
                    placeholder="Enter your contact email address" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                  <p className="text-xs text-gray-500">This email will be displayed in contact information</p>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="address">Office Address</Label>
                  <Textarea 
                    id="address" 
                    placeholder="Enter your full office address" 
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    rows={4}
                  />
                  <p className="text-xs text-gray-500">This address will be displayed in the footer</p>
                </div>
                
                  <Button 
                    onClick={handleSaveSettings}
                  disabled={isSaving}
                  className="w-full"
                >
                  {isSaving ? (
                    <>
                      <div className="animate-spin h-4 w-4 mr-2 border-2 border-t-transparent rounded-full"></div>
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="h-4 w-4 mr-2" />
                      Save Settings
                    </>
                  )}
                  </Button>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
} 