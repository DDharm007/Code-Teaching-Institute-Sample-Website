import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle, ArrowRight, CheckCircle } from "lucide-react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation, useSearch } from "wouter";
// Direct imports of data
import { internships, trainingPrograms } from "@/lib/data";

const internshipSchema = z.object({
  fullName: z.string().min(2, { message: "Full name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  phone: z.string().min(10, { message: "Please enter a valid phone number" }),
  internshipType: z.string().min(1, { message: "Please select an internship type" }),
  coverLetter: z.string().optional(),
});

const trainingSchema = z.object({
  fullName: z.string().min(2, { message: "Full name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  phone: z.string().min(10, { message: "Please enter a valid phone number" }),
  programId: z.string().min(1, { message: "Please select a program" }),
  message: z.string().optional(),
});

type InternshipFormValues = z.infer<typeof internshipSchema>;
type TrainingFormValues = z.infer<typeof trainingSchema>;

export default function ApplyPage() {
  const [activeTab, setActiveTab] = useState<string>("internship");
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [location] = useLocation();
  const searchParams = useSearch();
  const params = new URLSearchParams(searchParams);
  const programParam = params.get("program");
  const internshipParam = params.get("internship");
  
  // Debug available data
  useEffect(() => {
    console.log("Debug - Internships:", internships);
    console.log("Debug - Training Programs:", trainingPrograms);
  }, []);
  
  // Add these additional positions for testing and demonstration
  const additionalInternships = [
    { id: 5, title: "UI/UX Design Internship", duration: "3 Months", type: "Remote" },
    { id: 6, title: "Cloud DevOps Internship", duration: "4 Months", type: "Remote" },
    { id: 7, title: "Product Management Internship", duration: "6 Months", type: "Hybrid" },
  ];

  // Combine original internships with any additional ones
  const allInternships = [...internships, ...additionalInternships];

  // Set active tab based on URL
  useEffect(() => {
    if (location.includes("/apply/internship")) {
      setActiveTab("internship");
    } else if (location.includes("/apply/training")) {
      setActiveTab("training");
    }
  }, [location]);

  // Internship Application Form
  const internshipForm = useForm<InternshipFormValues>({
    resolver: zodResolver(internshipSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      internshipType: "",
      coverLetter: "",
    },
  });

  // Training Application Form
  const trainingForm = useForm<TrainingFormValues>({
    resolver: zodResolver(trainingSchema),
    defaultValues: {
      fullName: "",
      email: "",
      phone: "",
      programId: "",
      message: "",
    },
  });

  // Set form values when URL params are present
  useEffect(() => {
    console.log("URL parameters changed:", { internshipParam, programParam });
    
    if (internshipParam) {
      console.log("Looking for internship:", internshipParam);
      const position = allInternships.find((p) => p.title === internshipParam);
      console.log("Found position:", position);
      if (position) {
        console.log("Setting internship type to:", position.title);
        internshipForm.setValue("internshipType", position.title);
        setActiveTab("internship");
      }
    }
    
    if (programParam) {
      console.log("Looking for program:", programParam);
      const program = trainingPrograms.find((p) => p.id === programParam);
      console.log("Found program:", program);
      if (program) {
        console.log("Setting program ID to:", program.id);
        trainingForm.setValue("programId", program.id);
        setActiveTab("training");
      }
    }
  }, [internshipParam, programParam, internshipForm, trainingForm]);

  const handleInternshipSubmit = async (data: InternshipFormValues) => {
    try {
      setErrorMessage(null);
      // Mock API submission - log the data and return success
      console.log("Submitting internship application:", data);
      
      // Save to local storage for admin page to retrieve
      const existingApplications = JSON.parse(localStorage.getItem('internshipApplications') || '[]');
      const newApplication = {
        id: existingApplications.length + 1,
        fullName: data.fullName,
        email: data.email,
        phone: data.phone,
        internshipType: data.internshipType,
        coverLetter: data.coverLetter || "",
        resumeUrl: "",
        status: "pending",
        smsSent: false,
        createdAt: new Date().toISOString(),
      };
      existingApplications.push(newApplication);
      localStorage.setItem('internshipApplications', JSON.stringify(existingApplications));
      
      // Simulate a successful response
      setTimeout(() => {
        setSuccessMessage("Your internship application has been submitted successfully! We'll get back to you soon.");
        internshipForm.reset();
        window.scrollTo({ top: 0, behavior: "smooth" });
      }, 500);
      
    } catch (error: any) {
      console.error("Error submitting internship application:", error);
      setErrorMessage("Failed to submit your application. Please try again.");
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handleTrainingSubmit = async (data: TrainingFormValues) => {
    try {
      setErrorMessage(null);
      // Mock API submission - log the data and return success
      console.log("Submitting training application:", data);
      
      // Save to local storage for admin page to retrieve
      const existingApplications = JSON.parse(localStorage.getItem('trainingApplications') || '[]');
      const newApplication = {
        id: existingApplications.length + 1,
        fullName: data.fullName,
        email: data.email,
        phone: data.phone,
        programId: data.programId,
        message: data.message || "",
        status: "pending",
        emailSent: false,
        createdAt: new Date().toISOString(),
      };
      existingApplications.push(newApplication);
      localStorage.setItem('trainingApplications', JSON.stringify(existingApplications));
      
      // Simulate a successful response
      setTimeout(() => {
        setSuccessMessage("Your training program application has been submitted successfully! We'll contact you with further details.");
        trainingForm.reset();
        window.scrollTo({ top: 0, behavior: "smooth" });
      }, 500);
      
    } catch (error: any) {
      console.error("Error submitting training application:", error);
      setErrorMessage("Failed to submit your application. Please try again.");
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-10">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl font-bold mb-4">
            Apply Now
          </h1>
          <h2 className="text-xl text-gray-700 mb-3">
            Start Your Tech Journey with Codecrafters
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Apply for our internship positions or training programs. Fill out the form below to get started.
          </p>
        </motion.div>
      </div>

      <div className="container mx-auto px-4 py-10 max-w-4xl">
        {successMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-6"
          >
            <Alert className="border-green-500 bg-green-50">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertTitle className="text-green-800">Success!</AlertTitle>
              <AlertDescription className="text-green-700">{successMessage}</AlertDescription>
            </Alert>
          </motion.div>
        )}

        {errorMessage && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-6"
          >
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{errorMessage}</AlertDescription>
            </Alert>
          </motion.div>
        )}

        <Tabs defaultValue={activeTab} value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="internship">Internship Application</TabsTrigger>
            <TabsTrigger value="training">Training Programs</TabsTrigger>
          </TabsList>
          
          <TabsContent value="internship">
            <Card>
              <CardHeader>
                <CardTitle>Apply for an Internship</CardTitle>
                <CardDescription>
                  Fill out the form below to apply for one of our internship positions. We'll get back to you as soon as possible.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...internshipForm}>
                  <form onSubmit={internshipForm.handleSubmit(handleInternshipSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={internshipForm.control}
                        name="fullName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your full name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={internshipForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your email address" type="email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={internshipForm.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your phone number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={internshipForm.control}
                        name="internshipType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Internship Position</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a position" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {allInternships.map((position) => (
                                  <SelectItem key={position.id} value={position.title}>
                                    {position.title}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={internshipForm.control}
                      name="coverLetter"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Cover Letter (Optional)</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell us why you're interested in this position and what makes you a good fit"
                              className="min-h-32"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end">
                      <Button type="submit">
                        Submit Application
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="training">
            <Card>
              <CardHeader>
                <CardTitle>Apply for a Training Program</CardTitle>
                <CardDescription>
                  Fill out the form below to apply for one of our training programs. Our team will contact you with further details.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...trainingForm}>
                  <form onSubmit={trainingForm.handleSubmit(handleTrainingSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={trainingForm.control}
                        name="fullName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your full name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={trainingForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your email address" type="email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={trainingForm.control}
                        name="phone"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Phone Number</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your phone number" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={trainingForm.control}
                        name="programId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Training Program</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a program" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {trainingPrograms.map((program) => (
                                  <SelectItem key={program.id} value={program.id}>
                                    {program.title}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={trainingForm.control}
                      name="message"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Additional Information (Optional)</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell us about your background and why you're interested in this program"
                              className="min-h-32"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-end">
                      <Button type="submit">
                        Submit Application
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
} 