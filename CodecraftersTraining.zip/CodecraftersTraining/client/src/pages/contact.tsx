import ContactSection from "@/components/sections/contact-section";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { GradientText } from "@/components/ui/gradient-text";

export default function Contact() {
  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Contact <GradientText>Us</GradientText></h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Have questions about our programs or services? Reach out to our team for personalized assistance
          </p>
        </div>
        
        <Separator className="my-8" />
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <Card>
          <CardContent className="p-6 md:p-8">
            <h2 className="text-2xl font-bold mb-6">How Can We Help You?</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-bold mb-2 flex items-center">
                  <span className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                    <i className="fas fa-graduation-cap text-primary"></i>
                  </span>
                  Training Inquiries
                </h3>
                <p className="text-gray-600">
                  Questions about our training programs, course details, schedules, or admission process.
                </p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-bold mb-2 flex items-center">
                  <span className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                    <i className="fas fa-briefcase text-primary"></i>
                  </span>
                  Business Solutions
                </h3>
                <p className="text-gray-600">
                  Inquiries about our software development, digital marketing, or business automation services.
                </p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-bold mb-2 flex items-center">
                  <span className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                    <i className="fas fa-handshake text-primary"></i>
                  </span>
                  Partnerships
                </h3>
                <p className="text-gray-600">
                  Explore collaboration opportunities, corporate training programs, or become a hiring partner.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <ContactSection />
    </div>
  );
}
