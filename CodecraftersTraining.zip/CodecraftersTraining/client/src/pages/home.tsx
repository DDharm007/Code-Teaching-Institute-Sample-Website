import HeroSection from "@/components/sections/hero-section";
import FeaturedServices from "@/components/sections/featured-services";
import Testimonials from "@/components/sections/testimonials";
import AboutSection from "@/components/sections/about-section";
import ServicesSection from "@/components/sections/services-section";
import TrainingPrograms from "@/components/sections/training-programs";
import ContactSection from "@/components/sections/contact-section";
import TrustedBySection from "@/components/sections/trusted-by-section";
import SuccessStoriesSection from "@/components/sections/success-stories-section";
import FeaturedProgramsSection from "@/components/sections/featured-programs-section";
import LearningPathsSection from "@/components/sections/learning-paths-section";
import StatisticsSection from "@/components/sections/statistics-section";

export default function Home() {
  return (
    <>
      <HeroSection />
      <FeaturedServices />
      <AboutSection />
      <StatisticsSection />
      <ServicesSection />
      <FeaturedProgramsSection />
      <TrainingPrograms />
      <SuccessStoriesSection />
      <LearningPathsSection />
      <TrustedBySection />
      <Testimonials />
      <ContactSection />
    </>
  );
}
