import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { GradientText } from "@/components/ui/gradient-text";
import { internships } from "@/lib/data";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { BriefcaseBusiness, GraduationCap, CheckCircle2, Users, Calendar, Trophy } from "lucide-react";

export default function Internships() {
  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Internship <GradientText>Opportunities</GradientText></h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Gain real-world experience working on industry projects with mentoring from experienced professionals
          </p>
        </div>
        
        <Separator className="my-8" />
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <Card>
          <CardContent className="p-6 md:p-8">
            <h2 className="text-2xl font-bold mb-6">Why Intern with Codecrafters?</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-bold mb-2 flex items-center">
                  <span className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-2">
                    <i className="fas fa-project-diagram text-green-600"></i>
                  </span>
                  Real Projects
                </h3>
                <p className="text-gray-600">
                  Work on actual client projects that have real-world impact and add substantial value to your portfolio.
                </p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-bold mb-2 flex items-center">
                  <span className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-2">
                    <i className="fas fa-user-tie text-green-600"></i>
                  </span>
                  Mentorship
                </h3>
                <p className="text-gray-600">
                  Receive guidance from industry professionals who provide regular feedback and career advice.
                </p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-bold mb-2 flex items-center">
                  <span className="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center mr-2">
                    <i className="fas fa-briefcase text-green-600"></i>
                  </span>
                  Job Placement
                </h3>
                <p className="text-gray-600">
                  Top-performing interns often receive job offers from our partner companies or within Codecrafters.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <h2 className="text-2xl font-bold mb-6">All Available Internships</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {internships.map((internship) => (
            <Card key={internship.id} className="hover:border-primary transition-colors duration-300">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-bold mb-1">{internship.title}</h3>
                    <p className="text-gray-600 mb-3">Duration: {internship.duration}</p>
                  </div>
                  <Badge variant={internship.type === "Remote" ? "default" : "secondary"}>
                    {internship.type}
                  </Badge>
                </div>
                
                <div className="mb-3">
                  <h4 className="font-medium mb-2">Responsibilities:</h4>
                  <ul className="text-gray-700 space-y-1 pl-5 list-disc">
                    {internship.responsibilities.map((item, index) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                </div>
                
                <div className="mb-3">
                  <h4 className="font-medium mb-2">Requirements:</h4>
                  <ul className="text-gray-700 space-y-1 pl-5 list-disc">
                    {internship.requirements.map((item, index) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                </div>
                
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200">
                  <div className="flex items-center">
                    <i className="fas fa-certificate text-yellow-500 mr-2"></i>
                    <span className="text-gray-700">Certificate & Letter of Recommendation</span>
                  </div>
                  <Link href={`/apply/internship?internship=${encodeURIComponent(internship.title)}`}>
                    <Button size="sm">Apply Now</Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
      
      {/* Additional Programs Section */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16 bg-gray-50 py-12 rounded-lg">
        <h2 className="text-2xl font-bold mb-10 text-center">Additional Internship Programs</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center">
                <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <BriefcaseBusiness className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-bold mb-2">UI/UX Design Internship</h3>
                <p className="text-gray-600 mb-4">Learn user interface and user experience design principles while working on real projects</p>
                <Badge className="mb-4">3 Months</Badge>
                <Link href={`/apply/internship?internship=${encodeURIComponent("UI/UX Design Internship")}`}>
                  <Button className="w-full">Apply Now</Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center">
                <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <GraduationCap className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-bold mb-2">Cloud DevOps Internship</h3>
                <p className="text-gray-600 mb-4">Master cloud infrastructure and deployment automation techniques</p>
                <Badge className="mb-4">4 Months</Badge>
                <Link href={`/apply/internship?internship=${encodeURIComponent("Cloud DevOps Internship")}`}>
                  <Button className="w-full">Apply Now</Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center">
                <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-bold mb-2">Product Management Internship</h3>
                <p className="text-gray-600 mb-4">Learn to define, roadmap and manage successful tech products</p>
                <Badge className="mb-4">6 Months</Badge>
                <Link href={`/apply/internship?internship=${encodeURIComponent("Product Management Internship")}`}>
                  <Button className="w-full">Apply Now</Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Internship Benefits */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Internship Benefits</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center">
                <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <CheckCircle2 className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-lg font-bold mb-2">Skill Development</h3>
                <p className="text-gray-600">
                  Develop industry-relevant skills through practical application and guidance
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center">
                <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <Calendar className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-lg font-bold mb-2">Flexible Schedule</h3>
                <p className="text-gray-600">
                  Work around your academic commitments with our flexible timing options
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center">
                <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-lg font-bold mb-2">Networking</h3>
                <p className="text-gray-600">
                  Connect with professionals, mentors, and fellow interns in the tech industry
                </p>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col items-center text-center">
                <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <Trophy className="h-6 w-6 text-green-600" />
                </div>
                <h3 className="text-lg font-bold mb-2">Performance Incentives</h3>
                <p className="text-gray-600">
                  Earn performance-based stipends and recognition for exceptional work
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Success Stories */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <h2 className="text-2xl font-bold mb-8 text-center">Intern Success Stories</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardContent className="p-6">
              <div className="border-l-4 border-primary pl-4 py-2">
                <p className="text-gray-700 italic mb-4">
                  "The internship at Codecrafters gave me real-world exposure to enterprise software development. The mentorship I received helped me secure a full-time role at a leading tech company."
                </p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gray-200 rounded-full mr-4"></div>
                  <div>
                    <h4 className="font-bold">Sarah Johnson</h4>
                    <p className="text-gray-600">Former Software Development Intern</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="border-l-4 border-primary pl-4 py-2">
                <p className="text-gray-700 italic mb-4">
                  "During my digital marketing internship, I managed real client campaigns that delivered measurable results. The hands-on experience was invaluable for my career growth."
                </p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-gray-200 rounded-full mr-4"></div>
                  <div>
                    <h4 className="font-bold">Raj Mehta</h4>
                    <p className="text-gray-600">Former Digital Marketing Intern</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* CTA Section */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <Card className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Ready to Start Your Career Journey?</h2>
            <p className="mb-6 max-w-2xl mx-auto">
              Apply for our internship programs and gain the skills, experience, and industry connections you need to succeed.
            </p>
            <Link href="/apply/internship?internship=Full%20Stack%20Development%20Intern">
              <Button variant="secondary" size="lg" className="font-bold">
                Apply Now
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
