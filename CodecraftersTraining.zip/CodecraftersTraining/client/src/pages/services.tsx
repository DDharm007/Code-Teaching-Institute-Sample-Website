import ServicesSection from "@/components/sections/services-section";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { GradientText } from "@/components/ui/gradient-text";
import { CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Services() {
  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Our <GradientText>Services</GradientText></h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Comprehensive technology solutions to help businesses and individuals succeed in the digital age
          </p>
        </div>
        
        <Separator className="my-8" />
      </div>
      
      <ServicesSection />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <Card className="bg-gray-50">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold mb-6 text-center">Why Choose Codecrafters?</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="flex flex-col items-start">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">Industry Expertise</h3>
                <p className="text-gray-700">
                  Our team consists of professionals with years of industry experience across various technology domains.
                </p>
              </div>
              
              <div className="flex flex-col items-start">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">Customized Solutions</h3>
                <p className="text-gray-700">
                  We tailor our services to meet the specific needs and goals of your business or career path.
                </p>
              </div>
              
              <div className="flex flex-col items-start">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-2">Ongoing Support</h3>
                <p className="text-gray-700">
                  Our relationship doesn't end with project delivery. We provide continuous support and maintenance.
                </p>
              </div>
            </div>
            
            <div className="mt-12 text-center">
              <Link href="/contact">
                <Button size="lg" className="bg-primary hover:bg-blue-600">
                  Get a Free Consultation
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
