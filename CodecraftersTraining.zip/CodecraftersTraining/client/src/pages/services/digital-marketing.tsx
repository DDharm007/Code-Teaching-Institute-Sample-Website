import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { GradientText } from "@/components/ui/gradient-text";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft, Search, Megaphone, Hash, Pen, CheckCircle, ArrowRight } from "lucide-react";

export default function DigitalMarketingPage() {
  const services = [
    {
      title: "Search Engine Optimization",
      icon: <Search className="h-6 w-6 text-blue-500" />,
      description: "Improve your website's visibility in search engine results pages through on-page and off-page optimization techniques.",
      features: [
        "Keyword research and strategy",
        "On-page SEO optimization",
        "Technical SEO audits",
        "Link building and outreach",
        "Local SEO for businesses"
      ]
    },
    {
      title: "Search Engine Marketing",
      icon: <Megaphone className="h-6 w-6 text-blue-500" />,
      description: "Drive targeted traffic to your website through strategic paid advertising campaigns on search engines.",
      features: [
        "Google Ads campaign management",
        "PPC (Pay-Per-Click) optimization",
        "Ad copywriting and testing",
        "Conversion rate optimization",
        "Retargeting campaigns"
      ]
    },
    {
      title: "Social Media Marketing",
      icon: <Hash className="h-6 w-6 text-blue-500" />,
      description: "Build brand awareness and engage with your audience across popular social media platforms.",
      features: [
        "Social media strategy development",
        "Content creation and scheduling",
        "Community management",
        "Social media advertising",
        "Performance analytics and reporting"
      ]
    },
    {
      title: "Content Creation",
      icon: <Pen className="h-6 w-6 text-blue-500" />,
      description: "Develop high-quality, engaging content that resonates with your target audience and drives conversions.",
      features: [
        "Blog posts and articles",
        "Infographics and visual content",
        "Video production and editing",
        "Email marketing campaigns",
        "Whitepapers and ebooks"
      ]
    }
  ];

  const benefits = [
    "Increased brand awareness and visibility",
    "Higher website traffic and engagement",
    "Improved conversion rates and lead generation",
    "Better ROI on marketing investments",
    "Data-driven insights for continuous improvement",
    "Comprehensive reporting and analytics"
  ];

  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="mb-8">
          <Link href="/services">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Services
            </Button>
          </Link>
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Digital <GradientText>Marketing</GradientText></h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Boost your online presence and drive qualified traffic with our comprehensive digital marketing strategies
            </p>
          </div>
        </div>
        
        <Separator className="my-8" />
        
        {/* Hero section */}
        <div className="mb-16">
          <div className="bg-gradient-to-r from-blue-600 to-blue-400 rounded-xl overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="p-8 md:p-12 flex flex-col justify-center">
                <h2 className="text-3xl font-bold text-white mb-4">Transform Your Digital Presence</h2>
                <p className="text-white/90 mb-6">
                  In today's digital landscape, having a strong online presence is essential for business success. Our digital marketing experts will help you navigate the complexities of online marketing to reach your target audience effectively.
                </p>
                <div>
                  <Link href="/contact">
                    <Button className="bg-white text-blue-600 hover:bg-gray-100">
                      Get a Free Consultation
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="hidden md:block bg-[url('https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80')] bg-cover bg-center">
                <div className="w-full h-full bg-blue-900/20 backdrop-blur-sm"></div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Services */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Our Digital Marketing Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mr-4">
                      {service.icon}
                    </div>
                    <h3 className="text-xl font-bold">{service.title}</h3>
                  </div>
                  
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  
                  <h4 className="font-medium text-gray-800 mb-2">What we offer:</h4>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-blue-500 mr-2 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
        
        {/* Benefits */}
        <section className="mb-16">
          <Card className="bg-gray-50 border-blue-100">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-6 text-center">Why Choose Our Digital Marketing Services?</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start">
                    <CheckCircle className="text-blue-500 mr-3 mt-1 h-5 w-5 flex-shrink-0" />
                    <p className="text-gray-700">{benefit}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>
        
        {/* CTA */}
        <section>
          <div className="bg-blue-50 rounded-xl p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Ready to Grow Your Online Presence?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto mb-6">
              Our digital marketing experts are ready to help you build a customized strategy that aligns with your business goals and drives measurable results.
            </p>
            <Link href="/contact">
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                Contact Us Today
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
} 