import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { GradientText } from "@/components/ui/gradient-text";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft, CheckCircle, ArrowRight, GraduationCap, Clock, Award, BriefcaseBusiness, ChartGantt, UserRoundCheck, Star, AlignLeft } from "lucide-react";

export default function InternshipProgramsPage() {
  const programs = [
    {
      title: "Cyber Security Internship",
      duration: "3 months",
      level: "Intermediate to Advanced",
      description: "Gain hands-on experience in vulnerability assessment, penetration testing, and security monitoring in real-world environments.",
      skills: [
        "Network security fundamentals",
        "Vulnerability assessment techniques",
        "Security monitoring and incident response",
        "Ethical hacking methodologies",
        "Security compliance and best practices"
      ]
    },
    {
      title: "Full Stack Development Internship",
      duration: "4 months",
      level: "Beginner to Intermediate",
      description: "Build end-to-end web applications using modern technologies and frameworks while working on actual client projects.",
      skills: [
        "Frontend development (React/Angular/Vue)",
        "Backend development (Node.js/Python/Java)",
        "Database design and management",
        "API development and integration",
        "Version control and collaborative coding"
      ]
    },
    {
      title: "Cloud Computing Internship",
      duration: "3 months",
      level: "Intermediate",
      description: "Learn to design, deploy, and manage cloud infrastructure solutions on major cloud platforms.",
      skills: [
        "Cloud architecture principles",
        "Infrastructure as Code (IaC)",
        "Cloud security and compliance",
        "DevOps practices and tools",
        "Multi-cloud deployment strategies"
      ]
    },
    {
      title: "AI & Machine Learning Internship",
      duration: "4 months",
      level: "Intermediate to Advanced",
      description: "Develop machine learning models and AI solutions to solve real business problems across various domains.",
      skills: [
        "Data preprocessing and analysis",
        "Machine learning algorithms",
        "Deep learning frameworks",
        "Model evaluation and deployment",
        "AI ethics and responsible implementation"
      ]
    }
  ];

  const features = [
    {
      title: "Real-time Projects",
      icon: <ChartGantt className="h-6 w-6 text-green-600" />,
      description: "Work on actual client projects and business challenges, not just simulations or assignments."
    },
    {
      title: "Industry Mentoring",
      icon: <UserRoundCheck className="h-6 w-6 text-green-600" />,
      description: "Receive guidance and feedback from experienced professionals working in the field."
    },
    {
      title: "Professional Certification",
      icon: <Award className="h-6 w-6 text-green-600" />,
      description: "Earn industry-recognized certificates upon successful completion of the internship program."
    },
    {
      title: "Placement Assistance",
      icon: <BriefcaseBusiness className="h-6 w-6 text-green-600" />,
      description: "Get support for job placement through our network of industry partners and recruitment assistance."
    }
  ];

  const testimonials = [
    {
      name: "Priya Mehta",
      program: "Full Stack Development Internship",
      company: "TechSolutions Inc.",
      quote: "The hands-on experience I gained during my internship at Codecrafters was invaluable. Working on real client projects prepared me for my role as a developer better than any classroom could have.",
      rating: 5
    },
    {
      name: "Aryan Singh",
      program: "Cyber Security Internship",
      company: "SecureNet Systems",
      quote: "The mentorship I received during my internship helped me understand industry best practices and gave me confidence to tackle real security challenges in my current job.",
      rating: 5
    },
    {
      name: "Neha Sharma",
      program: "Cloud Computing Internship",
      company: "CloudWave Technologies",
      quote: "My internship experience at Codecrafters directly led to my current position. The projects I worked on became part of my portfolio that impressed my employer.",
      rating: 4
    }
  ];

  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="mb-8">
          <Link href="/services">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Services
            </Button>
          </Link>
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Internship <GradientText>Programs</GradientText></h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Gain hands-on experience working alongside industry professionals on real client projects
            </p>
          </div>
        </div>
        
        <Separator className="my-8" />
        
        {/* Hero section */}
        <div className="mb-16">
          <div className="bg-gradient-to-r from-green-600 to-emerald-400 rounded-xl overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="p-8 md:p-12 flex flex-col justify-center">
                <h2 className="text-3xl font-bold text-white mb-4">Launch Your Career with Hands-on Experience</h2>
                <p className="text-white/90 mb-6">
                  Bridge the gap between academic knowledge and industry requirements with our structured internship programs. Work on real projects, learn from industry experts, and build a strong foundation for your tech career.
                </p>
                <div>
                  <Link href="/apply">
                    <Button className="bg-white text-green-600 hover:bg-gray-100">
                      Apply for Internship
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="hidden md:block bg-[url('https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80')] bg-cover bg-center">
                <div className="w-full h-full bg-green-900/20 backdrop-blur-sm"></div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Key Features */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Why Choose Our Internship Programs?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card key={index} className="hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6 flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
        
        {/* Programs */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Our Internship Programs</h2>
          <div className="space-y-8">
            {programs.map((program, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                <div className="grid grid-cols-1 lg:grid-cols-3">
                  <div className="bg-green-50 p-6 flex flex-col justify-center">
                    <h3 className="text-xl font-bold mb-2 text-green-700">{program.title}</h3>
                    <div className="flex items-center mb-2">
                      <Clock className="h-4 w-4 text-green-600 mr-2" />
                      <span className="text-sm text-green-600">Duration: {program.duration}</span>
                    </div>
                    <div className="flex items-center mb-4">
                      <GraduationCap className="h-4 w-4 text-green-600 mr-2" />
                      <span className="text-sm text-green-600">Level: {program.level}</span>
                    </div>
                    <Link href="/apply">
                      <Button className="bg-green-600 hover:bg-green-700 text-white w-full">
                        Apply Now
                      </Button>
                    </Link>
                  </div>
                  <div className="col-span-2 p-6">
                    <p className="text-gray-700 mb-4">{program.description}</p>
                    <h4 className="font-medium text-gray-800 mb-2">Skills you'll gain:</h4>
                    <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {program.skills.map((skill, skillIndex) => (
                        <li key={skillIndex} className="flex items-start">
                          <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5" />
                          <span className="text-gray-600">{skill}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </section>
        
        {/* Success Stories */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Success Stories</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex justify-center mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className={`h-5 w-5 ${i < testimonial.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} />
                    ))}
                  </div>
                  <blockquote className="text-gray-700 mb-4 italic text-center">
                    "{testimonial.quote}"
                  </blockquote>
                  <div className="text-center">
                    <h4 className="font-bold">{testimonial.name}</h4>
                    <p className="text-sm text-gray-500">{testimonial.program}</p>
                    <p className="text-sm text-green-600">Now at: {testimonial.company}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
        
        {/* Application Process */}
        <section className="mb-16">
          <Card className="bg-gray-50 border-green-100">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-6 text-center">Application Process</h2>
              
              <div className="max-w-3xl mx-auto">
                <div className="relative">
                  <div className="absolute left-8 top-0 h-full w-1 bg-green-200"></div>
                  
                  <div className="relative mb-8 pl-20">
                    <div className="absolute left-0 top-0 w-16 h-16 rounded-full bg-green-100 flex items-center justify-center border-4 border-white">
                      <AlignLeft className="h-6 w-6 text-green-600" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">1. Online Application</h3>
                    <p className="text-gray-600">Fill out our online application form with your academic background, skills, and internship preferences.</p>
                  </div>
                  
                  <div className="relative mb-8 pl-20">
                    <div className="absolute left-0 top-0 w-16 h-16 rounded-full bg-green-100 flex items-center justify-center border-4 border-white">
                      <svg className="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                      </svg>
                    </div>
                    <h3 className="text-xl font-bold mb-2">2. Skills Assessment</h3>
                    <p className="text-gray-600">Complete a brief technical assessment to help us understand your current skill level and match you with the right projects.</p>
                  </div>
                  
                  <div className="relative mb-8 pl-20">
                    <div className="absolute left-0 top-0 w-16 h-16 rounded-full bg-green-100 flex items-center justify-center border-4 border-white">
                      <svg className="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                      </svg>
                    </div>
                    <h3 className="text-xl font-bold mb-2">3. Interview</h3>
                    <p className="text-gray-600">Participate in a brief interview with our team to discuss your goals, expectations, and determine project alignment.</p>
                  </div>
                  
                  <div className="relative pl-20">
                    <div className="absolute left-0 top-0 w-16 h-16 rounded-full bg-green-100 flex items-center justify-center border-4 border-white">
                      <svg className="h-6 w-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <h3 className="text-xl font-bold mb-2">4. Acceptance & Onboarding</h3>
                    <p className="text-gray-600">Once accepted, you'll receive program details and be onboarded to your team and project.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
        
        {/* CTA */}
        <section>
          <div className="bg-green-50 rounded-xl p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Ready to Kickstart Your Career?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto mb-6">
              Join our internship program and gain the hands-on experience, mentorship, and skills you need to succeed in the tech industry.
            </p>
            <Link href="/apply">
              <Button className="bg-green-600 hover:bg-green-700 text-white">
                Apply for Internship
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
} 