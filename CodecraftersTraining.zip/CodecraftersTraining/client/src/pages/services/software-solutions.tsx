import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { GradientText } from "@/components/ui/gradient-text";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowLeft, Laptop, Smartphone, Bot, Cog, CheckCircle, ArrowRight, Code, Database, Server, Shield } from "lucide-react";

export default function SoftwareSolutionsPage() {
  const services = [
    {
      title: "Custom Web Development",
      icon: <Laptop className="h-6 w-6 text-indigo-500" />,
      description: "Build scalable, responsive websites and web applications tailored to your specific business requirements.",
      features: [
        "Custom website development",
        "Web application development",
        "E-commerce solutions",
        "Content management systems",
        "Progressive web applications"
      ]
    },
    {
      title: "Mobile App Development",
      icon: <Smartphone className="h-6 w-6 text-indigo-500" />,
      description: "Create engaging, user-friendly mobile applications for iOS and Android platforms that drive user engagement.",
      features: [
        "Native iOS and Android apps",
        "Cross-platform app development",
        "UI/UX design for mobile",
        "App maintenance and updates",
        "App store optimization"
      ]
    },
    {
      title: "Business Automation",
      icon: <Bot className="h-6 w-6 text-indigo-500" />,
      description: "Streamline your business processes with automated workflows that increase efficiency and reduce errors.",
      features: [
        "Workflow automation",
        "Document processing systems",
        "Customer relationship management",
        "Inventory management solutions",
        "Reporting and analytics tools"
      ]
    },
    {
      title: "Enterprise Solutions",
      icon: <Cog className="h-6 w-6 text-indigo-500" />,
      description: "Develop robust, scalable enterprise-grade applications that support your organization's growth and operations.",
      features: [
        "Enterprise application integration",
        "Cloud migration services",
        "Legacy system modernization",
        "Custom ERP and CRM solutions",
        "Enterprise mobility solutions"
      ]
    }
  ];

  const technologies = [
    {
      title: "Frontend Development",
      icon: <Code className="h-6 w-6 text-indigo-500" />,
      items: ["React", "Angular", "Vue.js", "Next.js", "TypeScript", "Tailwind CSS"]
    },
    {
      title: "Backend Development",
      icon: <Server className="h-6 w-6 text-indigo-500" />,
      items: ["Node.js", "Python", "Java", "PHP", ".NET", "Ruby on Rails"]
    },
    {
      title: "Database Technologies",
      icon: <Database className="h-6 w-6 text-indigo-500" />,
      items: ["MongoDB", "MySQL", "PostgreSQL", "Firebase", "Redis", "SQL Server"]
    },
    {
      title: "DevOps & Security",
      icon: <Shield className="h-6 w-6 text-indigo-500" />,
      items: ["AWS", "Azure", "Google Cloud", "Docker", "Kubernetes", "CI/CD"]
    }
  ];

  const benefits = [
    "Customized solutions tailored to your specific business needs",
    "Scalable architecture that grows with your business",
    "Modern, user-friendly interfaces that enhance user experience",
    "Secure, reliable systems built with industry best practices",
    "Ongoing support and maintenance to ensure optimal performance",
    "Transparent development process with regular updates"
  ];

  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="mb-8">
          <Link href="/services">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Services
            </Button>
          </Link>
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4">Software <GradientText>Solutions</GradientText></h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Custom software development to solve complex business challenges and drive digital transformation
            </p>
          </div>
        </div>
        
        <Separator className="my-8" />
        
        {/* Hero section */}
        <div className="mb-16">
          <div className="bg-gradient-to-r from-indigo-600 to-purple-400 rounded-xl overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2">
              <div className="p-8 md:p-12 flex flex-col justify-center">
                <h2 className="text-3xl font-bold text-white mb-4">Innovative Solutions for Modern Businesses</h2>
                <p className="text-white/90 mb-6">
                  From concept to deployment, our experienced team of developers creates custom software solutions designed to streamline operations, enhance user experiences, and solve complex business challenges.
                </p>
                <div>
                  <Link href="/contact">
                    <Button className="bg-white text-indigo-600 hover:bg-gray-100">
                      Discuss Your Project
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="hidden md:block bg-[url('https://images.unsplash.com/photo-1573495612937-f02b92290f34?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80')] bg-cover bg-center">
                <div className="w-full h-full bg-indigo-900/20 backdrop-blur-sm"></div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Services */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Our Software Development Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 rounded-full bg-indigo-100 flex items-center justify-center mr-4">
                      {service.icon}
                    </div>
                    <h3 className="text-xl font-bold">{service.title}</h3>
                  </div>
                  
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  
                  <h4 className="font-medium text-gray-800 mb-2">What we offer:</h4>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start">
                        <CheckCircle className="h-5 w-5 text-indigo-500 mr-2 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
        
        {/* Technologies */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Technologies We Work With</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {technologies.map((tech, index) => (
              <Card key={index} className="hover:shadow-md transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 rounded-full bg-indigo-100 flex items-center justify-center mr-3">
                      {tech.icon}
                    </div>
                    <h3 className="text-lg font-bold">{tech.title}</h3>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    {tech.items.map((item, itemIndex) => (
                      <span key={itemIndex} className="bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full text-sm">
                        {item}
                      </span>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
        
        {/* Benefits */}
        <section className="mb-16">
          <Card className="bg-gray-50 border-indigo-100">
            <CardContent className="p-8">
              <h2 className="text-2xl font-bold mb-6 text-center">Why Choose Our Software Solutions?</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start">
                    <CheckCircle className="text-indigo-500 mr-3 mt-1 h-5 w-5 flex-shrink-0" />
                    <p className="text-gray-700">{benefit}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </section>
        
        {/* CTA */}
        <section>
          <div className="bg-indigo-50 rounded-xl p-8 text-center">
            <h2 className="text-2xl font-bold mb-4">Ready to Transform Your Business?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto mb-6">
              Our development team is ready to help you build custom software solutions that drive efficiency, innovation, and growth for your business.
            </p>
            <Link href="/contact">
              <Button className="bg-indigo-600 hover:bg-indigo-700 text-white">
                Start Your Project
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </section>
      </div>
    </div>
  );
} 