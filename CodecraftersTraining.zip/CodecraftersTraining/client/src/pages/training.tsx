import TrainingPrograms from "@/components/sections/training-programs";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { GradientText } from "@/components/ui/gradient-text";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { trainingPrograms } from "@/lib/data";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Training() {
  return (
    <div className="py-24">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">Training <GradientText>Programs</GradientText></h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Career-oriented IT training programs designed to transform beginners into industry-ready professionals
          </p>
        </div>
        
        <Separator className="my-8" />
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <Card>
          <CardContent className="p-6 md:p-8">
            <h2 className="text-2xl font-bold mb-6">Our Training Approach</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-bold mb-2 flex items-center">
                  <span className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                    <i className="fas fa-chalkboard-teacher text-primary"></i>
                  </span>
                  Expert Instructors
                </h3>
                <p className="text-gray-600">
                  Learn from industry professionals with extensive real-world experience in their respective domains.
                </p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-bold mb-2 flex items-center">
                  <span className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                    <i className="fas fa-laptop-code text-primary"></i>
                  </span>
                  Hands-on Projects
                </h3>
                <p className="text-gray-600">
                  Apply your learning through practical projects that simulate real-world challenges and scenarios.
                </p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-lg">
                <h3 className="text-xl font-bold mb-2 flex items-center">
                  <span className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-2">
                    <i className="fas fa-certificate text-primary"></i>
                  </span>
                  Career Support
                </h3>
                <p className="text-gray-600">
                  Receive guidance on resume building, interview preparation, and job placement assistance.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <TrainingPrograms />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <Card>
          <CardContent className="p-6 md:p-8">
            <h2 className="text-2xl font-bold mb-6">Detailed Course Information</h2>
            
            <Tabs defaultValue="cyber">
              <TabsList className="grid w-full grid-cols-2 md:grid-cols-4">
                <TabsTrigger value="cyber">Cyber Security</TabsTrigger>
                <TabsTrigger value="fullstack">Full Stack Dev</TabsTrigger>
                <TabsTrigger value="cloud">Cloud Computing</TabsTrigger>
                <TabsTrigger value="ai">AI & ML</TabsTrigger>
              </TabsList>
              
              {trainingPrograms.map((program) => (
                <TabsContent key={program.id} value={program.id} className="p-4">
                  <h3 className="text-xl font-bold mb-4">{program.title}</h3>
                  <p className="text-gray-700 mb-4">{program.description}</p>
                  
                  <div className="mb-6">
                    <h4 className="text-lg font-bold mb-3">Course Syllabus</h4>
                    <ul className="space-y-2">
                      {program.modules.map((module, index) => (
                        <li key={index} className="flex items-start">
                          <span className="text-primary mr-2">•</span>
                          <span>{module}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="mb-6">
                    <h4 className="text-lg font-bold mb-3">Career Opportunities</h4>
                    <ul className="space-y-2">
                      {program.careers.map((career, index) => (
                        <li key={index} className="flex items-start">
                          <span className="text-primary mr-2">•</span>
                          <span>{career}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  <div className="mt-6 flex justify-center">
                    <Link href={`/apply/training?program=${program.id}`}>
                      <Button className="px-8">Apply Now</Button>
                    </Link>
                  </div>
                </TabsContent>
              ))}
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
