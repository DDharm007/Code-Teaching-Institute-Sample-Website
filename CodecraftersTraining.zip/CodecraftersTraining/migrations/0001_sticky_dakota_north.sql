ALTER TABLE `contact_messages` ADD `status` text DEFAULT 'pending' NOT NULL;--> statement-breakpoint
ALTER TABLE `contact_messages` ADD `email_sent` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `internship_applications` ADD `status` text DEFAULT 'pending' NOT NULL;--> statement-breakpoint
ALTER TABLE `internship_applications` ADD `sms_sent` integer DEFAULT 0 NOT NULL;