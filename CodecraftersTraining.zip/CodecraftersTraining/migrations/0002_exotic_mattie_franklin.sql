CREATE TABLE `internship_positions` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`title` text NOT NULL,
	`duration` text NOT NULL,
	`type` text NOT NULL,
	`category` text NOT NULL,
	`responsibilities` text NOT NULL,
	`requirements` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `site_settings` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`key` text NOT NULL,
	`value` text NOT NULL,
	`description` text,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `site_settings_key_unique` ON `site_settings` (`key`);--> statement-breakpoint
CREATE TABLE `training_programs` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`slug` text NOT NULL,
	`short_title` text NOT NULL,
	`title` text NOT NULL,
	`description` text NOT NULL,
	`modules` text NOT NULL,
	`tools` text NOT NULL,
	`highlights` text NOT NULL,
	`careers` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `training_programs_slug_unique` ON `training_programs` (`slug`);