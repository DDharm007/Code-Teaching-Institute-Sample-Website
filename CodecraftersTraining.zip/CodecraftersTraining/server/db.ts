import { drizzle } from 'drizzle-orm/better-sqlite3';
import Database from 'better-sqlite3';
import * as path from 'path';
import { migrate } from 'drizzle-orm/better-sqlite3/migrator';
import { log } from './vite';
import { testimonials } from '@shared/schema';

// Initialize SQLite database
const sqlite = new Database(path.resolve('./database.sqlite'));
export const db = drizzle(sqlite);

// Function to initialize the database
export async function initializeDatabase() {
  try {
    // Perform migrations (creates tables if they don't exist)
    migrate(db, { migrationsFolder: './migrations' });
    log('Database migration completed successfully', 'database');
    
    // Seed testimonials if the table is empty
    const existingTestimonials = await db.select().from(testimonials);
    
    if (existingTestimonials.length === 0) {
      log('Seeding testimonials data...', 'database');
      
      await db.insert(testimonials).values([
        {
          name: "Alex Johnson",
          role: "Software Developer",
          content: "The Full Stack Development course completely transformed my career. The hands-on projects and dedicated mentors helped me build a professional portfolio that impressed employers. I landed a job at a tech startup just 2 weeks after completion!",
          rating: 5,
          program: "Full Stack Web Development Graduate"
        },
        {
          name: "Sarah Miller",
          role: "Cybersecurity Analyst",
          content: "Codecrafters' Cyber Security program gave me practical skills that I use daily in my job. The lab exercises and real-world scenarios prepared me for the challenges I face as a security professional. Highly recommended!",
          rating: 5,
          program: "Cyber Security Graduate"
        },
        {
          name: "Raj Patel",
          role: "Cloud Engineer",
          content: "The Cloud Computing course provided a comprehensive overview of different cloud platforms and services. The instructors were knowledgeable and always willing to help. I'm now certified and working at a major tech company.",
          rating: 5,
          program: "Cloud Computing Graduate"
        }
      ]);
      
      log('Testimonials data seeded successfully', 'database');
    }
  } catch (error) {
    console.error('Database initialization error:', error);
    throw error;
  }
} 