import nodemailer from 'nodemailer';
import { log } from './vite';

// Configure email transporter
const emailTransporter = nodemailer.createTransport({
  host: 'smtp.gmail.com', // Replace with your SMTP server
  port: 587,
  secure: false, // true for 465, false for other ports
  auth: {
    user: 'info@codecrafters.com', // Updated email
    pass: 'your-app-password', // Replace with your app password
  },
});

/**
 * Send email notification for contact form status update
 */
export async function sendContactStatusEmail(
  email: string,
  name: string,
  status: string,
  subject: string
): Promise<boolean> {
  try {
    // In development, log instead of actually sending
    if (process.env.NODE_ENV === 'development') {
      log(`Email would be sent to ${email} with status: ${status}`, 'notification');
      return true;
    }

    const statusText = status === 'accepted' ? 'Accepted' : 'Rejected';
    
    const mailOptions = {
      from: 'info@codecrafters.com', // Updated email
      to: email,
      subject: `Your Contact Request Status: ${statusText}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <h2 style="color: #4A90E2;">Hello ${name},</h2>
          <p>Thank you for reaching out to Codecrafters regarding "<strong>${subject}</strong>".</p>
          <p>We wanted to let you know that your request has been <strong>${statusText}</strong>.</p>
          ${status === 'accepted' 
            ? '<p>Our team will be in touch with you shortly to discuss your inquiry in more detail.</p>' 
            : '<p>Unfortunately, we are unable to proceed with your request at this time.</p>'
          }
          <p>If you have any questions, please don't hesitate to contact us at +91 9023362937.</p>
          <p style="margin-top: 30px;">Best regards,<br/>The Codecrafters Team</p>
        </div>
      `
    };

    await emailTransporter.sendMail(mailOptions);
    return true;
  } catch (error) {
    console.error('Error sending email notification:', error);
    return false;
  }
}

/**
 * Send WhatsApp notification for internship application status update
 * This uses a simple browser redirect since we don't have a WhatsApp API integration
 */
export async function sendInternshipStatusWhatsApp(
  phone: string,
  name: string,
  status: string,
  internshipType: string
): Promise<boolean> {
  try {
    // Format phone number (remove any non-digit characters)
    const formattedPhone = phone.replace(/\D/g, '');
    
    // In development, log instead of actually sending
    if (process.env.NODE_ENV === 'development') {
      log(`WhatsApp would be sent to ${formattedPhone} with status: ${status}`, 'notification');
      return true;
    }

    const statusText = status === 'accepted' ? 'Accepted' : 'Rejected';
    
    // Create WhatsApp message
    const message = `Hello ${name}, 
    
Thank you for applying for the ${internshipType} internship at Codecrafters.

We are pleased to inform you that your application has been *${statusText}*.

${status === 'accepted' 
  ? 'Our HR team will contact you shortly with further details about the next steps.' 
  : 'We appreciate your interest and encourage you to apply for future opportunities.'
}

For any queries, please contact us at +91 9023362937.

Regards,
Codecrafters Team`;

    // For actual implementation, you would use a WhatsApp Business API
    // For now, we're just returning the message that would be sent
    log(`WhatsApp message to ${formattedPhone}: ${message}`, 'notification');
    
    return true;
  } catch (error) {
    console.error('Error preparing WhatsApp notification:', error);
    return false;
  }
}

/**
 * Send email notification for training application status update
 */
export async function sendTrainingStatusEmail(
  email: string,
  name: string,
  status: string,
  programName: string
): Promise<boolean> {
  try {
    // In development, log instead of actually sending
    if (process.env.NODE_ENV === 'development') {
      log(`Email would be sent to ${email} with status: ${status} for ${programName} program`, 'notification');
      return true;
    }

    const statusText = status === 'accepted' ? 'Accepted' : 'Rejected';
    
    const mailOptions = {
      from: 'info@codecrafters.com', // Updated email
      to: email,
      subject: `Your Training Application Status: ${statusText}`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
          <h2 style="color: #4A90E2;">Hello ${name},</h2>
          <p>Thank you for applying to our <strong>${programName}</strong> training program.</p>
          <p>We are pleased to inform you that your application has been <strong>${statusText}</strong>.</p>
          ${status === 'accepted' 
            ? '<p>Our team will be in touch with you shortly to discuss the enrollment process and provide you with further details about the program schedule.</p>' 
            : '<p>Unfortunately, we are unable to proceed with your application at this time. We encourage you to apply for future training opportunities that align with your skills and interests.</p>'
          }
          <p>If you have any questions, please don't hesitate to contact us at +91 9023362937.</p>
          <p style="margin-top: 30px;">Best regards,<br/>The Codecrafters Training Team</p>
        </div>
      `
    };

    await emailTransporter.sendMail(mailOptions);
    return true;
  } catch (error) {
    console.error('Error sending training application email notification:', error);
    return false;
  }
} 