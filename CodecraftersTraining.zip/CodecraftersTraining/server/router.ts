import { z } from "zod";
import express, { Request, Response } from "express";
import { storage } from "./storage";
import { 
  contactFormSchema, 
  internshipApplicationSchema, 
  siteSettingsSchema,
  trainingProgramSchema,
  internshipPositionSchema,
  trainingApplicationSchema
} from "@shared/schema";
import { asyncHandler } from "./utils";
import { sendContactStatusEmail, sendInternshipStatusWhatsApp } from "./notifications";

export const router = express.Router();

// Auth routes
router.post("/api/login", asyncHandler(async (req: Request, res: Response) => {
  // ... existing code ...
}));

// ... existing code ...

// Contact and Internship Application endpoints
// ... existing code ...

// Training Application endpoint
router.post("/api/training-application", asyncHandler(async (req: Request, res: Response) => {
  const result = trainingApplicationSchema.safeParse(req.body);
  
  if (!result.success) {
    return res.status(400).json({ errors: result.error.format() });
  }
  
  const application = await storage.createTrainingApplication(result.data);
  
  res.status(201).json({ 
    message: "Your application has been submitted successfully! We will review it and get back to you.",
    data: application
  });
}));

// Admin approval/rejection for training applications
router.post("/api/admin/training/:id/status", asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const { status } = req.body;
  
  if (!status || (status !== 'accepted' && status !== 'rejected')) {
    return res.status(400).json({ message: "Invalid status. Must be 'accepted' or 'rejected'" });
  }

  const application = await storage.getTrainingApplicationById(Number(id));
  if (!application) {
    return res.status(404).json({ message: "Training application not found" });
  }

  // Update status
  const updatedApplication = await storage.updateTrainingApplicationStatus(Number(id), status);
  
  // Send email notification
  if (application.emailSent === 0) {
    // You can implement a function to send training application emails
    // Similar to sendContactStatusEmail
    // sendTrainingStatusEmail(application.email, application.fullName, status, application.programId);
    
    await storage.markTrainingEmailSent(Number(id));
  }

  res.json({ 
    message: `Training application status updated to ${status}`,
    data: updatedApplication
  });
}));

// Admin endpoint for listing training applications
router.get("/api/admin/training-applications", asyncHandler(async (req: Request, res: Response) => {
  const applications = await storage.getAllTrainingApplications();
  res.json(applications);
}));

// Site Settings Routes
router.get("/api/admin/site-settings", asyncHandler(async (req: Request, res: Response) => {
  const settings = await storage.getAllSiteSettings();
  res.json(settings);
}));

router.get("/api/admin/site-settings/:key", asyncHandler(async (req: Request, res: Response) => {
  const key = req.params.key;
  const setting = await storage.getSiteSettingByKey(key);
  
  if (!setting) {
    return res.status(404).json({ message: `Setting with key '${key}' not found` });
  }
  
  res.json(setting);
}));

router.post("/api/admin/site-settings", asyncHandler(async (req: Request, res: Response) => {
  const result = siteSettingsSchema.safeParse(req.body);
  
  if (!result.success) {
    return res.status(400).json({ errors: result.error.format() });
  }
  
  const { key, value, description } = result.data;
  const setting = await storage.updateSiteSetting(key, value, description);
  res.json(setting);
}));

// Public API for getting site settings (limited)
router.get("/api/site-settings", asyncHandler(async (req: Request, res: Response) => {
  const settings = await storage.getAllSiteSettings();
  // Only return public settings (e.g., logo, site name)
  const publicSettings = settings.reduce((acc, setting) => {
    acc[setting.key] = setting.value;
    return acc;
  }, {} as Record<string, string>);
  
  res.json(publicSettings);
}));

// Training Programs Routes
router.get("/api/admin/training-programs", asyncHandler(async (req: Request, res: Response) => {
  const programs = await storage.getAllTrainingPrograms();
  
  // Parse JSON string fields to objects for the frontend
  const processedPrograms = programs.map(program => ({
    ...program,
    modules: typeof program.modules === 'string' ? JSON.parse(program.modules) : program.modules,
    tools: typeof program.tools === 'string' ? JSON.parse(program.tools) : program.tools,
    highlights: typeof program.highlights === 'string' ? JSON.parse(program.highlights) : program.highlights,
    careers: typeof program.careers === 'string' ? JSON.parse(program.careers) : program.careers,
  }));
  
  res.json(processedPrograms);
}));

router.get("/api/admin/training-programs/:slug", asyncHandler(async (req: Request, res: Response) => {
  const slug = req.params.slug;
  const program = await storage.getTrainingProgramBySlug(slug);
  
  if (!program) {
    return res.status(404).json({ message: `Training program with slug '${slug}' not found` });
  }
  
  // Parse JSON string fields to objects
  const processedProgram = {
    ...program,
    modules: typeof program.modules === 'string' ? JSON.parse(program.modules) : program.modules,
    tools: typeof program.tools === 'string' ? JSON.parse(program.tools) : program.tools,
    highlights: typeof program.highlights === 'string' ? JSON.parse(program.highlights) : program.highlights,
    careers: typeof program.careers === 'string' ? JSON.parse(program.careers) : program.careers,
  };
  
  res.json(processedProgram);
}));

router.post("/api/admin/training-programs", asyncHandler(async (req: Request, res: Response) => {
  const result = trainingProgramSchema.safeParse(req.body);
  
  if (!result.success) {
    return res.status(400).json({ errors: result.error.format() });
  }
  
  const program = await storage.createTrainingProgram(result.data);
  
  // Parse JSON string fields to objects for the response
  const processedProgram = {
    ...program,
    modules: typeof program.modules === 'string' ? JSON.parse(program.modules) : program.modules,
    tools: typeof program.tools === 'string' ? JSON.parse(program.tools) : program.tools,
    highlights: typeof program.highlights === 'string' ? JSON.parse(program.highlights) : program.highlights,
    careers: typeof program.careers === 'string' ? JSON.parse(program.careers) : program.careers,
  };
  
  res.json(processedProgram);
}));

router.put("/api/admin/training-programs/:id", asyncHandler(async (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  const result = trainingProgramSchema.partial().safeParse(req.body);
  
  if (!result.success) {
    return res.status(400).json({ errors: result.error.format() });
  }
  
  const program = await storage.updateTrainingProgram(id, result.data);
  
  // Parse JSON string fields to objects for the response
  const processedProgram = {
    ...program,
    modules: typeof program.modules === 'string' ? JSON.parse(program.modules) : program.modules,
    tools: typeof program.tools === 'string' ? JSON.parse(program.tools) : program.tools,
    highlights: typeof program.highlights === 'string' ? JSON.parse(program.highlights) : program.highlights,
    careers: typeof program.careers === 'string' ? JSON.parse(program.careers) : program.careers,
  };
  
  res.json(processedProgram);
}));

router.delete("/api/admin/training-programs/:id", asyncHandler(async (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  const success = await storage.deleteTrainingProgram(id);
  
  if (!success) {
    return res.status(404).json({ message: `Training program with ID ${id} not found` });
  }
  
  res.json({ message: `Training program with ID ${id} deleted successfully` });
}));

// Public API for getting training programs
router.get("/api/training-programs", asyncHandler(async (req: Request, res: Response) => {
  const programs = await storage.getAllTrainingPrograms();
  
  // Parse JSON string fields to objects
  const processedPrograms = programs.map(program => ({
    ...program,
    modules: typeof program.modules === 'string' ? JSON.parse(program.modules) : program.modules,
    tools: typeof program.tools === 'string' ? JSON.parse(program.tools) : program.tools,
    highlights: typeof program.highlights === 'string' ? JSON.parse(program.highlights) : program.highlights,
    careers: typeof program.careers === 'string' ? JSON.parse(program.careers) : program.careers,
  }));
  
  res.json(processedPrograms);
}));

router.get("/api/training-programs/:slug", asyncHandler(async (req: Request, res: Response) => {
  const slug = req.params.slug;
  const program = await storage.getTrainingProgramBySlug(slug);
  
  if (!program) {
    return res.status(404).json({ message: `Training program with slug '${slug}' not found` });
  }
  
  // Parse JSON string fields to objects
  const processedProgram = {
    ...program,
    modules: typeof program.modules === 'string' ? JSON.parse(program.modules) : program.modules,
    tools: typeof program.tools === 'string' ? JSON.parse(program.tools) : program.tools,
    highlights: typeof program.highlights === 'string' ? JSON.parse(program.highlights) : program.highlights,
    careers: typeof program.careers === 'string' ? JSON.parse(program.careers) : program.careers,
  };
  
  res.json(processedProgram);
}));

// Internship Positions Routes
router.get("/api/admin/internship-positions", asyncHandler(async (req: Request, res: Response) => {
  const positions = await storage.getAllInternshipPositions();
  
  // Parse JSON string fields to objects for the frontend
  const processedPositions = positions.map(position => ({
    ...position,
    responsibilities: typeof position.responsibilities === 'string' 
      ? JSON.parse(position.responsibilities) 
      : position.responsibilities,
    requirements: typeof position.requirements === 'string' 
      ? JSON.parse(position.requirements) 
      : position.requirements,
  }));
  
  res.json(processedPositions);
}));

router.get("/api/admin/internship-positions/:id", asyncHandler(async (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  const position = await storage.getInternshipPositionById(id);
  
  if (!position) {
    return res.status(404).json({ message: `Internship position with ID ${id} not found` });
  }
  
  // Parse JSON string fields to objects
  const processedPosition = {
    ...position,
    responsibilities: typeof position.responsibilities === 'string' 
      ? JSON.parse(position.responsibilities) 
      : position.responsibilities,
    requirements: typeof position.requirements === 'string' 
      ? JSON.parse(position.requirements) 
      : position.requirements,
  };
  
  res.json(processedPosition);
}));

router.post("/api/admin/internship-positions", asyncHandler(async (req: Request, res: Response) => {
  const result = internshipPositionSchema.safeParse(req.body);
  
  if (!result.success) {
    return res.status(400).json({ errors: result.error.format() });
  }
  
  const position = await storage.createInternshipPosition(result.data);
  
  // Parse JSON string fields to objects for the response
  const processedPosition = {
    ...position,
    responsibilities: typeof position.responsibilities === 'string' 
      ? JSON.parse(position.responsibilities) 
      : position.responsibilities,
    requirements: typeof position.requirements === 'string' 
      ? JSON.parse(position.requirements) 
      : position.requirements,
  };
  
  res.json(processedPosition);
}));

router.put("/api/admin/internship-positions/:id", asyncHandler(async (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  const result = internshipPositionSchema.partial().safeParse(req.body);
  
  if (!result.success) {
    return res.status(400).json({ errors: result.error.format() });
  }
  
  const position = await storage.updateInternshipPosition(id, result.data);
  
  // Parse JSON string fields to objects for the response
  const processedPosition = {
    ...position,
    responsibilities: typeof position.responsibilities === 'string' 
      ? JSON.parse(position.responsibilities) 
      : position.responsibilities,
    requirements: typeof position.requirements === 'string' 
      ? JSON.parse(position.requirements) 
      : position.requirements,
  };
  
  res.json(processedPosition);
}));

router.delete("/api/admin/internship-positions/:id", asyncHandler(async (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  const success = await storage.deleteInternshipPosition(id);
  
  if (!success) {
    return res.status(404).json({ message: `Internship position with ID ${id} not found` });
  }
  
  res.json({ message: `Internship position with ID ${id} deleted successfully` });
}));

// Public API for getting internship positions
router.get("/api/internship-positions", asyncHandler(async (req: Request, res: Response) => {
  const positions = await storage.getAllInternshipPositions();
  
  // Parse JSON string fields to objects
  const processedPositions = positions.map(position => ({
    ...position,
    responsibilities: typeof position.responsibilities === 'string' 
      ? JSON.parse(position.responsibilities) 
      : position.responsibilities,
    requirements: typeof position.requirements === 'string' 
      ? JSON.parse(position.requirements) 
      : position.requirements,
  }));
  
  res.json(processedPositions);
}));

router.get("/api/internship-positions/:id", asyncHandler(async (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  const position = await storage.getInternshipPositionById(id);
  
  if (!position) {
    return res.status(404).json({ message: `Internship position with ID ${id} not found` });
  }
  
  // Parse JSON string fields to objects
  const processedPosition = {
    ...position,
    responsibilities: typeof position.responsibilities === 'string' 
      ? JSON.parse(position.responsibilities) 
      : position.responsibilities,
    requirements: typeof position.requirements === 'string' 
      ? JSON.parse(position.requirements) 
      : position.requirements,
  };
  
  res.json(processedPosition);
})); 