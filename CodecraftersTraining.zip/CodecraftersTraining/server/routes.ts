import express, { Request, Response } from "express";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { contactFormSchema, internshipApplicationSchema, trainingApplicationSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { sendContactStatusEmail, sendInternshipStatusWhatsApp, sendTrainingStatusEmail } from "./notifications";
import { log } from "./vite";

export async function registerRoutes(app: Express): Promise<Server> {
  const apiRouter = express.Router();

  // Get testimonials
  apiRouter.get("/testimonials", async (req: Request, res: Response) => {
    try {
      const testimonials = await storage.getAllTestimonials();
      res.json(testimonials);
    } catch (error) {
      console.error("Error fetching testimonials:", error);
      res.status(500).json({ message: "Failed to fetch testimonials" });
    }
  });

  // Submit contact form
  apiRouter.post("/contact", async (req: Request, res: Response) => {
    try {
      const validatedData = contactFormSchema.parse(req.body);
      const message = await storage.createContactMessage(validatedData);
      res.status(201).json({ 
        message: "Thank you for your message. We will get back to you soon!",
        data: message
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error submitting contact form:", error);
      res.status(500).json({ message: "Failed to submit your message. Please try again later." });
    }
  });

  // Submit internship application
  apiRouter.post("/internship-application", async (req: Request, res: Response) => {
    try {
      const validatedData = internshipApplicationSchema.parse(req.body);
      const application = await storage.createInternshipApplication(validatedData);
      res.status(201).json({ 
        message: "Your application has been submitted successfully! We will review it and get back to you.",
        data: application
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error submitting internship application:", error);
      res.status(500).json({ message: "Failed to submit your application. Please try again later." });
    }
  });

  // Submit training application
  apiRouter.post("/training-application", async (req: Request, res: Response) => {
    try {
      const validatedData = trainingApplicationSchema.parse(req.body);
      const application = await storage.createTrainingApplication(validatedData);
      res.status(201).json({ 
        message: "Your training application has been submitted successfully! We will review it and get back to you.",
        data: application
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Error submitting training application:", error);
      res.status(500).json({ message: "Failed to submit your application. Please try again later." });
    }
  });

  // Admin Routes
  // Get all contact messages
  apiRouter.get("/admin/contacts", async (req: Request, res: Response) => {
    try {
      const messages = await storage.getAllContactMessages();
      res.json(messages);
    } catch (error) {
      console.error("Error fetching contact messages:", error);
      res.status(500).json({ message: "Failed to fetch contact messages" });
    }
  });

  // Get all internship applications
  apiRouter.get("/admin/internship-applications", async (req: Request, res: Response) => {
    try {
      const applications = await storage.getAllInternshipApplications();
      res.json(applications);
    } catch (error) {
      console.error("Error fetching internship applications:", error);
      res.status(500).json({ message: "Failed to fetch internship applications" });
    }
  });

  // Get all training applications
  apiRouter.get("/admin/training-applications", async (req: Request, res: Response) => {
    try {
      const applications = await storage.getAllTrainingApplications();
      res.json(applications);
    } catch (error) {
      console.error("Error fetching training applications:", error);
      res.status(500).json({ message: "Failed to fetch training applications" });
    }
  });

  // Update contact message status
  apiRouter.post("/admin/contact/:id/status", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      if (!status || (status !== 'accepted' && status !== 'rejected')) {
        return res.status(400).json({ message: "Invalid status. Must be 'accepted' or 'rejected'" });
      }

      const contactMessage = await storage.getContactMessageById(Number(id));
      if (!contactMessage) {
        return res.status(404).json({ message: "Contact message not found" });
      }

      // Update status
      const updatedMessage = await storage.updateContactMessageStatus(Number(id), status);
      
      // Send email notification
      if (contactMessage.emailSent === 0) {
        const emailSent = await sendContactStatusEmail(
          contactMessage.email,
          contactMessage.name,
          status,
          contactMessage.subject
        );
        
        if (emailSent) {
          await storage.markContactEmailSent(Number(id));
          log(`Sent email notification to ${contactMessage.email}`, 'notification');
        }
      }

      res.json({ 
        message: `Contact message status updated to ${status}`,
        data: updatedMessage
      });
    } catch (error) {
      console.error("Error updating contact message status:", error);
      res.status(500).json({ message: "Failed to update status" });
    }
  });

  // Update internship application status
  apiRouter.post("/admin/internship/:id/status", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      if (!status || (status !== 'accepted' && status !== 'rejected')) {
        return res.status(400).json({ message: "Invalid status. Must be 'accepted' or 'rejected'" });
      }

      const application = await storage.getInternshipApplicationById(Number(id));
      if (!application) {
        return res.status(404).json({ message: "Internship application not found" });
      }

      // Update status
      const updatedApplication = await storage.updateInternshipApplicationStatus(Number(id), status);
      
      // Send WhatsApp notification
      if (application.smsSent === 0) {
        const smsSent = await sendInternshipStatusWhatsApp(
          application.phone,
          application.fullName,
          status,
          application.internshipType
        );
        
        if (smsSent) {
          await storage.markInternshipSmsSent(Number(id));
          log(`Prepared WhatsApp notification to ${application.phone}`, 'notification');
        }
      }

      res.json({ 
        message: `Internship application status updated to ${status}`,
        data: updatedApplication
      });
    } catch (error) {
      console.error("Error updating internship application status:", error);
      res.status(500).json({ message: "Failed to update status" });
    }
  });

  // Update training application status
  apiRouter.post("/admin/training/:id/status", async (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      
      if (!status || (status !== 'accepted' && status !== 'rejected')) {
        return res.status(400).json({ message: "Invalid status. Must be 'accepted' or 'rejected'" });
      }

      const application = await storage.getTrainingApplicationById(Number(id));
      if (!application) {
        return res.status(404).json({ message: "Training application not found" });
      }

      // Get the program name
      const program = await storage.getTrainingProgramBySlug(application.programId);
      const programName = program ? program.title : application.programId;

      // Update status
      const updatedApplication = await storage.updateTrainingApplicationStatus(Number(id), status);
      
      // Send Email notification
      if (application.emailSent === 0) {
        const emailSent = await sendTrainingStatusEmail(
          application.email,
          application.fullName,
          status,
          programName
        );
        
        if (emailSent) {
          await storage.markTrainingEmailSent(Number(id));
          log(`Sent email notification to ${application.email} for training application`, 'notification');
        }
      }

      res.json({ 
        message: `Training application status updated to ${status}`,
        data: updatedApplication
      });
    } catch (error) {
      console.error("Error updating training application status:", error);
      res.status(500).json({ message: "Failed to update status" });
    }
  });

  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}
