import { 
  users, 
  type User, 
  type InsertUser, 
  type ContactMessage, 
  type InsertContactMessage,
  type Testimonial,
  type InsertTestimonial,
  type InternshipApplication,
  type InsertInternshipApplication,
  type ContactFormValues,
  type InternshipApplicationFormValues,
  testimonials,
  contactMessages,
  internshipApplications,
  siteSettings,
  type SiteSettings,
  type InsertSiteSettings,
  trainingPrograms,
  type TrainingProgram,
  type InsertTrainingProgram,
  internshipPositions,
  type InternshipPosition,
  type InsertInternshipPosition,
  trainingApplications,
  type TrainingApplication,
  type InsertTrainingApplication,
  type TrainingApplicationFormValues
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllTestimonials(): Promise<Testimonial[]>;
  getTestimonial(id: number): Promise<Testimonial | undefined>;
  createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial>;
  createContactMessage(message: ContactFormValues): Promise<ContactMessage>;
  createInternshipApplication(application: InternshipApplicationFormValues): Promise<InternshipApplication>;
  getAllContactMessages(): Promise<ContactMessage[]>;
  getAllInternshipApplications(): Promise<InternshipApplication[]>;
  updateContactMessageStatus(id: number, status: string): Promise<ContactMessage>;
  updateInternshipApplicationStatus(id: number, status: string): Promise<InternshipApplication>;
  markContactEmailSent(id: number): Promise<ContactMessage>;
  markInternshipSmsSent(id: number): Promise<InternshipApplication>;
  getContactMessageById(id: number): Promise<ContactMessage | undefined>;
  getInternshipApplicationById(id: number): Promise<InternshipApplication | undefined>;
  getSiteSettingByKey(key: string): Promise<SiteSettings | undefined>;
  getAllSiteSettings(): Promise<SiteSettings[]>;
  updateSiteSetting(key: string, value: string, description?: string): Promise<SiteSettings>;
  createSiteSetting(setting: InsertSiteSettings): Promise<SiteSettings>;
  getAllTrainingPrograms(): Promise<TrainingProgram[]>;
  getTrainingProgramBySlug(slug: string): Promise<TrainingProgram | undefined>;
  createTrainingProgram(program: InsertTrainingProgram): Promise<TrainingProgram>;
  updateTrainingProgram(id: number, program: Partial<TrainingProgram>): Promise<TrainingProgram>;
  deleteTrainingProgram(id: number): Promise<boolean>;
  getAllInternshipPositions(): Promise<InternshipPosition[]>;
  getInternshipPositionById(id: number): Promise<InternshipPosition | undefined>;
  createInternshipPosition(position: InsertInternshipPosition): Promise<InternshipPosition>;
  updateInternshipPosition(id: number, position: Partial<InternshipPosition>): Promise<InternshipPosition>;
  deleteInternshipPosition(id: number): Promise<boolean>;
  createTrainingApplication(application: TrainingApplicationFormValues): Promise<TrainingApplication>;
  getAllTrainingApplications(): Promise<TrainingApplication[]>;
  getTrainingApplicationById(id: number): Promise<TrainingApplication | undefined>;
  updateTrainingApplicationStatus(id: number, status: string): Promise<TrainingApplication>;
  markTrainingEmailSent(id: number): Promise<TrainingApplication>;
}

export class DbStorage implements IStorage {

  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username)).limit(1);
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const result = await db.insert(users).values(insertUser).returning();
    return result[0];
  }

  async getAllTestimonials(): Promise<Testimonial[]> {
    return await db.select().from(testimonials);
  }

  async getTestimonial(id: number): Promise<Testimonial | undefined> {
    const result = await db.select().from(testimonials).where(eq(testimonials.id, id)).limit(1);
    return result[0];
  }

  async createTestimonial(testimonial: InsertTestimonial): Promise<Testimonial> {
    const result = await db.insert(testimonials).values(testimonial).returning();
    return result[0];
  }

  async createContactMessage(message: ContactFormValues): Promise<ContactMessage> {
    const now = new Date().toISOString();
    
    const newMessage = {
      ...message,
      status: "pending",
      emailSent: 0,
      createdAt: now
    };
    
    const result = await db.insert(contactMessages).values(newMessage).returning();
    return result[0];
  }

  async createInternshipApplication(application: InternshipApplicationFormValues): Promise<InternshipApplication> {
    const now = new Date().toISOString();
    
    const newApplication = {
      ...application,
      resumeUrl: '',
      status: "pending",
      smsSent: 0,
      createdAt: now
    };
    
    const result = await db.insert(internshipApplications).values(newApplication).returning();
    return result[0];
  }

  async createTrainingApplication(application: TrainingApplicationFormValues): Promise<TrainingApplication> {
    const now = new Date().toISOString();
    
    const newApplication = {
      ...application,
      status: "pending",
      emailSent: 0,
      createdAt: now
    };
    
    const result = await db.insert(trainingApplications).values(newApplication).returning();
    return result[0];
  }

  async getAllContactMessages(): Promise<ContactMessage[]> {
    return await db.select().from(contactMessages).orderBy(contactMessages.id);
  }

  async getAllInternshipApplications(): Promise<InternshipApplication[]> {
    return await db.select().from(internshipApplications).orderBy(internshipApplications.id);
  }

  async getAllTrainingApplications(): Promise<TrainingApplication[]> {
    return await db.select().from(trainingApplications).orderBy(trainingApplications.id);
  }

  async getContactMessageById(id: number): Promise<ContactMessage | undefined> {
    const result = await db.select().from(contactMessages).where(eq(contactMessages.id, id)).limit(1);
    return result[0];
  }

  async getInternshipApplicationById(id: number): Promise<InternshipApplication | undefined> {
    const result = await db.select().from(internshipApplications).where(eq(internshipApplications.id, id)).limit(1);
    return result[0];
  }

  async getTrainingApplicationById(id: number): Promise<TrainingApplication | undefined> {
    const result = await db.select().from(trainingApplications).where(eq(trainingApplications.id, id)).limit(1);
    return result[0];
  }

  async updateContactMessageStatus(id: number, status: string): Promise<ContactMessage> {
    const result = await db
      .update(contactMessages)
      .set({ status })
      .where(eq(contactMessages.id, id))
      .returning();
    return result[0];
  }

  async updateInternshipApplicationStatus(id: number, status: string): Promise<InternshipApplication> {
    const result = await db
      .update(internshipApplications)
      .set({ status })
      .where(eq(internshipApplications.id, id))
      .returning();
    return result[0];
  }

  async updateTrainingApplicationStatus(id: number, status: string): Promise<TrainingApplication> {
    const result = await db
      .update(trainingApplications)
      .set({ status })
      .where(eq(trainingApplications.id, id))
      .returning();
    return result[0];
  }

  async markContactEmailSent(id: number): Promise<ContactMessage> {
    const result = await db
      .update(contactMessages)
      .set({ emailSent: 1 })
      .where(eq(contactMessages.id, id))
      .returning();
    return result[0];
  }

  async markInternshipSmsSent(id: number): Promise<InternshipApplication> {
    const result = await db
      .update(internshipApplications)
      .set({ smsSent: 1 })
      .where(eq(internshipApplications.id, id))
      .returning();
    return result[0];
  }

  async markTrainingEmailSent(id: number): Promise<TrainingApplication> {
    const result = await db
      .update(trainingApplications)
      .set({ emailSent: 1 })
      .where(eq(trainingApplications.id, id))
      .returning();
    return result[0];
  }

  async getSiteSettingByKey(key: string): Promise<SiteSettings | undefined> {
    const result = await db.select().from(siteSettings).where(eq(siteSettings.key, key)).limit(1);
    return result[0];
  }

  async getAllSiteSettings(): Promise<SiteSettings[]> {
    return await db.select().from(siteSettings);
  }

  async createSiteSetting(setting: InsertSiteSettings): Promise<SiteSettings> {
    const result = await db.insert(siteSettings).values({
      ...setting,
      updatedAt: new Date().toISOString()
    }).returning();
    return result[0];
  }

  async updateSiteSetting(key: string, value: string, description?: string): Promise<SiteSettings> {
    const existingSetting = await this.getSiteSettingByKey(key);
    
    if (!existingSetting) {
      return await this.createSiteSetting({
        key,
        value,
        description: description || ""
      });
    }
    
    const updateData: any = {
      value,
      updatedAt: new Date().toISOString()
    };
    
    if (description !== undefined) {
      updateData.description = description;
    }
    
    const result = await db
      .update(siteSettings)
      .set(updateData)
      .where(eq(siteSettings.key, key))
      .returning();
    
    return result[0];
  }

  async getAllTrainingPrograms(): Promise<TrainingProgram[]> {
    return await db
      .select()
      .from(trainingPrograms)
      .where(eq(trainingPrograms.active, 1))
      .orderBy(trainingPrograms.id);
  }

  async getTrainingProgramBySlug(slug: string): Promise<TrainingProgram | undefined> {
    const result = await db
      .select()
      .from(trainingPrograms)
      .where(eq(trainingPrograms.slug, slug))
      .limit(1);
    return result[0];
  }

  async createTrainingProgram(program: InsertTrainingProgram): Promise<TrainingProgram> {
    const processedProgram = {
      ...program,
      modules: typeof program.modules === 'string' ? program.modules : JSON.stringify(program.modules),
      tools: typeof program.tools === 'string' ? program.tools : JSON.stringify(program.tools),
      highlights: typeof program.highlights === 'string' ? program.highlights : JSON.stringify(program.highlights),
      careers: typeof program.careers === 'string' ? program.careers : JSON.stringify(program.careers),
      active: 1,
      updatedAt: new Date().toISOString()
    };
    
    const result = await db.insert(trainingPrograms).values(processedProgram).returning();
    return result[0];
  }

  async updateTrainingProgram(id: number, program: Partial<TrainingProgram>): Promise<TrainingProgram> {
    const processedFields: any = {
      ...program,
      updatedAt: new Date().toISOString()
    };
    
    if (program.modules) {
      processedFields.modules = typeof program.modules === 'string' 
        ? program.modules 
        : JSON.stringify(program.modules);
    }
    
    if (program.tools) {
      processedFields.tools = typeof program.tools === 'string' 
        ? program.tools 
        : JSON.stringify(program.tools);
    }
    
    if (program.highlights) {
      processedFields.highlights = typeof program.highlights === 'string' 
        ? program.highlights 
        : JSON.stringify(program.highlights);
    }
    
    if (program.careers) {
      processedFields.careers = typeof program.careers === 'string' 
        ? program.careers 
        : JSON.stringify(program.careers);
    }
    
    delete processedFields.id;
    
    const result = await db
      .update(trainingPrograms)
      .set(processedFields)
      .where(eq(trainingPrograms.id, id))
      .returning();
    
    return result[0];
  }

  async deleteTrainingProgram(id: number): Promise<boolean> {
    const result = await db
      .update(trainingPrograms)
      .set({ 
        active: 0,
        updatedAt: new Date().toISOString() 
      })
      .where(eq(trainingPrograms.id, id))
      .returning();
    
    return result.length > 0;
  }

  async getAllInternshipPositions(): Promise<InternshipPosition[]> {
    return await db
      .select()
      .from(internshipPositions)
      .where(eq(internshipPositions.active, 1))
      .orderBy(internshipPositions.id);
  }

  async getInternshipPositionById(id: number): Promise<InternshipPosition | undefined> {
    const result = await db
      .select()
      .from(internshipPositions)
      .where(eq(internshipPositions.id, id))
      .limit(1);
    return result[0];
  }

  async createInternshipPosition(position: InsertInternshipPosition): Promise<InternshipPosition> {
    const processedPosition = {
      ...position,
      responsibilities: typeof position.responsibilities === 'string' 
        ? position.responsibilities 
        : JSON.stringify(position.responsibilities),
      requirements: typeof position.requirements === 'string' 
        ? position.requirements 
        : JSON.stringify(position.requirements),
      active: 1,
      updatedAt: new Date().toISOString()
    };
    
    const result = await db.insert(internshipPositions).values(processedPosition).returning();
    return result[0];
  }

  async updateInternshipPosition(id: number, position: Partial<InternshipPosition>): Promise<InternshipPosition> {
    const processedFields: any = {
      ...position,
      updatedAt: new Date().toISOString()
    };
    
    if (position.responsibilities) {
      processedFields.responsibilities = typeof position.responsibilities === 'string' 
        ? position.responsibilities 
        : JSON.stringify(position.responsibilities);
    }
    
    if (position.requirements) {
      processedFields.requirements = typeof position.requirements === 'string' 
        ? position.requirements 
        : JSON.stringify(position.requirements);
    }
    
    delete processedFields.id;
    
    const result = await db
      .update(internshipPositions)
      .set(processedFields)
      .where(eq(internshipPositions.id, id))
      .returning();
    
    return result[0];
  }

  async deleteInternshipPosition(id: number): Promise<boolean> {
    const result = await db
      .update(internshipPositions)
      .set({ 
        active: 0,
        updatedAt: new Date().toISOString() 
      })
      .where(eq(internshipPositions.id, id))
      .returning();
    
    return result.length > 0;
  }
}

export const storage = new DbStorage();
