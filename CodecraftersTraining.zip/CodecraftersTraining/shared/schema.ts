import { sqliteTable, text, integer, blob } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = sqliteTable("users", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const testimonials = sqliteTable("testimonials", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  role: text("role").notNull(),
  content: text("content").notNull(),
  rating: integer("rating").notNull(),
  program: text("program"),
});

export const contactMessages = sqliteTable("contact_messages", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  name: text("name").notNull(),
  email: text("email").notNull(),
  subject: text("subject").notNull(),
  message: text("message").notNull(),
  status: text("status").notNull().default("pending"),
  emailSent: integer("email_sent").notNull().default(0), // 0 = not sent, 1 = sent
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
});

export const internshipApplications = sqliteTable("internship_applications", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  internshipType: text("internship_type").notNull(),
  coverLetter: text("cover_letter"),
  resumeUrl: text("resume_url"),
  status: text("status").notNull().default("pending"),
  smsSent: integer("sms_sent").notNull().default(0), // 0 = not sent, 1 = sent
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
});

export const trainingApplications = sqliteTable("training_applications", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  programId: text("program_id").notNull(),
  message: text("message"),
  status: text("status").notNull().default("pending"),
  emailSent: integer("email_sent").notNull().default(0), // 0 = not sent, 1 = sent
  createdAt: text("created_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// Content Management Tables
export const siteSettings = sqliteTable("site_settings", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  key: text("key").notNull().unique(), // e.g., 'logo', 'site_name', 'whatsapp_number'
  value: text("value").notNull(),
  description: text("description"),
  updatedAt: text("updated_at").notNull().$defaultFn(() => new Date().toISOString()),
});

export const trainingPrograms = sqliteTable("training_programs", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  slug: text("slug").notNull().unique(), // e.g., 'cyber', 'fullstack'
  shortTitle: text("short_title").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  modules: text("modules").notNull(), // JSON string array
  tools: text("tools").notNull(), // JSON string array
  highlights: text("highlights").notNull(), // JSON string array
  careers: text("careers").notNull(), // JSON string array
  active: integer("active").notNull().default(1), // 0 = inactive, 1 = active
  updatedAt: text("updated_at").notNull().$defaultFn(() => new Date().toISOString()),
});

export const internshipPositions = sqliteTable("internship_positions", {
  id: integer("id").primaryKey({ autoIncrement: true }),
  title: text("title").notNull(),
  duration: text("duration").notNull(),
  type: text("type").notNull(), // Remote or Hybrid
  category: text("category").notNull(),
  responsibilities: text("responsibilities").notNull(), // JSON string array
  requirements: text("requirements").notNull(), // JSON string array
  active: integer("active").notNull().default(1), // 0 = inactive, 1 = active
  updatedAt: text("updated_at").notNull().$defaultFn(() => new Date().toISOString()),
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertTestimonialSchema = createInsertSchema(testimonials);

export const insertContactMessageSchema = createInsertSchema(contactMessages).omit({
  id: true,
  createdAt: true,
  status: true,
  emailSent: true,
});

export const insertInternshipApplicationSchema = createInsertSchema(internshipApplications).omit({
  id: true,
  createdAt: true,
  resumeUrl: true,
  status: true,
  smsSent: true,
});

export const insertTrainingApplicationSchema = createInsertSchema(trainingApplications).omit({
  id: true,
  createdAt: true,
  status: true,
  emailSent: true,
});

export const insertSiteSettingsSchema = createInsertSchema(siteSettings).omit({
  id: true,
  updatedAt: true,
});

export const insertTrainingProgramSchema = createInsertSchema(trainingPrograms).omit({
  id: true,
  updatedAt: true,
  active: true,
});

export const insertInternshipPositionSchema = createInsertSchema(internshipPositions).omit({
  id: true,
  updatedAt: true,
  active: true,
});

// Form Validation Schemas
export const contactFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  subject: z.string().min(5, { message: "Subject must be at least 5 characters" }),
  message: z.string().min(10, { message: "Message must be at least 10 characters" }),
});

export const internshipApplicationSchema = z.object({
  fullName: z.string().min(2, { message: "Full name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  phone: z.string().min(10, { message: "Please enter a valid phone number" }),
  internshipType: z.string().min(1, { message: "Please select an internship type" }),
  coverLetter: z.string().optional(),
});

export const trainingApplicationSchema = z.object({
  fullName: z.string().min(2, { message: "Full name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  phone: z.string().min(10, { message: "Please enter a valid phone number" }),
  programId: z.string().min(1, { message: "Please select a program" }),
  message: z.string().optional(),
});

export const siteSettingsSchema = z.object({
  key: z.string().min(1),
  value: z.string().min(1),
  description: z.string().optional(),
});

export const trainingProgramSchema = z.object({
  slug: z.string().min(1),
  shortTitle: z.string().min(1),
  title: z.string().min(1),
  description: z.string().min(1),
  modules: z.string().min(1), // JSON string array
  tools: z.string().min(1), // JSON string array
  highlights: z.string().min(1), // JSON string array
  careers: z.string().min(1), // JSON string array
});

export const internshipPositionSchema = z.object({
  title: z.string().min(1),
  duration: z.string().min(1),
  type: z.string().min(1),
  category: z.string().min(1),
  responsibilities: z.string().min(1), // JSON string array
  requirements: z.string().min(1), // JSON string array
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type Testimonial = typeof testimonials.$inferSelect;
export type InsertTestimonial = z.infer<typeof insertTestimonialSchema>;

export type ContactMessage = typeof contactMessages.$inferSelect;
export type InsertContactMessage = z.infer<typeof insertContactMessageSchema>;

export type InternshipApplication = typeof internshipApplications.$inferSelect;
export type InsertInternshipApplication = z.infer<typeof insertInternshipApplicationSchema>;

export type TrainingApplication = typeof trainingApplications.$inferSelect;
export type InsertTrainingApplication = z.infer<typeof insertTrainingApplicationSchema>;

export type ContactFormValues = z.infer<typeof contactFormSchema>;
export type InternshipApplicationFormValues = z.infer<typeof internshipApplicationSchema>;
export type TrainingApplicationFormValues = z.infer<typeof trainingApplicationSchema>;

export type SiteSettings = typeof siteSettings.$inferSelect;
export type InsertSiteSettings = z.infer<typeof insertSiteSettingsSchema>;

export type TrainingProgram = typeof trainingPrograms.$inferSelect;
export type InsertTrainingProgram = z.infer<typeof insertTrainingProgramSchema>;

export type InternshipPosition = typeof internshipPositions.$inferSelect;
export type InsertInternshipPosition = z.infer<typeof insertInternshipPositionSchema>;
