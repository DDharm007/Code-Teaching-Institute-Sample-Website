/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./client/index.html",
    "./client/src/**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        primary: "#3B82F6", 
        secondary: "#6B7280",
        background: "#FFFFFF",
        foreground: "#101010",
        border: "#E2E8F0",
        muted: "#F9FAFB",
        "muted-foreground": "#6B7280",
        accent: "#F3F4F6",
        "accent-foreground": "#111827",
        destructive: "#EF4444",
        "destructive-foreground": "#FFFFFF",
        card: "#FFFFFF",
        "card-foreground": "#101010",
        popover: "#FFFFFF",
        "popover-foreground": "#101010",
      },
      borderRadius: {
        lg: "0.5rem",
        md: "0.375rem",
        sm: "0.25rem", 
      }
    }
  },
  plugins: [require("tailwindcss-animate"), require("@tailwindcss/typography")]
} 