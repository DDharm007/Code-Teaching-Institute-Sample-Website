import type { Config } from "tailwindcss";

export default {
  darkMode: ["class"],
  content: [
    "./client/index.html", 
    "./client/src/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      borderRadius: {
        lg: "0.5rem",
        md: "0.375rem",
        sm: "0.25rem",
      },
      colors: {
        primary: "#3B82F6", 
        secondary: "#6B7280",
        background: "#FFFFFF",
        foreground: "#101010",
        border: "#E2E8F0",
        muted: "#F9FAFB",
        "muted-foreground": "#6B7280",
        accent: "#F3F4F6",
        "accent-foreground": "#111827",
        destructive: "#EF4444",
        "destructive-foreground": "#FFFFFF",
        card: "#FFFFFF",
        "card-foreground": "#101010",
        popover: "#FFFFFF",
        "popover-foreground": "#101010",
      },
      keyframes: {
        "accordion-down": {
          from: {
            height: "0",
          },
          to: {
            height: "var(--radix-accordion-content-height)",
          },
        },
        "accordion-up": {
          from: {
            height: "var(--radix-accordion-content-height)",
          },
          to: {
            height: "0",
          },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate"), require("@tailwindcss/typography")],
} satisfies Config;
